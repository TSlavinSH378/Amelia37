package com.ipsoft.amelia.sampleapp

import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.Menu
import android.view.MenuItem
import android.view.View

import com.ipsoft.amelia.sampleapp.accordion.Section

import net.ipsoft.amelia.sdk.BaseDomain
import net.ipsoft.amelia.sdk.IAmeliaChat

class ChatActivity : AppCompatActivity(), IntegrationFragment.ActionListener {

    private var ameliaChat: IAmeliaChat? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_chat)
        val toolbar = findViewById(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayUseLogoEnabled(true)
        supportActionBar!!.setDisplayShowTitleEnabled(true)

        val app = application as AmeliaApplication
        ameliaChat = app.ameliaChat

        val domain = intent.getParcelableExtra<BaseDomain>("domain")
        if (savedInstanceState == null) {
            selectDomain(domain)
        }

        val chatFragment = ChatFragment.newInstance(domain)
        supportFragmentManager.beginTransaction()
                .add(R.id.chat_fragment, chatFragment)
                .commit()

        volumeControlStream = AudioManager.STREAM_MUSIC
    }

    private fun selectDomain(domain: BaseDomain) {
        ameliaChat!!.selectDomain(domain)
    }

    override fun onStart() {
        super.onStart()
        invalidateOptionsMenu()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (ameliaChat!!.user != null && !ameliaChat!!.user.isAnonymous) {
            menuInflater.inflate(R.menu.menu_logout, menu)
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onBackPressed() {
        if (hideIntegrationFragment()) return
        super.onBackPressed()
        ameliaChat!!.endConversation()
    }

    private fun hideIntegrationFragment(): Boolean {
        val integrationFragment = supportFragmentManager.findFragmentByTag("TAG-INTEGRATION-FRAGMENT")
        if (integrationFragment != null) {
            supportFragmentManager.beginTransaction()
                    .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.fade_out)
                    .remove(integrationFragment)
                    .commit()


            supportActionBar!!.setTitle(R.string.app_name)
            supportActionBar!!.setDisplayHomeAsUpEnabled(true)
            return true
        }
        return false
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                ameliaChat!!.endConversation()
                return false
            }
            R.id.action_logout -> {
                ameliaChat!!.logout()
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return true
            }
        }
        return false
    }

    fun showIntegration(section: Section) {
        val integrationFragment = IntegrationFragment()
        integrationFragment.setSection(section)

        supportActionBar!!.title = section.title
        supportActionBar!!.setDisplayHomeAsUpEnabled(false)

        supportFragmentManager.beginTransaction()
                .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.fade_out)
                .add(R.id.fragment_container, integrationFragment, "TAG-INTEGRATION-FRAGMENT")
                .commit()
        findViewById(R.id.fragment_container).visibility = View.VISIBLE
    }

    override fun onAction(processName: String, processArgs: String, utterance: String) {
        ameliaChat!!.runAction(processName, processArgs, utterance)
        hideIntegrationFragment()
    }

    companion object {

        val DOMAIN = "domain"
    }
}
