package com.ipsoft.amelia.sampleapp.accordion;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Section {

    protected String name = null;
    protected String sectionType = null;
    protected String title = null;
    protected String imageBase64 = null;
    protected String actionLabel = null;
    protected String actionProcessName = null;
    protected String actionProcessArgs = null;
    protected String selectionUtterance = null;
    protected String utteranceConjunction = null;
    protected List<Section> children = null;
    protected List<SectionField> sectionFields = null;

    public String getName() {
        return name;
    }

    public String getSectionType() {
        return sectionType;
    }

    public String getTitle() {
        return title;
    }

    public String getImageBase64() {
        return imageBase64;
    }

    public String getActionLabel() {
        return actionLabel;
    }

    public String getActionProcessName() {
        return actionProcessName;
    }

    public String getActionProcessArgs() {
        return actionProcessArgs;
    }

    public String getSelectionUtterance() {
        return selectionUtterance;
    }

    public String getUtteranceConjunction() {
        return utteranceConjunction;
    }

    public List<Section> getChildren() {
        return children;
    }

    public List<SectionField> getSectionFields() {
        return sectionFields;
    }

    public static Section deserialize(JSONObject jsonObject) throws JSONException {
        Section section = new Section();
        section.name = jsonObject.optString("name");
        section.sectionType = jsonObject.optString("sectionType");
        section.title = jsonObject.optString("title");
        section.imageBase64 = jsonObject.optString("imageBase64");
        section.actionLabel = jsonObject.optString("actionLabel");
        final JSONObject selectionUtteranceMetadata = jsonObject.optJSONObject("selectionUtteranceMetadata");
        if (selectionUtteranceMetadata != null) {
            section.selectionUtterance = selectionUtteranceMetadata.optString("staticUtterance");
            section.utteranceConjunction = selectionUtteranceMetadata.optString("conjunction");
        }
        final JSONObject actionProcess = jsonObject.optJSONObject("actionProcess");
        if (actionProcess != null) {
            section.actionProcessName = actionProcess.optString("processName");
            final JSONObject processArgs = actionProcess.optJSONObject("processArgs");
            section.actionProcessArgs = processArgs == null ? null : processArgs.toString();
        }

        JSONArray jsonArray = jsonObject.getJSONArray("children");
        List<Section> children = new ArrayList<>(jsonArray.length());
        for (int i = 0; i < jsonArray.length(); i++) {
            children.add(Section.deserialize(jsonArray.getJSONObject(i)));
        }
        section.children = children;

        jsonArray = jsonObject.getJSONArray("sectionFields");
        List<SectionField> sectionFields = new ArrayList<>(jsonArray.length());
        for (int i = 0; i < jsonArray.length(); i++) {
            sectionFields.add(SectionField.deserialize(jsonArray.getJSONObject(i)));
        }
        section.sectionFields = sectionFields;

        return section;
    }

}
