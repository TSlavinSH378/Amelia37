package com.ipsoft.amelia.sampleapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import net.ipsoft.amelia.sdk.IAmeliaError;
import net.ipsoft.amelia.sdk.BaseAuthSystem;
import net.ipsoft.amelia.sdk.BaseSessionListener;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.ISessionListener;
import net.ipsoft.amelia.sdk.LoginOptions;

public class LoginActivity extends AppCompatActivity {

    public static final String PREFERENCE_EMAIL = "email";
    public static final String PREFERENCE_PASSWORD = "password";
    public static final String EXTRA_AUTH_SYSTEM = "auth_system";

    private AutoCompleteTextView usernameView;
    private EditText passwordView;
    private View progressView;
    private IAmeliaChat ameliaChat;
    private Button loginButton;
    private BaseAuthSystem authSystem;

    private ISessionListener setupListener = new BaseSessionListener() {
        @Override
        public void onLoginFail(IAmeliaError error) {
            showProgress(false);
            passwordView.setError(getString(R.string.error_incorrect_password));
            passwordView.requestFocus();
        }

        @Override
        public void onLoginSuccess() {

            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
            SharedPreferences.Editor editor = sharedPreferences.edit();

            String email = usernameView.getText().toString();
            String password = passwordView.getText().toString();

            editor.putString(PREFERENCE_EMAIL, email);
            editor.putString(PREFERENCE_PASSWORD, password);

            editor.apply();
            setResult(RESULT_OK);
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        authSystem = getIntent().getParcelableExtra(EXTRA_AUTH_SYSTEM);
        usernameView = (AutoCompleteTextView) findViewById(R.id.email);

        passwordView = (EditText) findViewById(R.id.password);
        passwordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.login || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });

        autoFillForm();

        loginButton = (Button) findViewById(R.id.email_sign_in_button);
        loginButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptLogin();
            }
        });

        progressView = findViewById(R.id.login_progress);

        AmeliaApplication app = (AmeliaApplication) getApplication();
        ameliaChat = app.getAmeliaChat();
        ameliaChat.addSessionListener(setupListener);

        setResult(RESULT_CANCELED);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        ameliaChat.removeSessionListener(setupListener);
    }


    private void autoFillForm() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
        String email = sharedPreferences.getString(PREFERENCE_EMAIL, "");
        String password = sharedPreferences.getString(PREFERENCE_PASSWORD, "");
        usernameView.setText(email);
        passwordView.setText(password);
    }

    private void attemptLogin() {

        usernameView.setError(null);
        passwordView.setError(null);

        String email = usernameView.getText().toString();
        String password = passwordView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        if (!TextUtils.isEmpty(password) && !isPasswordValid(password)) {
            passwordView.setError(getString(R.string.error_invalid_password));
            focusView = passwordView;
            cancel = true;
        }

        if (TextUtils.isEmpty(email)) {
            usernameView.setError(getString(R.string.error_field_required));
            focusView = usernameView;
            cancel = true;
        } else if (!isEmailValid(email)) {
            usernameView.setError(getString(R.string.error_invalid_email));
            focusView = usernameView;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {
            showProgress(true);
            LoginOptions options = new LoginOptions(authSystem, email, password);
            ameliaChat.login(options);
        }
    }

    private boolean isEmailValid(String email) {
        return true;
    }

    private boolean isPasswordValid(String password) {
        return true;
    }


    private void showProgress(final boolean show) {
        loginButton.setEnabled(!show);
        progressView.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                setResult(RESULT_CANCELED);
                finish();
                return true;
        }
        return false;
    }

}

