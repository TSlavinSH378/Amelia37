package com.ipsoft.amelia.sampleapp

import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Environment
import android.support.v4.content.ContextCompat
import android.support.v4.content.FileProvider
import android.support.v7.widget.RecyclerView
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import net.ipsoft.amelia.sdk.FormInputData
import com.ipsoft.amelia.sampleapp.accordion.Section
import net.ipsoft.amelia.sdk.ContentDisplayOption
import okio.Okio
import java.io.File
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.regex.Pattern

class ChatRecyclerViewAdapter(chatHistory: ChatHistory, formSubmitListener: FormSubmitListener?, permissionRequestListener: PermissionRequestListener?) : RecyclerView.Adapter<ChatRecyclerViewAdapter.ViewHolder>() {
    private var mFormSubmitListener: FormSubmitListener?
    private var mPermissionRequestListener: PermissionRequestListener?

    private val mValues: List<ChatRecord>
    private val onPdfClickListener = View.OnClickListener { v ->
        var uri = v.tag as Uri
        uri = FileProvider.getUriForFile(v.context, v.context.applicationContext.packageName + ".provider", File(uri.path))
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        v.context.startActivity(intent)
    }

    init {
        mValues = chatHistory.records
        mFormSubmitListener = formSubmitListener
        mPermissionRequestListener = permissionRequestListener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder? {
        val view: View
        when (viewType) {
            VIEW_TYPE_ME -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_me, parent, false)
                return ViewHolder(view)
            }
            VIEW_TYPE_AMELIA -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_amelia, parent, false)
                return AmeliaViewHolder(view)
            }
            VIEW_TYPE_MMO_ME -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_mmo_me, parent, false)
                return AmeliaViewHolder(view)
            }
            VIEW_TYPE_MMO_AMELIA -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_mmo_amelia, parent, false)
                return AmeliaViewHolder(view)
            }
            VIEW_TYPE_FORM -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_form, parent, false)
                return FormViewHolder(view)
            }
        }
        return null
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.mItem = mValues[position]
        holder.mContentView.setOnClickListener(null)
        when (holder.itemViewType) {
            VIEW_TYPE_ME, VIEW_TYPE_AMELIA -> {
                val messageTextView = holder.mContentView as TextView
                val context = messageTextView.context
                if (holder.mItem is DownloadChatRecord) {
                    val text = (holder.mItem as DownloadChatRecord).downloadMessage.uri.toString()
                    messageTextView.text = text
                } else if (holder.mItem is UploadChatRecord) {
                    val uploadChatRecord = holder.mItem as UploadChatRecord?
                    if (uploadChatRecord!!.uploadMessage.recentError != null) {
                        messageTextView.text = uploadChatRecord.uploadMessage.recentError.message
                    } else if (uploadChatRecord.uploadMessage.isUploaded) {
                        messageTextView.text = context.getString(R.string.uploaded, uploadChatRecord.uploadMessage.fileType)
                    } else {
                        messageTextView.setText(R.string.uploading)
                    }
                } else if (holder.mItem!!.integration != null && holder.mItem!!.integration.length > 0) {
                    val section: Section
                    try {
                        section = Section.deserialize(JSONObject(holder.mItem!!.integration))
                        messageTextView.text = context.getString(R.string.tap_to_open_integration, section.title)
                        messageTextView.setOnClickListener {
                            if (holder.mView.context is ChatActivity) {
                                (holder.mView.context as ChatActivity).showIntegration(section)
                            }
                        }
                    } catch (e: JSONException) {
                        //Log.e("chat-fragment", "Failed to parse integration message");
                    }

                } else {
                    val textMessage = holder.mItem!!.messageText
                    val htmlPattern = Pattern.compile("^(.*?)(<\\w){1}(.|\\s)*(>){1}(.*?)$")
                    if (htmlPattern.matcher(textMessage).matches()) {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            messageTextView.text = Html.fromHtml(textMessage, Html.FROM_HTML_MODE_LEGACY)
                        } else {
                            messageTextView.text = Html.fromHtml(textMessage)
                        }
                    } else {
                        messageTextView.text = textMessage
                    }
                }
            }
            VIEW_TYPE_MMO_ME -> {
                val mmoItem = holder.mItem as DownloadChatRecord?
                val imageView = holder.mContentView as ImageView
                if (mmoItem!!.downloadMessage.getMimeType().contains("/pdf")) {
                    imageView.setImageDrawable(ContextCompat.getDrawable(imageView.context, R.drawable.ic_pdf_black_40dp))
                } else {
                    imageView.setImageURI(mmoItem.downloadMessage.getUri())
                }
            }
            VIEW_TYPE_MMO_AMELIA -> {
                val mmoItem = holder.mItem as DownloadChatRecord
                val container = holder.mContentView as ViewGroup
                val marginSmall = container.context.resources.getDimensionPixelOffset(R.dimen.margin_small)
                container.removeAllViews()
                val imageView = ImageView(container.context)
                imageView.setBackgroundResource(R.drawable.chat_bubble_amelia)
                imageView.scaleType = ImageView.ScaleType.CENTER_INSIDE
                imageView.setPadding(marginSmall, marginSmall, marginSmall, marginSmall)
                imageView.adjustViewBounds = true
                container.addView(imageView)
                val lp = imageView.layoutParams as LinearLayout.LayoutParams
                lp.setMargins(0, marginSmall, 0, marginSmall)


                val mimeType = mmoItem.downloadMessage.mimeType
                val recentError = mmoItem.downloadMessage.error
                if (recentError != null || mimeType == null) {
                    lp.width = Utils.getPixelFromDp(container.context, 50f)
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    imageView.setImageResource(R.drawable.broken_file)
                    imageView.minimumWidth = 200
                    imageView.minimumHeight = 200
                } else {
                    lp.width = ViewGroup.LayoutParams.MATCH_PARENT
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    if (mimeType.contains("/pdf")) {
                        imageView.setImageDrawable(ContextCompat.getDrawable(container.context, R.drawable.ic_pdf_black_40dp))
                        imageView.tag = mmoItem.downloadMessage.uri
                        imageView.setOnClickListener(onPdfClickListener)
                    } else if (mimeType.contains("image")) {
                        val imageUri = mmoItem.downloadMessage.uri
                        val contentDisplayOption = mmoItem.downloadMessage.contentDisplayOption
                        val fileInfo = mmoItem.downloadMessage.fileInfo
                        imageView.tag = null
                        val imageClickListener = View.OnClickListener { popupImage(imageView.context, imageUri) }
                        val imageLongClickListener = View.OnLongClickListener {
                            showExtendedOptions(imageView.context, imageUri, mimeType)
                            true
                        }
                        if (contentDisplayOption == ContentDisplayOption.INLINE_ONLY) {
                            imageView.setImageURI(imageUri)
                        } else if (contentDisplayOption == ContentDisplayOption.INLINE_AND_POPUP) {
                            imageView.setImageURI(imageUri)
                            imageView.setOnClickListener(imageClickListener)
                        } else if (contentDisplayOption == ContentDisplayOption.POPUP_ONLY) {
                            imageView.visibility = View.GONE
                            popupImage(imageView.context, imageUri)
                        } else if (contentDisplayOption == ContentDisplayOption.POPUP_AND_INLINE) {
                            popupImage(imageView.context, imageUri)
                            imageView.setImageURI(imageUri)
                        } else {
                            lp.width = Utils.getPixelFromDp(container.context, 50f)
                            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                            imageView.setImageResource(R.drawable.file_icon)
                        }
                        if (fileInfo.download!!) {
                            imageView.setOnLongClickListener(imageLongClickListener)
                        }
                        if (fileInfo.shouldDisplayResourceDetails()) {
                            val file = File(imageUri.path)
                            val tv = TextView(container.context)
                            tv.text = fileInfo.filename + " (" + file.length() / 1024 + "KB)"
                            container.addView(tv)
                        }

                    } else {//other types of file downloaded.
                        imageView.setImageDrawable(ContextCompat.getDrawable(container.context, R.drawable.file_icon))
                        imageView.tag = null
                        imageView.setOnClickListener(null)
                        imageView.setOnClickListener { v ->
                            val fileUrl = mmoItem.downloadMessage.uri.toString()
                            Toast.makeText(holder.mContentView.getContext(), v.context.getString(R.string.file_downloaded_at) + fileUrl, Toast.LENGTH_LONG).show()
                        }
                    }
                }

            }
            VIEW_TYPE_FORM -> {
                val form: FormInputData = holder.mItem!!.form

                val msgTextView = holder.mContentView as TextView
                msgTextView.text = holder.mItem!!.messageText

                val placeHolderView = (holder as FormViewHolder).formPlaceholder

                val formView = FormView(placeHolderView.context)
                formView.setFormInputData(form)
                formView.setFormSubmitListener(object : FormView.FormSubmittedListener {
                    override fun onFormSubmitted(value: String) {
                        if (mFormSubmitListener != null) {
                            mFormSubmitListener!!.onFormSubmitted(form, value)
                        }
                    }
                })

                // Replace the placeholder with the actual formView
                val parent = placeHolderView.parent as ViewGroup
                val placeholderIndex = parent.indexOfChild(placeHolderView)
                parent.removeView(placeHolderView)
                formView.id = placeHolderView.id
                parent.addView(formView, placeholderIndex)
            }
        }
        if (!holder.mItem!!.isSelf) {
            (holder as AmeliaViewHolder).emoticon.text = getEmoticon(holder.mItem!!)
        }

        holder.mView.setOnClickListener {
            // retry
        }
    }

    private fun showExtendedOptions(context: Context, uri: Uri, mimeType: String) {
        val colors = arrayOf<CharSequence>("Save")

        val builder = AlertDialog.Builder(context)
        builder.setTitle("File options")
        builder.setItems(colors) { dialog, which ->
            if (which == 0) {
                mPermissionRequestListener?.requestPermission(object : PermissionRequestCompletionListener {
                    override fun onPermissionGranted() {
                        val sourceFile = File(uri.path)
                        val downloadFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                        val file = File(downloadFolder, sourceFile.name)
                        try {
                            val bufferedSink = Okio.buffer(Okio.sink(file))
                            bufferedSink.writeAll(Okio.source(sourceFile))
                            bufferedSink.close()
                            val manager = context.getSystemService(
                                    Context.DOWNLOAD_SERVICE) as DownloadManager
                            manager.addCompletedDownload(file.name, file.name, true, mimeType, file.absolutePath, file.length(), true)
                            Toast.makeText(context, file.name + " " + context.getString(R.string.file_saved_successfully), Toast.LENGTH_LONG).show()
                        } catch (ex: IOException) {
                            Toast.makeText(context, context.getString(R.string.file_cannot_be_saved), Toast.LENGTH_LONG).show()
                        }
                    }

                    override fun onPermissionDenied() {
                        Toast.makeText(context, context.getString(R.string.file_cannot_be_saved), Toast.LENGTH_LONG).show()
                    }
                })

            }
        }
        builder.show()
    }

    private fun popupImage(context: Context, imageUri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setDataAndType(imageUri, "image/*")
        context.startActivity(intent)
    }

    private fun getEmoticon(chatRecord: ChatRecord): String {
        if (chatRecord is UploadChatRecord) {
            if (chatRecord.uploadMessage.isUploaded) {
                return String(Character.toChars(0x1F44D))
            } else {
                return String(Character.toChars(0x1F449))
            }
        } else {
            when (chatRecord.mood) {
                "NEUTRAL" ->  return String(Character.toChars(0x1F610))
                "HAPPY" -> return String(Character.toChars(0x1F603))
                "SAD" -> return String(Character.toChars(0x1F622))
                "SURPRISED" -> return String(Character.toChars(0x1F632))
                "ANGRY" -> return String(Character.toChars(0x1F621))
                "DISGUSTED" -> return String(Character.toChars(0x1F623))
                "FEAR" -> return String(Character.toChars(0x1F631))
                "CONTEMPT" -> return String(Character.toChars(0x1F620))
                "AMUSED" -> return String(Character.toChars(0x1F601))
                "BEMUSED" -> return String(Character.toChars(0x1F601))
                "CONFUSION" -> return String(Character.toChars(0x1F615))
                "EXCITED" -> return String(Character.toChars(0x1F603))
                "HAPPY_SINCERE" -> return String(Character.toChars(0x1F603))
                "JOY" -> return String(Character.toChars(0x1F603))
                "POUT" -> return String(Character.toChars(0x1F621))
                "SIMPLE_SMILE" -> return String(Character.toChars(0x1F603))
                "SINCERE_SMILE" -> return String(Character.toChars(0x1F603))
                "SMIRK_LEFT" -> return String(Character.toChars(0x1F60F))
                "SMIRK_RIGHT" -> return String(Character.toChars(0x1F60F))
                "SIRPRISED" -> return String(Character.toChars(0x1F632))
                else -> return String(Character.toChars(0x1F610))
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val item = mValues[position]
        if (item is DownloadChatRecord) {
            return if (mValues[position].isSelf) VIEW_TYPE_MMO_ME else VIEW_TYPE_MMO_AMELIA
        }

        // Display as form if there is a form and it is the last item
        if (item.form != null && position == mValues.size - 1) {
            return VIEW_TYPE_FORM
        }

        if ("OutboundSessionClosedMessage" == item.messageType || "OutboundConversationClosedMessage" == item.messageType) {
            return VIEW_TYPE_SYS
        }

        return if (mValues[position].isSelf) VIEW_TYPE_ME else VIEW_TYPE_AMELIA
    }


    override fun getItemCount(): Int {
        return mValues.size
    }

    fun removeFormSubmitListener() {
        mFormSubmitListener = null
    }

    open inner class ViewHolder(val mView: View) : RecyclerView.ViewHolder(mView) {
        val mContentView: View
        var mItem: ChatRecord? = null

        init {
            mContentView = mView.findViewById(R.id.message)
        }
    }

    open inner class AmeliaViewHolder(view: View) : ViewHolder(view) {
        val emoticon: TextView

        init {
            emoticon = view.findViewById(R.id.emoticon) as TextView
        }
    }

    inner class FormViewHolder(view: View) : AmeliaViewHolder(view) {

        val formPlaceholder: ViewGroup
            get() = itemView.findViewById(R.id.fields_container) as ViewGroup
    }

    interface FormSubmitListener {
        fun onFormSubmitted(form: FormInputData, message: String)
    }

    interface PermissionRequestListener {
        fun requestPermission(listener: PermissionRequestCompletionListener)
    }

    interface PermissionRequestCompletionListener {
        fun onPermissionGranted()
        fun onPermissionDenied()
    }

    companion object {

        private val VIEW_TYPE_ME = 0
        private val VIEW_TYPE_AMELIA = 1
        private val VIEW_TYPE_MMO_ME = 2
        private val VIEW_TYPE_MMO_AMELIA = 3
        private val VIEW_TYPE_FORM = 4
        private val VIEW_TYPE_SYS = 5

    }
}
