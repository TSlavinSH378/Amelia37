package com.ipsoft.amelia.sampleapp;


import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.IDownloadMessage;

/**
 * A specific chat record for MMO downloads
 */
public class DownloadChatRecord extends ChatRecord {

    public final IDownloadMessage downloadMessage;

    public DownloadChatRecord(IAmeliaOutboundMessage message) {
        super(message);
        downloadMessage = message.getDownloadMessage();
    }

}
