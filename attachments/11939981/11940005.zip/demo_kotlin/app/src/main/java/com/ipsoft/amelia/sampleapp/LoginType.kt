package com.ipsoft.amelia.sampleapp

/**
 * Created by yyang on 2/5/18.
 */

enum class LoginType {
    LOGIN_TYPE_AUTH,
    LOGIN_TYPE_ANONYMOUS
}
