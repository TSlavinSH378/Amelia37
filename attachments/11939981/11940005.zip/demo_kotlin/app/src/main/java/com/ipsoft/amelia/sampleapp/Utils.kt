package com.ipsoft.amelia.sampleapp

import android.content.Context
import android.content.res.Resources

/**
 * Created by yyang on 9/7/17.
 */

object Utils {
    val LOGIN_TYPE = "LOGIN_TYPE"

    val screenWidth: Int
        get() = Resources.getSystem().displayMetrics.widthPixels

    fun isEmpty(str: String?): Boolean {
        return str == null || str.length == 0
    }


    fun getPixelFromDp(context: Context, dp: Float): Int {
        return (dp * context.resources.displayMetrics.density).toInt()
    }
}
