package com.ipsoft.amelia.sampleapp

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.support.design.widget.Snackbar
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import net.ipsoft.amelia.sdk.*


class DomainFragment : Fragment(), SwipeRefreshLayout.OnRefreshListener {
    private var mColumnCount = 1
    private var mListener: OnListFragmentInteractionListener? = null
    private var adapter: DomainRecyclerViewAdapter? = null
    private var ameliaChat: IAmeliaChat? = null
    private var swipeToRefresh: SwipeRefreshLayout? = null
    private var app: AmeliaApplication? = null
    private var isSamlLogin: Boolean = false
    private var authSystem: BaseAuthSystem? = null
    private var pendingNewConversation: Boolean = false
    private var loginType: LoginType? = null

    private val sessionListener = object : BaseSessionListener() {

        override fun onDomainSelectionRequired(domains: List<BaseDomain>?) {
            if (isAdded) {
                adapter!!.setValues(domains)
                swipeToRefresh!!.isRefreshing = false
                swipeToRefresh!!.isEnabled = false
            }
            unsetPendingState()
        }

        override fun onDomainFail(error: IAmeliaError?) {
            if (isAdded) {
                Snackbar.make(view!!, "There was error fetching domains.", Snackbar.LENGTH_SHORT).show()
                swipeToRefresh!!.isRefreshing = false
                swipeToRefresh!!.isEnabled = true
            }
            unsetPendingState()
        }

        override fun onSessionStart() {
            if (isAdded) {
                activity.supportInvalidateOptionsMenu()
            }
            unsetPendingState()
        }

        override fun onSessionFail(error: IAmeliaError?) {
            if (isAdded) {
                Snackbar.make(view!!, "There was error starting the session.", Snackbar.LENGTH_SHORT).show()
                swipeToRefresh!!.isRefreshing = false
                swipeToRefresh!!.isEnabled = true
            }
            unsetPendingState()
        }

        override fun onLoginRequired(authSystems: List<BaseAuthSystem>) {
            if (isAdded) {
                authSystem = findAuthSystem(authSystems)
                if (!isSamlLogin) {
                    val intent = Intent(context, LoginActivity::class.java)
                    intent.putExtra(LoginActivity.EXTRA_AUTH_SYSTEM, authSystem)
                    startActivityForResult(intent, LOGIN_INTERNAL_REQUEST_CODE)
                } else {
                    if (authSystem != null) {
                        val app = this@DomainFragment.activity.application as AmeliaApplication
                        val ssoLoginIntent = Intent(context, SsoLoginActivity::class.java)
                        ssoLoginIntent.putExtra(SsoLoginActivity.EXTRA_LOGIN_URL, app.baseUrl + "/Amelia" + authSystem!!.loginPath + "?loginMode=mobileios")
                        startActivityForResult(ssoLoginIntent, LOGIN_SAML_REQUEST_CODE)
                    } else {
                        Snackbar.make(view!!, "No auth systems available for SAML login", Snackbar.LENGTH_SHORT).show()
                        swipeToRefresh!!.isRefreshing = false
                        swipeToRefresh!!.isEnabled = true
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (arguments != null) {
            mColumnCount = arguments.getInt(ARG_COLUMN_COUNT)
        }

        app = activity.application as AmeliaApplication
        ameliaChat = app!!.ameliaChat
        ameliaChat!!.addSessionListener(sessionListener)


        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        isSamlLogin = sharedPreferences.getBoolean(getString(R.string.key_saml_login_enabled), false)

        setHasOptionsMenu(true)

    }

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater!!.inflate(R.layout.fragment_domain_grid, container, false)

        val context = view.context
        val recyclerView = view.findViewById(R.id.list) as RecyclerView
        if (mColumnCount <= 1) {
            recyclerView.layoutManager = LinearLayoutManager(context)
        } else {
            recyclerView.layoutManager = GridLayoutManager(context, mColumnCount)
        }

        adapter = DomainRecyclerViewAdapter(mListener)
        recyclerView.adapter = adapter

        swipeToRefresh = view.findViewById(R.id.swipe_to_refresh) as SwipeRefreshLayout
        swipeToRefresh!!.setOnRefreshListener(this)
        swipeToRefresh!!.isRefreshing = true


        val intent = this.activity.intent
        val loginType = intent.getIntExtra(Utils.LOGIN_TYPE, LoginType.LOGIN_TYPE_AUTH.ordinal)
        if (loginType == LoginType.LOGIN_TYPE_AUTH.ordinal) {
            this.loginType = LoginType.LOGIN_TYPE_AUTH
            ameliaChat?.stepupLogin()
        } else {
            this.loginType = LoginType.LOGIN_TYPE_ANONYMOUS
            ameliaChat?.startNewConversation()
        }
        pendingNewConversation = true

        return view
    }


    override fun onAttach(context: Context?) {
        super.onAttach(context)
        if (context is OnListFragmentInteractionListener) {
            mListener = context
        }
    }

    override fun onDetach() {
        super.onDetach()
        mListener = null
    }

    override fun onDestroy() {
        super.onDestroy()
        ameliaChat!!.removeSessionListener(sessionListener)
    }


    override fun onRefresh() {
        pendingNewConversation = true
        if (loginType === LoginType.LOGIN_TYPE_AUTH) {
            ameliaChat?.stepupLogin()
        } else {
            ameliaChat?.startNewConversation()
        }
    }

    interface OnListFragmentInteractionListener {
        fun onListFragmentInteraction(item: BaseDomain)
    }

    fun findAuthSystem(authSystems: List<BaseAuthSystem>): BaseAuthSystem? {
        if (!isSamlLogin) {
            for (authSystem in authSystems) {
                if (!authSystem.redirect) {
                    return authSystem
                }
            }
        } else {
            for (authSystem in authSystems) {
                if (authSystem.redirect) {
                    return authSystem
                }
            }
        }
        return null
    }

    private fun unsetPendingState() {
        pendingNewConversation = false
        activity.supportInvalidateOptionsMenu()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == LOGIN_INTERNAL_REQUEST_CODE) {
            when (resultCode) {
                Activity.RESULT_CANCELED -> activity.finish()
            }
        } else if (requestCode == LOGIN_SAML_REQUEST_CODE) {
            when (resultCode) {
                Activity.RESULT_OK -> {
                    var loginOptions: LoginOptions? = null
                    if (data != null && data.extras != null) {
                        loginOptions = LoginOptions(authSystem, data.extras.getString(AmeliaAppConstants.SSO_COOKIE))
                    } else {
                        loginOptions = LoginOptions(authSystem, activity.applicationContext)
                    }
                    ameliaChat!!.login(loginOptions)
                    authSystem = null
                }
                Activity.RESULT_CANCELED -> activity.finish()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        activity.supportInvalidateOptionsMenu()
    }


    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        if (ameliaChat!!.user != null && !ameliaChat!!.user.isAnonymous) {
            inflater!!.inflate(R.menu.menu_logout, menu)
        } else if (!pendingNewConversation && (ameliaChat!!.user == null || ameliaChat!!.user.isAnonymous)) {
            inflater!!.inflate(R.menu.menu_login, menu)
        } else {
            super.onCreateOptionsMenu(menu, inflater)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item!!.itemId) {
            R.id.action_logout -> {
                ameliaChat!!.logout()
                val intent = Intent(context, MainActivity::class.java)
                startActivity(intent)
                return true
            }
            R.id.action_login -> {
                pendingNewConversation = true
                ameliaChat!!.stepupLogin()
                return true
            }
        }
        return false
    }

    companion object {

        private val ARG_COLUMN_COUNT = "column-count"
        private val LOGIN_INTERNAL_REQUEST_CODE = 1002
        private val LOGIN_SAML_REQUEST_CODE = 1003

        fun newInstance(columnCount: Int): DomainFragment {
            val fragment = DomainFragment()
            val args = Bundle()
            args.putInt(ARG_COLUMN_COUNT, columnCount)
            fragment.arguments = args
            return fragment
        }
    }
}
