package com.ipsoft.amelia.sampleapp;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ipsoft.amelia.sampleapp.accordion.Section;

import net.ipsoft.amelia.sdk.IAmeliaError;
import net.ipsoft.amelia.sdk.ContentDisplayOption;
import net.ipsoft.amelia.sdk.FormInputData;
import net.ipsoft.amelia.sdk.IResourceToDisplay;

import java.io.File;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;

import okio.BufferedSink;
import okio.Okio;

public class ChatRecyclerViewAdapter extends RecyclerView.Adapter<ChatRecyclerViewAdapter.ViewHolder> {

    private static final int VIEW_TYPE_ME = 0;
    private static final int VIEW_TYPE_AMELIA = 1;
    private static final int VIEW_TYPE_MMO_ME = 2;
    private static final int VIEW_TYPE_MMO_AMELIA = 3;
    private static final int VIEW_TYPE_FORM = 4;
    private static final int VIEW_TYPE_SYS = 5;

    private final List<ChatRecord> mValues;
    private PermissionRequestListener mPermissionRequestListener;
    private FormSubmitListener mFormSubmitListener;
    private View.OnClickListener onPdfClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Uri uri = (Uri) v.getTag();
            uri = FileProvider.getUriForFile(v.getContext(), v.getContext().getApplicationContext().getPackageName() + ".provider", new File(uri.getPath()));
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            v.getContext().startActivity(intent);
        }
    };

    public ChatRecyclerViewAdapter(ChatHistory chatHistory, @Nullable FormSubmitListener formSubmitListener, @Nullable PermissionRequestListener permissionRequestListener) {
        mValues = chatHistory.getRecords();
        mFormSubmitListener = formSubmitListener;
        mPermissionRequestListener = permissionRequestListener;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case VIEW_TYPE_ME:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_me, parent, false);
                return new ViewHolder(view);
            case VIEW_TYPE_AMELIA:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_amelia, parent, false);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_MMO_ME:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_mmo_me, parent, false);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_MMO_AMELIA:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_mmo_amelia, parent, false);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_FORM:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_form, parent, false);
                return new FormViewHolder(view);

        }
        return null;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.mItem = mValues.get(position);
        holder.mContentView.setOnClickListener(null);
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_ME:
            case VIEW_TYPE_AMELIA:
                TextView messageTextView = (TextView) holder.mContentView;
                Context context = messageTextView.getContext();
                if (holder.mItem instanceof DownloadChatRecord) {
                    String text = ((DownloadChatRecord) holder.mItem).downloadMessage.getUri().toString();
                    messageTextView.setText(text);
                } else if (holder.mItem instanceof UploadChatRecord) {
                    UploadChatRecord uploadChatRecord = (UploadChatRecord) holder.mItem;
                    if (uploadChatRecord.uploadMessage.getRecentError() != null) {
                        messageTextView.setText(uploadChatRecord.uploadMessage.getRecentError().getMessage());
                    } else if (uploadChatRecord.uploadMessage.isUploaded()) {
                        messageTextView.setText(context.getString(R.string.uploaded, uploadChatRecord.uploadMessage.fileType));
                    } else {
                        messageTextView.setText(R.string.uploading);
                    }
                } else if (holder.mItem.integration != null && holder.mItem.integration.length() > 0) {
                    final Section section;
                    try {
                        section = Section.deserialize(new JSONObject(holder.mItem.integration));
                        messageTextView.setText(context.getString(R.string.tap_to_open_integration, section.getTitle()));
                        messageTextView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (holder.mView.getContext() instanceof ChatActivity) {
                                    ((ChatActivity) holder.mView.getContext()).showIntegration(section);
                                }
                            }
                        });
                    } catch (JSONException e) {
                        //Log.e("chat-fragment", "Failed to parse integration message");
                    }
                } else {
                    String textMessage = holder.mItem.messageText;
                    Pattern htmlPattern
                            = Pattern.compile("^(.*?)(<\\w){1}(.|\\s)*(>){1}(.*?)$");
                    if (textMessage!=null&&htmlPattern.matcher(textMessage).matches()) {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            messageTextView.setText(Html.fromHtml(textMessage, Html.FROM_HTML_MODE_LEGACY));
                        } else {
                            messageTextView.setText(Html.fromHtml(textMessage));
                        }
                    } else {
                        messageTextView.setText(textMessage);
                    }
                }
                break;
            case VIEW_TYPE_MMO_ME: {
                DownloadChatRecord mmoItem = (DownloadChatRecord) holder.mItem;
                ImageView imageView = ((ImageView) holder.mContentView);
                if (mmoItem.downloadMessage.getMimeType().contains("/pdf")) {
                    imageView.setImageDrawable(ContextCompat.getDrawable(imageView.getContext(), R.drawable.ic_pdf_black_40dp));
                } else {
                    imageView.setImageURI(mmoItem.downloadMessage.getUri());
                }
                break;
            }
            case VIEW_TYPE_MMO_AMELIA: {
                final DownloadChatRecord mmoItem = (DownloadChatRecord) holder.mItem;
                ViewGroup container = (ViewGroup) holder.mContentView;
                final int marginSmall = container.getContext().getResources().getDimensionPixelOffset(R.dimen.margin_small);
                container.removeAllViews();
                final ImageView imageView = new ImageView(container.getContext());
                imageView.setBackgroundResource(R.drawable.chat_bubble_amelia);
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                imageView.setPadding(marginSmall, marginSmall, marginSmall, marginSmall);
                imageView.setAdjustViewBounds(true);
                container.addView(imageView);
                LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) imageView.getLayoutParams();
                lp.setMargins(0, marginSmall, 0, marginSmall);


                final String mimeType = mmoItem.downloadMessage.getMimeType();
                final IAmeliaError recentError = mmoItem.downloadMessage.getError();
                if (recentError != null || mimeType == null) {
                    lp.width = Utils.getPixelFromDp(container.getContext(), 50);
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    imageView.setImageResource(R.drawable.broken_file);
                    imageView.setMinimumWidth(200);
                    imageView.setMinimumHeight(200);
                } else {
                    lp.width = ViewGroup.LayoutParams.MATCH_PARENT;
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    if (mimeType.contains("/pdf")) {
                        imageView.setImageDrawable(ContextCompat.getDrawable(container.getContext(), R.drawable.ic_pdf_black_40dp));
                        imageView.setTag(mmoItem.downloadMessage.getUri());
                        imageView.setOnClickListener(onPdfClickListener);
                    } else if (mimeType.contains("image")) {
                        final Uri imageUri = mmoItem.downloadMessage.getUri();
                        ContentDisplayOption contentDisplayOption = mmoItem.downloadMessage.getContentDisplayOption();
                        IResourceToDisplay fileInfo = mmoItem.downloadMessage.getFileInfo();
                        imageView.setTag(null);
                        View.OnClickListener imageClickListener = new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                popupImage(imageView.getContext(), imageUri);
                            }
                        };
                        View.OnLongClickListener imageLongClickListener = new View.OnLongClickListener() {
                            @Override
                            public boolean onLongClick(View v) {
                                showExtendedOptions(imageView.getContext(), imageUri, mimeType);
                                return true;
                            }
                        };
                        if (contentDisplayOption == ContentDisplayOption.INLINE_ONLY) {
                            imageView.setImageURI(imageUri);
                        } else if (contentDisplayOption == ContentDisplayOption.INLINE_AND_POPUP) {
                            imageView.setImageURI(imageUri);
                            imageView.setOnClickListener(imageClickListener);
                        } else if (contentDisplayOption == ContentDisplayOption.POPUP_ONLY) {
                            imageView.setVisibility(View.GONE);
                            popupImage(imageView.getContext(), imageUri);
                        } else if (contentDisplayOption == ContentDisplayOption.POPUP_AND_INLINE) {
                            popupImage(imageView.getContext(), imageUri);
                            imageView.setImageURI(imageUri);
                        } else {
                            lp.width = Utils.getPixelFromDp(container.getContext(), 50);
                            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                            imageView.setImageResource(R.drawable.file_icon);
                        }
                        if (fileInfo.getDownload()) {
                            imageView.setOnLongClickListener(imageLongClickListener);
                        }
                        if (fileInfo.shouldDisplayResourceDetails()) {
                            File file = new File(imageUri.getPath());
                            TextView tv = new TextView(container.getContext());
                            tv.setText(fileInfo.getFilename() + " (" + file.length() / 1024 + "KB)");
                            container.addView(tv);
                        }

                    } else {//other types of file downloaded.
                        imageView.setImageDrawable(ContextCompat.getDrawable(container.getContext(), R.drawable.file_icon));
                        imageView.setTag(null);
                        imageView.setOnClickListener(null);
                        imageView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String fileUrl = mmoItem.downloadMessage.getUri().toString();
                                Toast.makeText(holder.mContentView.getContext(), v.getContext().getString(R.string.file_downloaded_at) + fileUrl, Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }

                break;
            }
            case VIEW_TYPE_FORM:
                final FormInputData form = holder.mItem.form;

                TextView msgTextView = (TextView) holder.mContentView;
                msgTextView.setText(holder.mItem.messageText);

                final ViewGroup placeHolderView = ((FormViewHolder) holder).getFormPlaceholder();

                FormView formView = new FormView(placeHolderView.getContext());
                formView.setFormInputData(form);
                formView.setFormSubmitListener(new FormView.FormSubmittedListener() {
                    @Override
                    public void onFormSubmitted(String value) {
                        if (mFormSubmitListener != null) {
                            mFormSubmitListener.onFormSubmitted(form, value);
                        }
                    }
                });

                // Replace the placeholder with the actual formView
                final ViewGroup parent = (ViewGroup) placeHolderView.getParent();
                final int placeholderIndex = parent.indexOfChild(placeHolderView);
                parent.removeView(placeHolderView);
                formView.setId(placeHolderView.getId());
                parent.addView(formView, placeholderIndex);

                break;
        }
        if (!holder.mItem.isSelf) {
            ((AmeliaViewHolder) holder).emoticon.setText(getEmoticon(holder.mItem));
        }

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // retry
            }
        });
    }

    private String getEmoticon(ChatRecord chatRecord) {
        if (chatRecord instanceof UploadChatRecord) {
            UploadChatRecord uploadChatRecord = (UploadChatRecord) chatRecord;
            if (uploadChatRecord.uploadMessage.isUploaded()) {
                return new String(Character.toChars(0x1F44D));
            } else {
                return new String(Character.toChars(0x1F449));
            }
        } else {
            switch (chatRecord.mood) {
                case "NEUTRAL":
                    return new String(Character.toChars(0x1F610));
                case "HAPPY":
                    return new String(Character.toChars(0x1F603));
                case "SAD":
                    return new String(Character.toChars(0x1F622));
                case "SURPRISED":
                    return new String(Character.toChars(0x1F632));
                case "ANGRY":
                    return new String(Character.toChars(0x1F621));
                case "DISGUSTED":
                    return new String(Character.toChars(0x1F623));
                case "FEAR":
                    return new String(Character.toChars(0x1F631));
                case "CONTEMPT":
                    return new String(Character.toChars(0x1F620));
                case "AMUSED":
                    return new String(Character.toChars(0x1F601));
                case "BEMUSED":
                    return new String(Character.toChars(0x1F601));
                case "CONFUSION":
                    return new String(Character.toChars(0x1F615));
                case "EXCITED":
                    return new String(Character.toChars(0x1F603));
                case "HAPPY_SINCERE":
                    return new String(Character.toChars(0x1F603));
                case "JOY":
                    return new String(Character.toChars(0x1F603));
                case "POUT":
                    return new String(Character.toChars(0x1F621));
                case "SIMPLE_SMILE":
                    return new String(Character.toChars(0x1F603));
                case "SINCERE_SMILE":
                    return new String(Character.toChars(0x1F603));
                case "SMIRK_LEFT":
                    return new String(Character.toChars(0x1F60F));
                case "SMIRK_RIGHT":
                    return new String(Character.toChars(0x1F60F));
                case "SIRPRISED":
                    return new String(Character.toChars(0x1F632));
                default:
                    return new String(Character.toChars(0x1F610));
            }
        }
    }


    @Override
    public int getItemViewType(int position) {
        ChatRecord item = mValues.get(position);
        if (item instanceof DownloadChatRecord) {
            return mValues.get(position).isSelf ? VIEW_TYPE_MMO_ME : VIEW_TYPE_MMO_AMELIA;
        }

        // Display as form if there is a form and it is the last item
        if (item.form != null && position == (mValues.size() - 1)) {
            return VIEW_TYPE_FORM;
        }

        if ("OutboundSessionClosedMessage".equals(item.messageType) ||
                "OutboundConversationClosedMessage".equals(item.messageType)) {
            return VIEW_TYPE_SYS;
        }

        return mValues.get(position).isSelf ? VIEW_TYPE_ME : VIEW_TYPE_AMELIA;
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public void removeFormSubmitListener() {
        mFormSubmitListener = null;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final View mContentView;
        public ChatRecord mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mContentView = view.findViewById(R.id.message);
        }
    }

    public class AmeliaViewHolder extends ViewHolder {
        public final TextView emoticon;

        public AmeliaViewHolder(View view) {
            super(view);
            emoticon = (TextView) view.findViewById(R.id.emoticon);
        }
    }

    public class FormViewHolder extends AmeliaViewHolder {

        public FormViewHolder(View view) {
            super(view);
        }

        public ViewGroup getFormPlaceholder() {
            return (ViewGroup) itemView.findViewById(R.id.fields_container);
        }
    }

    interface FormSubmitListener {
        void onFormSubmitted(FormInputData form, String message);
    }

    interface PermissionRequestListener {
        void requestPermission(PermissionRequestCompletionListener listener);
    }

    interface PermissionRequestCompletionListener {
        void onPermissionGranted();

        void onPermissionDenied();
    }

    private void showExtendedOptions(final Context context, final Uri uri, final String mimeType) {
        CharSequence colors[] = new CharSequence[]{"Save"};

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("File options");
        builder.setItems(colors, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    if (mPermissionRequestListener != null) {
                        mPermissionRequestListener.requestPermission(new PermissionRequestCompletionListener() {
                            @Override
                            public void onPermissionGranted() {
                                File sourceFile = new File(uri.getPath());
                                File downloadFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                                File file = new File(downloadFolder, sourceFile.getName());
                                try {
                                    BufferedSink bufferedSink = Okio.buffer(Okio.sink(file));
                                    bufferedSink.writeAll(Okio.source(sourceFile));
                                    bufferedSink.close();
                                    DownloadManager manager = (DownloadManager) context.getSystemService(
                                            Context.DOWNLOAD_SERVICE);
                                    manager.addCompletedDownload(file.getName(), file.getName(), true, mimeType, file.getAbsolutePath(), file.length(), true);
                                    Toast.makeText(context, file.getName() + " " + context.getString(R.string.file_saved_successfully), Toast.LENGTH_LONG).show();
                                } catch (IOException ex) {
                                    Toast.makeText(context, context.getString(R.string.file_cannot_be_saved)+" "+ex.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }

                            @Override
                            public void onPermissionDenied() {
                                Toast.makeText(context, context.getString(R.string.file_cannot_be_saved), Toast.LENGTH_LONG).show();
                            }
                        });
                    }

                }
            }
        });
        builder.show();
    }

    private void popupImage(Context context, Uri imageUri) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(imageUri, "image/*");
        context.startActivity(intent);
    }
}
