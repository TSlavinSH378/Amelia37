package com.ipsoft.amelia.sampleapp

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.support.customtabs.CustomTabsClient
import android.support.customtabs.CustomTabsServiceConnection
import android.support.v7.app.AppCompatActivity
import android.webkit.WebView
import android.net.Uri
import android.support.customtabs.CustomTabsIntent
import android.support.customtabs.CustomTabsSession
import android.util.Log

/**
 * new SSO feature (with Chrome tab and mobile redirect mod) is tested against blackrock-amelia-dev
 */
class SsoLoginActivity : AppCompatActivity() {
    protected var webView: WebView? = null
    internal val CUSTOM_TAB_PACKAGE_NAME = "com.android.chrome"
    internal var mCustomTabsClient: CustomTabsClient? = null
    internal var mCustomTabsSession: CustomTabsSession? = null
    internal var mCustomTabsServiceConnection: CustomTabsServiceConnection? = null
    internal var mCustomTabsIntent: CustomTabsIntent? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sso_login)
        webView = findViewById(R.id.web_view) as WebView
        val url = intent.getStringExtra(EXTRA_LOGIN_URL)
        mCustomTabsServiceConnection = object : CustomTabsServiceConnection() {
            override fun onCustomTabsServiceConnected(componentName: ComponentName, customTabsClient: CustomTabsClient) {
                mCustomTabsClient = customTabsClient
                mCustomTabsClient!!.warmup(0L)
                mCustomTabsSession = mCustomTabsClient!!.newSession(null)
            }

            override fun onServiceDisconnected(name: ComponentName) {
                mCustomTabsClient = null
            }
        }

        CustomTabsClient.bindCustomTabsService(this, CUSTOM_TAB_PACKAGE_NAME, mCustomTabsServiceConnection)

        mCustomTabsIntent = CustomTabsIntent.Builder(mCustomTabsSession)
                .setShowTitle(true)
                .build()
        mCustomTabsIntent!!.launchUrl(
                this,
                Uri.parse(url)
        )
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val ssoResult = intent.getStringExtra(AmeliaAppConstants.SSO_COOKIE)
        val url = getIntent().getStringExtra(EXTRA_LOGIN_URL)
        Log.d("steve","url is "+url);
        if (!Utils.isEmpty(ssoResult)) {
            val resultIntent = Intent()
            resultIntent.putExtra(AmeliaAppConstants.SSO_COOKIE, ssoResult)
            this@SsoLoginActivity.setResult(Activity.RESULT_OK, resultIntent)
            this@SsoLoginActivity.finish()
        } else if (!Utils.isEmpty(url)) {
            mCustomTabsIntent!!.launchUrl(this, Uri.parse(url))
        } else {
            this@SsoLoginActivity.setResult(Activity.RESULT_CANCELED)
            this@SsoLoginActivity.finish()
        }
    }

    override fun onDestroy() {
        unbindService(mCustomTabsServiceConnection)
        super.onDestroy()
    }

    companion object {
        val EXTRA_LOGIN_URL = "login_url"
    }

}
