package com.ipsoft.amelia.sampleapp

import net.ipsoft.amelia.sdk.AmeliaOutboundMessage
import net.ipsoft.amelia.sdk.UploadMessage

/**
 * A specific chat record for MMO upload request
 */
class UploadChatRecord(message: AmeliaOutboundMessage) : ChatRecord(message) {

    val uploadMessage: UploadMessage

    init {
        this.uploadMessage = message.uploadMessage
    }

}
