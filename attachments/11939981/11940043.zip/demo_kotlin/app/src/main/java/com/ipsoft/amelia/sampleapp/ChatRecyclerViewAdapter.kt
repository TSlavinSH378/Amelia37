package com.ipsoft.amelia.sampleapp

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.support.v4.content.ContextCompat
import android.support.v4.content.FileProvider
import android.support.v7.widget.RecyclerView
import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import net.ipsoft.amelia.sdk.FormInputData
import com.ipsoft.amelia.sampleapp.accordion.Section
import java.io.File
import org.json.JSONException
import org.json.JSONObject
import java.util.regex.Pattern

class ChatRecyclerViewAdapter(chatHistory: ChatHistory,  formSubmitListener: FormSubmitListener?) : RecyclerView.Adapter<ChatRecyclerViewAdapter.ViewHolder>() {
    private var mFormSubmitListener:FormSubmitListener?
    private val mValues: List<ChatRecord>
    private val onPdfClickListener = View.OnClickListener { v ->
        var uri = v.tag as Uri
        uri = FileProvider.getUriForFile(v.context, v.context.applicationContext.packageName + ".provider", File(uri.path))
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        v.context.startActivity(intent)
    }

    init {
        mValues = chatHistory.records
        mFormSubmitListener = formSubmitListener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder? {
        val view: View
        when (viewType) {
            VIEW_TYPE_ME -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_me, parent, false)
                return ViewHolder(view)
            }
            VIEW_TYPE_AMELIA -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_amelia, parent, false)
                return AmeliaViewHolder(view)
            }
            VIEW_TYPE_MMO_ME -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_mmo_me, parent, false)
                return AmeliaViewHolder(view)
            }
            VIEW_TYPE_MMO_AMELIA -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_mmo_amelia, parent, false)
                return AmeliaViewHolder(view)
            }
            VIEW_TYPE_FORM -> {
                view = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item_form, parent, false)
                return FormViewHolder(view)
            }
        }
        return null
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.mItem = mValues[position]
        holder.mContentView.setOnClickListener(null)
        when (holder.itemViewType) {
            VIEW_TYPE_ME, VIEW_TYPE_AMELIA -> {
                val messageTextView = holder.mContentView as TextView
                val context = messageTextView.context
                if (holder.mItem is DownloadChatRecord) {
                    val text = (holder.mItem as DownloadChatRecord).downloadMessage.metadata.url
                    messageTextView.text = text
                } else if (holder.mItem is UploadChatRecord) {
                    val uploadChatRecord = holder.mItem as UploadChatRecord?
                    if (uploadChatRecord!!.uploadMessage.recentError != null) {
                        messageTextView.text = uploadChatRecord.uploadMessage.recentError.message
                    } else if (uploadChatRecord.uploadMessage.isUploaded) {
                        messageTextView.text = context.getString(R.string.uploaded, uploadChatRecord.uploadMessage.fileType)
                    } else {
                        messageTextView.setText(R.string.uploading)
                    }
                } else if (holder.mItem!!.integration != null && holder.mItem!!.integration.length > 0) {
                    val section: Section
                    try {
                        section = Section.deserialize(JSONObject(holder.mItem!!.integration))
                        messageTextView.text = context.getString(R.string.tap_to_open_integration, section.title)
                        messageTextView.setOnClickListener {
                            if (holder.mView.context is ChatActivity) {
                                (holder.mView.context as ChatActivity).showIntegration(section)
                            }
                        }
                    } catch (e: JSONException) {
                        //Log.e("chat-fragment", "Failed to parse integration message");
                    }

                } else {
                    val textMessage = holder.mItem!!.messageText
                    val htmlPattern = Pattern.compile("^(.*?)(<\\w){1}(.|\\s)*(>){1}(.*?)$")
                    if (htmlPattern.matcher(textMessage).matches()) {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            messageTextView.text = Html.fromHtml(textMessage, Html.FROM_HTML_MODE_LEGACY)
                        } else {
                            messageTextView.text = Html.fromHtml(textMessage)
                        }
                    } else {
                        messageTextView.text = textMessage
                    }
                }
            }
            VIEW_TYPE_MMO_ME -> {
                val mmoItem = holder.mItem as DownloadChatRecord?
                val imageView = holder.mContentView as ImageView
                if (mmoItem!!.downloadMessage.getMimeType(0).contains("/pdf")) {
                    imageView.setImageDrawable(ContextCompat.getDrawable(imageView.context, R.drawable.ic_pdf_black_40dp))
                } else {
                    imageView.setImageURI(mmoItem.downloadMessage.getUri(0))
                }
            }
            VIEW_TYPE_MMO_AMELIA -> {
                val mmoItem = holder.mItem as DownloadChatRecord?
                val container = holder.mContentView as ViewGroup

                val marginSmall = container.context.resources.getDimensionPixelOffset(R.dimen.margin_small)

                container.removeAllViews()
                for (i in 0..mmoItem!!.downloadMessage.metadata.value.size - 1) {
                    val imageView = ImageView(container.context)
                    imageView.setBackgroundResource(R.drawable.chat_bubble_amelia)
                    imageView.scaleType = ImageView.ScaleType.CENTER_INSIDE
                    imageView.setPadding(marginSmall, marginSmall, marginSmall, marginSmall)
                    container.addView(imageView)
                    val lp = imageView.layoutParams as LinearLayout.LayoutParams
                    lp.setMargins(0, marginSmall, 0, marginSmall)
                    lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                }

                for (i in 0..mmoItem.downloadMessage.metadata.value.size - 1) {
                    val mimeType = mmoItem.downloadMessage.getMimeType(0)

                    val recentError = mmoItem.downloadMessage.getRecentError(i)
                    val imageView = container.getChildAt(i) as ImageView

                    if (recentError != null || mimeType == null) {
                        imageView.setBackgroundColor(Color.RED)
                        imageView.minimumWidth = 200
                        imageView.minimumHeight = 200
                        continue
                    }

                    if (mimeType.contains("/pdf")) {
                        imageView.setImageDrawable(ContextCompat.getDrawable(container.context, R.drawable.ic_pdf_black_40dp))
                        imageView.tag = mmoItem.downloadMessage.getUri(0)
                        imageView.setOnClickListener(onPdfClickListener)
                    } else if (mimeType.contains("image")) {
                        imageView.setImageURI(mmoItem.downloadMessage.getUri(0))
                        imageView.tag = null
                        imageView.setOnClickListener(null)
                    } else {//other types of file downloaded.
                        imageView.setImageDrawable(ContextCompat.getDrawable(container.context, R.drawable.file_icon))
                        imageView.tag = null
                        imageView.setOnClickListener(null)
                        imageView.setOnClickListener {
                            val fileUrl = mmoItem.downloadMessage.getUri(0).toString()
                            Toast.makeText(holder.mContentView.getContext(), "file downloaded at: " + fileUrl, Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            VIEW_TYPE_FORM -> {
                val form:FormInputData = holder.mItem!!.form

                val msgTextView = holder.mContentView as TextView
                msgTextView.text = holder.mItem!!.messageText

                val placeHolderView = (holder as FormViewHolder).formPlaceholder

                val formView = FormView(placeHolderView.context)
                formView.setFormInputData(form)
                formView.setFormSubmitListener (object: FormView.FormSubmittedListener{
                    override fun onFormSubmitted(value: String) {
                        if (mFormSubmitListener != null) {
                            mFormSubmitListener!!.onFormSubmitted(form, value)
                        }
                    }
                })

                // Replace the placeholder with the actual formView
                val parent = placeHolderView.parent as ViewGroup
                val placeholderIndex = parent.indexOfChild(placeHolderView)
                parent.removeView(placeHolderView)
                formView.id = placeHolderView.id
                parent.addView(formView, placeholderIndex)
            }
        }
        if (!holder.mItem!!.isSelf) {
            (holder as AmeliaViewHolder).emoticon.text = getEmoticon(holder.mItem!!)
        }

        holder.mView.setOnClickListener {
            // retry
        }
    }

    private fun getEmoticon(chatRecord: ChatRecord): String {
        if (chatRecord is UploadChatRecord) {
            if (chatRecord.uploadMessage.isUploaded) {
                return String(Character.toChars(0x1F44D))
            } else {
                return String(Character.toChars(0x1F449))
            }
        } else {
            when (chatRecord.mood) {
                "NEUTRAL" -> return String(Character.toChars(0x1F610))
                "HAPPY" -> return String(Character.toChars(0x1F603))
                "SAD" -> return String(Character.toChars(0x1F622))
                "SURPRISED" -> return String(Character.toChars(0x1F632))
                "ANGRY" -> return String(Character.toChars(0x1F621))
                "DISGUSTED" -> return String(Character.toChars(0x1F623))
                "FEAR" -> return String(Character.toChars(0x1F631))
                "CONTEMPT" -> return String(Character.toChars(0x1F620))
                else -> return chatRecord.mood
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val item = mValues[position]
        if (item is DownloadChatRecord && "file" == item.downloadMessage.metadata.type) {
            return if (mValues[position].isSelf) VIEW_TYPE_MMO_ME else VIEW_TYPE_MMO_AMELIA
        }

        // Display as form if there is a form and it is the last item
        if (item.form != null && position == mValues.size - 1) {
            return VIEW_TYPE_FORM
        }
        return if (mValues[position].isSelf) VIEW_TYPE_ME else VIEW_TYPE_AMELIA
    }

    override fun getItemCount(): Int {
        return mValues.size
    }

    fun removeFormSubmitListener() {
        mFormSubmitListener = null
    }

    open inner class ViewHolder(val mView: View) : RecyclerView.ViewHolder(mView) {
        val mContentView: View
        var mItem: ChatRecord? = null

        init {
            mContentView = mView.findViewById(R.id.message)
        }
    }

    open inner class AmeliaViewHolder(view: View) : ViewHolder(view) {
        val emoticon: TextView

        init {
            emoticon = view.findViewById(R.id.emoticon) as TextView
        }
    }

    inner class FormViewHolder(view: View) : AmeliaViewHolder(view) {

        val formPlaceholder: ViewGroup
            get() = itemView.findViewById(R.id.fields_container) as ViewGroup
    }

     interface FormSubmitListener {
        fun onFormSubmitted(form: FormInputData, message: String)
    }

    companion object {

        private val VIEW_TYPE_ME = 0
        private val VIEW_TYPE_AMELIA = 1
        private val VIEW_TYPE_MMO_ME = 2
        private val VIEW_TYPE_MMO_AMELIA = 3
        private val VIEW_TYPE_FORM = 4
    }
}
