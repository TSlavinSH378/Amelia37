import android.content.res.Resources;

/**
 * Created by yyang on 9/7/17.
 */

public class Utils {
    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static boolean isEmpty(String str){
        return str==null||str.length()==0;
    }
}
