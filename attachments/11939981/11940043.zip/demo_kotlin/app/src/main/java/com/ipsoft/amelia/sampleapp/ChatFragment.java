package com.ipsoft.amelia.sampleapp;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import net.ipsoft.amelia.sdk.AmeliaError;
import net.ipsoft.amelia.sdk.AmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.BaseConversationListener;
import net.ipsoft.amelia.sdk.Domain;
import net.ipsoft.amelia.sdk.DownloadMessage;
import net.ipsoft.amelia.sdk.DownloadedMmo;
import net.ipsoft.amelia.sdk.FormInputData;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.IConversationListener;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class ChatFragment extends Fragment {

    public static final int FILE_REQUEST_CODE = 1001;
    private static final int MIC_PERMISSON_REQUEST_CODE = 2002;
    private IAmeliaChat ameliaChat;
    private ChatHistory chatHistory;
    private ChatRecyclerViewAdapter adapter;
    private EditText inputField;
    private View sendButton;
    private View speechButton;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeToRefresh;
    private int recentlyLoadedChatIndex = -1;
    private SpeechRecognizer speechRecognizer;
    private Domain domain;

    private View.OnClickListener sendButtonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            submit();
        }
    };

    private View.OnLongClickListener sendButtonLongClickListener = new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            new AlertDialog.Builder(getContext())
                    .setTitle("Run the workflow")
                    .setItems(R.array.run_the_workflow, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String workflow = getResources().getStringArray(R.array.run_the_workflow)[which];
                            submit("run the workflow " + workflow);
                        }
                    })
                    .create()
                    .show();
            return true;
        }
    };

    private View.OnClickListener speechButtonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (ensureMicrophonePermission()) {
                startSpeechListener();
            }
        }
    };

    private void startSpeechListener() {
        Intent recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, domain.getLocaleLanguageTag());

        speechRecognizer.startListening(recognizerIntent);
    }

    private boolean ensureMicrophonePermission() {
        final boolean hasPermission = ContextCompat.checkSelfPermission(getContext(), android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (hasPermission) return true;

        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},
                MIC_PERMISSON_REQUEST_CODE);
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == MIC_PERMISSON_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startSpeechListener();
            } else {
                // We were not granted microphone permission.
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    public ChatFragment() {
    }

    @SuppressWarnings("unused")
    public static ChatFragment newInstance(Domain domain) {
        ChatFragment fragment = new ChatFragment();
        Bundle args = new Bundle();
        args.putParcelable(ChatActivity.Companion.getDOMAIN(), domain);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AmeliaApplication app = (AmeliaApplication) getActivity().getApplication();
        ameliaChat = app.getAmeliaChat();
        chatHistory = app.getChatHistory();
        domain = getArguments().getParcelable(ChatActivity.Companion.getDOMAIN());
        setRetainInstance(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chat, container, false);
        Context context = view.getContext();
        recyclerView = (RecyclerView) view.findViewById(R.id.list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter = new ChatRecyclerViewAdapter(chatHistory, new ChatRecyclerViewAdapter.FormSubmitListener() {
            @Override
            public void onFormSubmitted(FormInputData form, String message) {
                ameliaChat.submitForm(form, message);
            }
        });
        recentlyLoadedChatIndex = chatHistory.getRecords().size() - 1;
        recyclerView.setAdapter(adapter);

        swipeToRefresh = (SwipeRefreshLayout) view.findViewById(R.id.swipe_to_refresh);
        boolean isRefreshing = chatHistory.getRecords().isEmpty();
        swipeToRefresh.setRefreshing(isRefreshing);
        swipeToRefresh.setEnabled(isRefreshing);

        inputField = (EditText) view.findViewById(R.id.input_field);
        inputField.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == EditorInfo.IME_ACTION_SEND && sendButton.isEnabled()) {
                    submit();
                    return true;
                }
                return false;
            }
        });

        speechButton = view.findViewById(R.id.speech_button);
        if (SpeechRecognizer.isRecognitionAvailable(getContext())) {
            speechButton.setEnabled(ameliaChat.isInputEnabled());
            speechButton.setOnClickListener(speechButtonClickListener);
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    Log.d("amelia", "onReadyForSpeech");
                }

                @Override
                public void onBeginningOfSpeech() {
                    Log.d("amelia", "onBeginningOfSpeech");
                }

                @Override
                public void onRmsChanged(float rmsdB) {
                    Log.d("amelia", "onRmsChanged");
                }

                @Override
                public void onBufferReceived(byte[] buffer) {
                    Log.d("amelia", "onBufferReceived");
                }

                @Override
                public void onEndOfSpeech() {
                    Log.d("amelia", "onEndOfSpeech");
                }

                @Override
                public void onError(int error) {
                    Log.d("amelia", "onError");
                }

                @Override
                public void onResults(Bundle results) {
                    Log.d("amelia", "onResults");

                    String str = "";
                    List<String> data = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (data.size() > 0) {
                        str = data.get(0);
                        inputField.setText(str);
                        if (sendButton.isEnabled()) {
                            submit();
                        }
                    }
                    Log.d("amelia", "onResults: [" + data.size() + "]" + str);

                }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    String str = "";
                    List<String> data = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (data.size() > 0) {
                        str = data.get(0);
                        inputField.setText(str);
                    }
                    Log.d("amelia", "onPartialResults: [" + data.size() + "]" + str);

                }

                @Override
                public void onEvent(int eventType, Bundle params) {
                    Log.d("amelia", "onEvent");
                }
            });
        } else {
            speechButton.setVisibility(View.GONE);
        }

        sendButton = view.findViewById(R.id.send_button);
        sendButton.setEnabled(ameliaChat.isInputEnabled());
        sendButton.setOnClickListener(sendButtonClickListener);
        sendButton.setOnLongClickListener(sendButtonLongClickListener);

        ameliaChat.addConversationListener(conversationListener);
        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ameliaChat.removeConversationListener(conversationListener);
        adapter.removeFormSubmitListener();
    }

    private void submit() {
        submit(inputField.getText().toString());
    }

    private void submit(String message) {
        ameliaChat.say(message);
        inputField.setText("");
    }

    private void notifyNewMessage() {
        swipeToRefresh.setRefreshing(false);
        swipeToRefresh.setEnabled(false);
        int lastIndex = chatHistory.getRecords().size() - 1;
        int numItems = lastIndex - recentlyLoadedChatIndex;
        adapter.notifyItemRangeInserted(recentlyLoadedChatIndex + 1, numItems);
        recentlyLoadedChatIndex = lastIndex;
        recyclerView.scrollToPosition(lastIndex);
    }

    private int getMoodIcon(String mood) {
        switch (mood) {
            case "NEUTRAL":
                return R.drawable.graphics_44_amelia_neutral;
            case "HAPPY":
                return R.drawable.graphics_44_amelia_happy;
            case "SAD":
                return R.drawable.graphics_44_amelia_sad;
            case "DISGUSTED":
                return R.drawable.graphics_44_amelia_disgusted;
            case "CONTEMPT":
                return R.drawable.graphics_44_amelia_contempt;
            default:
                return R.drawable.graphics_44_amelia_neutral;
        }
    }


    private void openFileChooser(String fromUserDisplayName, String fileType) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.setType("*/*");
        Intent i = Intent.createChooser(intent, fromUserDisplayName  + " requested " + fileType);
        startActivityForResult(i, FILE_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 1001:
                if (resultCode == Activity.RESULT_OK) {
                    ameliaChat.uploadFile(data.getData());
                }
                break;
        }
    }

    private IConversationListener conversationListener = new BaseConversationListener() {

        @Override
        public void onSecureInputEnabledChanged(boolean enabled){
            if(inputField!=null) {
                if(enabled) {
                    inputField.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                }else{
                    inputField.setInputType(InputType.TYPE_CLASS_TEXT);
                }
            }
        }

        @Override
        public void onInputEnabledChanged(boolean enabled, String messageType, IAmeliaChat.InputStateChangeReason reason) {
            speechButton.setEnabled(enabled);
            sendButton.setEnabled(enabled);
        }

        @Override
        public void onMoodChange(String newMood, String oldMood) {
            if (isAdded()) {
                ((AppCompatActivity) getActivity()).getSupportActionBar().setIcon(getMoodIcon(newMood));
            }
        }

        @Override
        public void outboundFinalTextMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            notifyNewMessage();
        }

        @Override
        public void outboundProgressTextMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            notifyNewMessage();
        }

        @Override
        public void outboundIdleTalkMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            notifyNewMessage();
        }

        @Override
        public void outboundAgentSessionChangedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            notifyNewMessage();
        }

        @Override
        public void wolframAlphaFinalMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            notifyNewMessage();
        }

        @Override
        public void outboundFinalErrorMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            notifyNewMessage();
        }

        @Override
        public void outboundConversationClosedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            if (isAdded()) {
                getActivity().finish();
            }
        }

        @Override
        public void outboundIntegrationMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            notifyNewMessage();
        }

        @Override
        public void outboundSessionClosedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            notifyNewMessage();
        }

        @Override
        public void outboundEchoMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
            notifyNewMessage();
        }

        @Override
        public void outboundMmoDownloadMessage( AmeliaOutboundMessage ameliaOutboundMessage) {
            DownloadMessage downloadMessage = ameliaOutboundMessage.getDownloadMessage();
            if (isAdded() && downloadMessage.getError() == null) {
                String type = downloadMessage.getMetadata().getType();
                if ("file".equals(type)) {
                    final int numFiles = downloadMessage.getMetadata().getValue().size();
                    final AtomicInteger finishedFiles = new AtomicInteger(0);
                    for (int i = 0; i < numFiles; ++i) {
                        downloadMessage.download(i, new DownloadMessage.IDownloadListener() {

                            @Override
                            public void onDownloadFailed(AmeliaError error) {
                                finishedFiles.incrementAndGet();
                            }

                            @Override
                            public void onDownloadSuccess(DownloadedMmo mmo) {
                                final int currentlyDoneCount = finishedFiles.incrementAndGet();
                                if (currentlyDoneCount == numFiles) {
                                    // All files finished
                                    notifyNewMessage();
                                }
                            }
                        }, getContext().getExternalCacheDir());
                    }
                } else if ("url".equals(type)) {
                    notifyNewMessage();
                }
            }
        }

        @Override
        public void onUploadRequest(AmeliaOutboundMessage ameliaOutboundMessage) {
            openFileChooser(ameliaOutboundMessage.getFromUserDisplayName(), ameliaOutboundMessage.getUploadMessage().fileType);
            notifyNewMessage();
        }

        @Override
        public void onUploadSuccess(String fromUserDisplayName, String fileName, String url) {
            int lastIndex = chatHistory.getRecords().size() - 1;
            adapter.notifyItemChanged(lastIndex);
        }

        @Override
        public void onUploadFailed(String fromUserDisplayName, String fileName, String fileType) {

        }
    };
}
