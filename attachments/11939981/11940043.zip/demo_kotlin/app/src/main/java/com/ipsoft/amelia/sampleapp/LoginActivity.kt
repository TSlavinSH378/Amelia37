package com.ipsoft.amelia.sampleapp

import android.app.Activity
import android.os.Bundle
import android.preference.PreferenceManager
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.text.TextUtils
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

import net.ipsoft.amelia.sdk.AmeliaError
import net.ipsoft.amelia.sdk.AuthSystem
import net.ipsoft.amelia.sdk.BaseSessionListener
import net.ipsoft.amelia.sdk.IAmeliaChat
import net.ipsoft.amelia.sdk.LoginOptions

class LoginActivity : AppCompatActivity() {

    private var usernameView: AutoCompleteTextView? = null
    private var passwordView: EditText? = null
    private var progressView: View? = null
    private var ameliaChat: IAmeliaChat? = null
    private var loginButton: Button? = null
    private var authSystem: AuthSystem? = null

    private val setupListener = object : BaseSessionListener() {
        override fun onLoginFail(error: AmeliaError?) {
            showProgress(false)
            passwordView!!.error = getString(R.string.error_incorrect_password)
            passwordView!!.requestFocus()
        }

        override fun onLoginSuccess() {

            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this@LoginActivity)
            val editor = sharedPreferences.edit()

            val email = usernameView!!.text.toString()
            val password = passwordView!!.text.toString()

            editor.putString(PREFERENCE_EMAIL, email)
            editor.putString(PREFERENCE_PASSWORD, password)

            editor.apply()
            setResult(Activity.RESULT_OK)
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val toolbar = findViewById(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)

        authSystem = intent.getParcelableExtra<AuthSystem>(EXTRA_AUTH_SYSTEM)

        usernameView = findViewById(R.id.email) as AutoCompleteTextView

        passwordView = findViewById(R.id.password) as EditText
        passwordView!!.setOnEditorActionListener(TextView.OnEditorActionListener { textView, id, keyEvent ->
            if (id == R.id.login || id == EditorInfo.IME_NULL) {
                attemptLogin()
                return@OnEditorActionListener true
            }
            false
        })

        autoFillForm()

        loginButton = findViewById(R.id.email_sign_in_button) as Button
        loginButton!!.setOnClickListener { attemptLogin() }

        progressView = findViewById(R.id.login_progress)

        val app = application as AmeliaApplication
        ameliaChat = app.ameliaChat
        ameliaChat!!.addSessionListener(setupListener)

        setResult(Activity.RESULT_CANCELED)
    }

    public override fun onDestroy() {
        super.onDestroy()
        ameliaChat!!.removeSessionListener(setupListener)
    }


    private fun autoFillForm() {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this@LoginActivity)
        val email = sharedPreferences.getString(PREFERENCE_EMAIL, "")
        val password = sharedPreferences.getString(PREFERENCE_PASSWORD, "")
        usernameView!!.setText(email)
        passwordView!!.setText(password)
    }

    private fun attemptLogin() {

        usernameView!!.error = null
        passwordView!!.error = null

        val email = usernameView!!.text.toString()
        val password = passwordView!!.text.toString()

        var cancel = false
        var focusView: View? = null

        if (!TextUtils.isEmpty(password) && !isPasswordValid(password)) {
            passwordView!!.error = getString(R.string.error_invalid_password)
            focusView = passwordView
            cancel = true
        }

        if (TextUtils.isEmpty(email)) {
            usernameView!!.error = getString(R.string.error_field_required)
            focusView = usernameView
            cancel = true
        } else if (!isEmailValid(email)) {
            usernameView!!.error = getString(R.string.error_invalid_email)
            focusView = usernameView
            cancel = true
        }

        if (cancel) {
            focusView!!.requestFocus()
        } else {
            showProgress(true)
            val options = LoginOptions(authSystem, email, password)
            ameliaChat!!.login(options)
        }
    }

    private fun isEmailValid(email: String): Boolean {
        return true
    }

    private fun isPasswordValid(password: String): Boolean {
        return true
    }


    private fun showProgress(show: Boolean) {
        loginButton!!.isEnabled = !show
        progressView!!.visibility = if (show) View.VISIBLE else View.GONE
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                setResult(Activity.RESULT_CANCELED)
                finish()
                return true
            }
        }
        return false
    }

    companion object {

        val PREFERENCE_EMAIL = "email"
        val PREFERENCE_PASSWORD = "password"
        val EXTRA_AUTH_SYSTEM = "auth_system"
    }

}

