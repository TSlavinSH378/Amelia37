package com.ipsoft.amelia.sampleapp

import net.ipsoft.amelia.sdk.AmeliaOutboundMessage
import net.ipsoft.amelia.sdk.BaseConversationListener

import java.util.ArrayList

class ChatHistory : BaseConversationListener() {

    private val chatRecords = ArrayList<ChatRecord>()

    val records: List<ChatRecord>
        get() = chatRecords

    override fun onChatHistoryClear() {
        chatRecords.clear()
    }

    override fun outboundFinalTextMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundProgressTextMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundIdleTalkMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun wolframAlphaFinalMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundEchoMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundFinalErrorMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundConversationClosedMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundSessionClosedMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundIntegrationMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundAgentSessionChangedMessage(ameliaOutboundMessage: AmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun onUploadRequest(message: AmeliaOutboundMessage?) {
        chatRecords.add(UploadChatRecord(message!!))
    }

    override fun outboundMmoDownloadMessage(message: AmeliaOutboundMessage) {
        chatRecords.add(DownloadChatRecord(message))
    }
}
