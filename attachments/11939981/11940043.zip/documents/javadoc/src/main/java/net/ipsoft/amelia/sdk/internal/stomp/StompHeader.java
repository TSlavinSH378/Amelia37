package net.ipsoft.amelia.sdk.internal.stomp;

public class StompHeader {


    public static final String ACCEPT_VERSION  = "accept-version";
    public static final String CONTENT_LENGTH  = "content-length";
    public static final String CONTENT_TYPE    = "content-type";
    public static final String ID              = "id";
    public static final String DESTINATION     = "destination";
    public static final String ACK             = "ack";
    public static final String SUBSCRIPTION    = "subscription";
    public static final String MESSAGE_ID      = "message-id";
    public static final String TRANSACTION     = "transaction";
    public static final String RECEIPT         = "receipt";
    public static final String RECEIPT_ID      = "receipt-id";
    public static final String MESSAGE         = "message";

    public final String name;
    public final String value;

    public StompHeader(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public static StompHeader withAcceptVersion(String acceptVersion) {
        return new StompHeader(ACCEPT_VERSION, acceptVersion);
    }

    public static StompHeader withContentLength(int contentLength) {
        return new StompHeader(CONTENT_LENGTH, String.valueOf(contentLength));
    }

    public static StompHeader withContentType(String contentType) {
        return new StompHeader(CONTENT_TYPE, contentType);
    }

    public static StompHeader withId(String id) {
        return new StompHeader(ID, id);
    }

    public static StompHeader withDestination(String destination) {
        return new StompHeader(DESTINATION, destination);
    }

    public static StompHeader withAck(String ack) {
        return new StompHeader(ACK, ack);
    }

    public static StompHeader withSubscription(String subscription) {
        return new StompHeader(SUBSCRIPTION, subscription);
    }

    public static StompHeader withMessageId(String messageId) {
        return new StompHeader(MESSAGE_ID, messageId);
    }

    public static StompHeader withTransaction(String transaction) {
        return new StompHeader(TRANSACTION, transaction);
    }

    public static StompHeader withReceipt(String receipt) {
        return new StompHeader(RECEIPT, receipt);
    }

    public static StompHeader withReceiptId(String receiptId) {
        return new StompHeader(RECEIPT_ID, receiptId);
    }

    public static StompHeader withMessage(String message) {
        return new StompHeader(MESSAGE, message);
    }

    public String serialize() {
        StringBuilder builder = new StringBuilder();
        builder.append(escape(name)).append(':').append(escape(value));
        return builder.toString();
    }

    public static StompHeader deserialize(String header) throws StompException {
        String[] fields = header.split(":", 2);
        if (fields.length == 2) {

            String name = unescape(fields[0]);
            String value = unescape(fields[1]);

            return new StompHeader(name, value);
        }
        throw new StompException("Unable to parse stomp header: " + header);
    }

    private static String escape(String string) {
        String escaped = string.replace("\\", "\\\\");
        escaped = escaped.replace(":", "\\c");
        escaped = escaped.replace("\n", "\\n");
        return escaped;
    }

    private static String unescape(String string) {
        String unescaped = string.replace("\\", "\\\\");
        unescaped = unescaped.replace(":", "\\c");
        unescaped = unescaped.replace("\n", "\\n");
        return unescaped;
    }

    public boolean isContentLength() {
        return CONTENT_LENGTH.equals(name);
    }
}
