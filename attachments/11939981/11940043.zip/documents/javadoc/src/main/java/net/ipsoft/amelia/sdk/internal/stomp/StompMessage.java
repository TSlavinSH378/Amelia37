package net.ipsoft.amelia.sdk.internal.stomp;

public abstract class StompMessage {
}
