package net.ipsoft.amelia.sdk;

import net.ipsoft.amelia.sdk.internal.common.AmeliaChat;

public interface IConversationListener {
    /**
     * Callback for when user input contains secret and needs to be masked
     * @param enabled
     */
    void onSecureInputEnabledChanged(boolean enabled);

    /**
     * Callback when the emotional state of Amelia has changed
     *
     * @param newMood Amelia's new mood
     * @param oldMood Amelia's previous mood
     */
    void onMoodChange(String newMood, String oldMood);

    /**
     * An indication to the UI to enable/disable input controls
     *
     * @param enabled true when input controls are expected to be enabled
     * @param messageType
     * @param reason
     */
    void onInputEnabledChanged(boolean enabled, String messageType, IAmeliaChat.InputStateChangeReason reason);

    /**
     * A message from a Amelia was received. This is the raw message, clients are typically not
     * interested in this callback. Consider the <code>outboundXx</code> callbacks instead.
     * @param message the raw message
     */
    void onMessageReceived(String message);

    /**
     * Callback when a user input is attempted when a Amelia will not accept input
     *
     * @see #onInputEnabledChanged(boolean, String, IAmeliaChat.InputStateChangeReason)
     */
    void onErrorInputBlocked();

    /**
     * Callback when chat history has been cleared, either because the conversation was ended
     * or a client cleared it explicitly.
     */
    void onChatHistoryClear();

    /**
     * Callback when the connection to Amelia is established, but before the conversation has started
     */
    void onConnect();

    /**
     * Callback when the connection to Amelia goes down unexpectedly
     */
    void onDisconnect();

    /**
     * Callback when the connection to Amelia is established again after {@link #onDisconnect()}
     */
    void onReconnect();

    /**
     * Callback when Amelia playback has started
     */
    void onSpeakStart();

    /**
     * Callback when Amelia playback has ended
     */
    void onSpeakEnd();


    /**
     * OutboundFinalTextMessage will fire when Amelia says text at the conclusion of a typical process.
     * <p>
     * OutboundFinalTextMessage may have a formInputData attribute, which can be used to construct custom form widgets.
     * <p>
     * This is typically the type of message you want to echo into your chat UI.
     *
     * @param ameliaOutboundMessage
     */
    void outboundFinalTextMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * OutboundProgressTextMessage will fire when Amelia says when it is in the middle of a process.
     * <p>
     * This is typically the type of message you want to echo into your chat UI.
     * <p>
     * It will most often not have X-Amelia-Input-Enabled set to 'true', as most UIs will want to
     * keep the input disabled until Amelia has concluded its process.
     *
     * @param ameliaOutboundMessage
     */
    void outboundProgressTextMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * A social message Amelia could send if it detects the user is idle.
     * <p>
     * This is typically the type of message you want to echo into your chat UI.
     *
     * @param ameliaOutboundMessage
     */
    void outboundIdleTalkMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * A message Amelia sends when it detects the user is idle, but has no social messages
     * configured. This will not have any {@link AmeliaOutboundMessage#getMessageText()}, so it is
     * typically not useful to update the chat window itself, though a UI can listen for this event
     * to detect when the user has gone into an idle state.
     *
     * @param ameliaOutboundMessage
     */
    void outboundNoIdleTalkMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * WolframAlphaFinalMessage will fire when Amelia says text at the conclusion of a request made to WolframAlpha.
     * <p>
     * This is typically the type of message you want to echo into your chat UI.
     *
     * @param ameliaOutboundMessage
     */
    void wolframAlphaFinalMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * OutboundFinalErrorMessage will fire when Amelia encounters an unexpected error in the pipeline.
     * <p>
     * This is typically the type of message you want to echo into your chat UI.
     *
     * @param ameliaOutboundMessage
     */
    void outboundFinalErrorMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * Sent from Amelia in response to an {@link AmeliaChat#endConversation()}
     *
     * @param ameliaOutboundMessage
     */
    void outboundConversationClosedMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * OutboundIntegrationMessage will fire when Amelia requests the assembly of a section widgets
     * for working with another system.
     *
     * @param ameliaOutboundMessage
     */
    void outboundIntegrationMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * A message Amelia sends when the user session is closed. It will contain some
     * {@link AmeliaOutboundMessage#getMessageText()}, so you may use it to update the chat box as
     * well as to inform other components of your UI that the session has terminated.
     *
     * @param ameliaOutboundMessage
     */
    void outboundSessionClosedMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * An echo of a user response. Used to populate the user side of a chat.
     *
     * @param ameliaOutboundMessage
     */
    void outboundEchoMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * A message indicating files are available for download, the
     * {@link AmeliaOutboundMessage#downloadMessage} is set.
     *
     * @param ameliaOutboundMessage
     */
    void outboundMmoDownloadMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * Callback when an upload is requested
     *
     * @param ameliaOutboundMessage
     */
    void onUploadRequest(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * Callback when an upload succeeds
     *
     * @param fromUserDisplayName the display name of the user requesting
     * @param fileName the filename of the uploaded file
     * @param url the url of the uploaded file
     */
    void onUploadSuccess(String fromUserDisplayName, String fileName, String url);

    /**
     * Callback when an upload fails
     *
     * @param fromUserDisplayName the display name of the user requesting
     * @param fileName the filename of the uploaded file
     * @param fileType the type of file requested in the upload
     */
    void onUploadFailed(String fromUserDisplayName, String fileName, String fileType);

    /**
     * A message Amelia sends to request acknowledgment from the client that it is still there.
     * It typically contains no messageText, so is not useful for updating the chat box directly.
     * AmeliaChat will send responses automatically to preserve the conversation, but after the
     * configured idle wait time it will also notify Amelia that the user has gone idle.
     * Typically, the automated responses are enough, though you may listen to this event if you
     * need another portion of your UI to respond to an ack request.
     *
     * @param ameliaOutboundMessage
     */
    void outboundAckRequestMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * An agent has taken over the conversation.
     *
     * This is typically the type of message you want to echo into your chat UI.
     *
     * @param ameliaOutboundMessage
     */
    void outboundAgentSessionChangedMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     *
     * @param ameliaOutboundMessage
     */
    void outboundFinalReplayMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * Escalation started, waiting for an agent to pick up
     *
     * @param ameliaOutboundMessage
     */
    void outboundEscalationStartedMessage(AmeliaOutboundMessage ameliaOutboundMessage);

    /**
     * Generic outbound message called for every time an Amelia message is received, regardless
     * of type. Use this when a particular action is available for all or a subset of all messages.
     *
     * @param ameliaOutboundMessage
     */
    void outboundAmeliaMessage(AmeliaOutboundMessage ameliaOutboundMessage);
}
