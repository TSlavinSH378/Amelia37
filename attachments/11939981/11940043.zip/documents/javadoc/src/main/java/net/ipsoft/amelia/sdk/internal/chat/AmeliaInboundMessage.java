package net.ipsoft.amelia.sdk.internal.chat;

import android.util.JsonWriter;

import java.io.IOException;

public class AmeliaInboundMessage {
    protected String messageText = null;
    protected boolean secure = false;
    protected AmeliaInboundMessageAttributes attributes = null;

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public void setSecure(boolean secure){
        this.secure = secure;
    }

    public boolean isSecure(){
        return secure;
    }

    public AmeliaInboundMessageAttributes getAttributes() {
        return attributes;
    }

    public void setAttributes(AmeliaInboundMessageAttributes attributes) {
        this.attributes = attributes;
    }

    @Override
    public String toString() {
        return "{ " + "messageText: " + messageText + ", " + "attributes: " + (attributes == null ? null : attributes.hashCode()) + ", isSecure: "+isSecure()+" }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (messageText != null) {
            jsonWriter.name("messageText");
            jsonWriter.value(messageText);
        }
        if (attributes != null) {
            jsonWriter.name("attributes");
            attributes.serialize(jsonWriter);
        }
        jsonWriter.name("isSecure").value(secure?"true":"false");
        jsonWriter.endObject();
    }

}