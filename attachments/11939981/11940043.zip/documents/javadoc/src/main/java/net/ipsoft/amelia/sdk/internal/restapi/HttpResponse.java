package net.ipsoft.amelia.sdk.internal.restapi;

import android.content.Context;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;


public class HttpResponse {

    protected String mimeType;
    protected HttpError error;
    protected boolean cancelled;

    public HttpResponse() {}

    public void deserialize(Reader reader) throws IOException {}

    public void deserialize(InputStream inputStream) throws IOException {}

    public void deserialize(String string) {}

    public void run() {}

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public void setError(HttpError error) {
        this.error = error;
    }

    public void cancel() {
        cancelled = true;
    }

    public void setCookies(String cookies){}

    @Override
    public String toString() {
        return "{ " + "error: " + error + " }";
    }
}
