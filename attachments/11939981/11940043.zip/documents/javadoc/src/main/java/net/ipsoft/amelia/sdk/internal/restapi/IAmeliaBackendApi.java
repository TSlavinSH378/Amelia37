package net.ipsoft.amelia.sdk.internal.restapi;

import java.util.List;

public interface IAmeliaBackendApi {

    void setCallback(Callback callback);

    void initReq();

    void whoAmIReq(String xCsrfToken);

    void checkSessionRequest(String xCsrfToken);

    void authSystems();

    void anonymousAllowedReq(String xCsrfToken);

    void anonymousCreateReq(String xCsrfToken);

    void loginReq(LoginReq loginReq);

    void logoutReq();

    void domainsReq(String xCsrfToken);

    void newConversationReq(NewConversationReq newConversationReq);

    String baseUrl();

    boolean addCookies(String cookies);

    void clearCookies();

    interface Callback {

        void initRsp(InitRsp initRsp);


        void whoAmIRsp(WhoAmIRsp whoAmIRsp);

        void checkSessionRsp(CheckRsp checkRsp);

        void authSystems(AuthSystemsRsp authSystemsRsp);

        void anonymousAllowedRsp(AnonymousAllowedRsp anonymousAllowedRsp);

        void anonymousCreateRsp(AnonymousCreateRsp anonymousCreateRsp);

        void loginRsp(LoginRsp loginRsp);

        void logoutRsp(LogoutRsp logoutRsp);

        void domainsRsp(DomainsRsp domainsRsp);

        void newConversationRsp(NewConversationRsp newConversationRsp);
    }
}
