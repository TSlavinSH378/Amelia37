package net.ipsoft.amelia.sdk;

import android.content.Context;
import android.net.Uri;

import net.ipsoft.amelia.sdk.internal.common.Conversation;
import net.ipsoft.amelia.sdk.internal.restapi.FileMetadata;
import net.ipsoft.amelia.sdk.internal.restapi.HttpRequestProcessor;
import net.ipsoft.amelia.sdk.internal.restapi.MmoDownloadReq;
import net.ipsoft.amelia.sdk.internal.restapi.MmoDownloadRsp;
import net.ipsoft.amelia.sdk.internal.restapi.MmoMetadata;
import net.ipsoft.amelia.sdk.internal.restapi.MmoMetadataReq;
import net.ipsoft.amelia.sdk.internal.restapi.MmoMetadataRsp;

import java.io.File;

/**
 * Encapsulation of an MMO download message. Information about available files and their metadata
 * is exposed as well as utilities to download listed files.
 */
public class DownloadMessage {

    private String key;
    private HttpRequestProcessor httpRequestProcessor;
    private Conversation conversation;
    private MmoMetadata metadata;
    private AmeliaError recentError;
    private DownloadedMmo[] downloads;

    public DownloadMessage(HttpRequestProcessor httpRequestProcessor, Conversation conversation, String key) {
        this.key = key;
        this.conversation = conversation;
        this.httpRequestProcessor = httpRequestProcessor;
    }

    /**
     * Download a file at a given position from the list of files exposed via {@link #getMetadata()}.
     * If {@link #getMetadata()} returns <code>null</code>, metadata must be fetched using
     * {@link #fetchMetadata(OnMetadataFetchedListener)}. Downloaded files will end up in
     * the app's temporary file storage area as returned by {@link Context#getCacheDir()}.
     *
     * @param position position in the list of available MMOs
     * @param downloadListener listener monitor download progress
     * @param context context necessary to access file system
     */
    public void download(final int position, final IDownloadListener downloadListener, Context context) {
        download(position, downloadListener, context.getCacheDir());
    }

    /**
     * Download a file at a given position from the list of files exposed via {@link #getMetadata()}.
     * If {@link #getMetadata()} returns <code>null</code>, metadata must be fetched using
     * {@link #fetchMetadata(OnMetadataFetchedListener)}.
     *
     * NOTE: it is the responsibility of the client to ensure the app has been granted permissions
     * to write files to the supplied <code>downloadFolder</code>
     *
     * @param position position in the list of available MMOs
     * @param downloadListener listener monitor download progress
     * @param downloadFolder download location
     */
    public void download(final int position, final IDownloadListener downloadListener, File downloadFolder) {

        if (!"file".equals(metadata.getType())) {
            downloadListener.onDownloadFailed(new AmeliaError(AmeliaError.Code.invalidContent, "Unable to download type: " + metadata.getType()));
            return;
        }

        FileMetadata fileMetadata = metadata.getValue().get(position);
        final File file = new File(downloadFolder, fileMetadata.getName());

        httpRequestProcessor.send(new MmoDownloadReq(fileMetadata.getId(), conversation), new MmoDownloadRsp(file) {
            @Override
            public void run() {
                if (error == null) {
                    Uri uri = Uri.fromFile(file);
                    DownloadedMmo downloadedMmo = new DownloadedMmo(uri, mimeType);
                    downloads[position] = downloadedMmo;
                    downloadListener.onDownloadSuccess(downloadedMmo);
                } else {
                    DownloadedMmo downloadedMmo = new DownloadedMmo(new AmeliaError(error, "Failed to download MMO at index: " + position));
                    downloads[position] = downloadedMmo;
                    downloadListener.onDownloadFailed(downloadedMmo.recentError);
                }
            }
        });
    }

    /**
     * One attempt to fetch metadata is made before this class is instantiated, but if it fails
     * {@link #getMetadata()} will return <code>null</code> and {@link #getRecentError(int)} describes
     * the error that occurred. Call this method to retry fetching metadata.
     *
     * @param listener callback when metadata is fetched
     */
    public void fetchMetadata(final OnMetadataFetchedListener listener) {
        httpRequestProcessor.send(new MmoMetadataReq(conversation.xCsrfToken, key, conversation.conversationId), new MmoMetadataRsp() {
            @Override
            public void run() {
                if (error == null) {
                    recentError = null;
                    DownloadMessage.this.metadata = mmoMetadata;
                    DownloadMessage.this.downloads = new DownloadedMmo[mmoMetadata.getValue().size()];
                } else {
                    recentError = new AmeliaError(error, "Failed fetching metadata");
                }
                listener.onMetadataFetched();
            }
        });
    }

    /**
     * Gets the fetch metadata, call {@link #fetchMetadata(OnMetadataFetchedListener)} if this returns
     * <code>null</code>.
     *
     * @return metadata describing available MMOs
     */
    public MmoMetadata getMetadata() {
        return metadata;
    }

    public AmeliaError getError() {
        return recentError;
    }

    /**
     * Gets the uri of the downloaded MMO at the given position
     *
     * @param position position in the list of available MMOs
     * @return uri of downloaded MMO
     */
    public Uri getUri(int position) {
        if (downloads[position] != null) {
            return downloads[position].uri;
        }
        return null;
    }

    /**
     * Gets the mimeType of the downloaded MMO at the given position
     *
     * @param position position in the list of available MMOs
     * @return mimeType of the downloaded MMO
     */
    public String getMimeType(int position) {
        if (downloads[position] != null) {
            return downloads[position].mimeType;
        }
        return null;
    }


    /**
     * Gets the recent error when trying to download the MMO at the given position
     *
     * @param position position in the list of available MMOs
     * @return recent error when downloading the MMO
     */
    public AmeliaError getRecentError(int position) {
        if (downloads[position] != null) {
            return downloads[position].recentError;
        }
        return null;
    }

    public interface IDownloadListener {

        /**
         * Download failed
         *
         * @param error error
         */
        void onDownloadFailed(AmeliaError error);

        /**
         * Download succeeded
         *
         * @param mmo metadata describing the downloaded MMO
         */
        void onDownloadSuccess(DownloadedMmo mmo);
    }

    public interface OnMetadataFetchedListener {
        void onMetadataFetched();
    }

}
