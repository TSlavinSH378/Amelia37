package net.ipsoft.amelia.sdk.internal.restapi;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import java.io.IOException;

public class AnonymousAllowedRspData {
    protected String anonynousAllowed = null;

    public String getAnonynousAllowed() {
        return anonynousAllowed;
    }

    public void setAnonynousAllowed(String anonynousAllowed) {
        this.anonynousAllowed = anonynousAllowed;
    }

    @Override
    public String toString() {
        return "{ " + "anonynousAllowed: " + anonynousAllowed + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (anonynousAllowed != null) {
            jsonWriter.name("anonynousAllowed");
            jsonWriter.value(anonynousAllowed);
        }
        jsonWriter.endObject();
    }

    public static AnonymousAllowedRspData deserialize(JsonReader jsonReader) throws IOException {
        AnonymousAllowedRspData anonymousAllowedRspData = new AnonymousAllowedRspData();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("anonynousAllowed" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                anonymousAllowedRspData.setAnonynousAllowed(jsonReader.nextString());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return anonymousAllowedRspData;
    }
}