package net.ipsoft.amelia.sdk.internal.chat;

import net.ipsoft.amelia.sdk.AmeliaError;
import net.ipsoft.amelia.sdk.AmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.internal.common.Conversation;
import net.ipsoft.amelia.sdk.FormInputData;

public interface IAmeliaStompApi {

    void setChatListener(Callback chatListener);
    void startConversation(Conversation conversation);
    void ask(String messageText,boolean secure);
    void endConversationReq();
    void send(String messageType);
    void send(String messageText, String messageType);
    void sendSecure(String messageText,String messageType);
    void submitForm(FormInputData form, String messageText);
    void runAction(String processName, String argumentsJson, String messageText);

    interface Callback {
        void onSend(String messageType);
        void onConnect();
        void onReconnect();
        void onDisconnect();
        void endConversationRsp();

        void sessionFail(AmeliaError error);
        void onMessage(String text, AmeliaOutboundMessage ameliaOutboundMessage);
    }
}
