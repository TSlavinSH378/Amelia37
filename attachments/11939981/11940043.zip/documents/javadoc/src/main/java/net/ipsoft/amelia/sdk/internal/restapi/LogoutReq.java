package net.ipsoft.amelia.sdk.internal.restapi;

public class LogoutReq extends HttpRequest {

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/api/logout";
    }
}