package net.ipsoft.amelia.sdk;

public class UploadMessage {

    /*
     * Type of file requested by Amelia
     */
    public final String fileType;
    private AmeliaError recentError;
    private boolean isUploaded;

    public UploadMessage(String fileType) {
        this.fileType = fileType;
    }

    /**
     * Error from the most recently failed upload attempt, if any
     *
     * @return error
     */
    public AmeliaError getRecentError() {
        return recentError;
    }

    public void setRecentError(AmeliaError recentError) {
        this.recentError = recentError;
    }

    /**
     * Returns <code>true</code> if file has been successfully uploaded, <code>false</code> otherwise
     *
     * @return upload status
     */
    public boolean isUploaded() {
        return isUploaded;
    }

    public void setUploaded(boolean uploaded) {
        isUploaded = uploaded;
    }

}
