package net.ipsoft.amelia.sdk.internal.restapi;

import java.io.IOException;
import java.util.ArrayList;

import android.util.JsonWriter;
import android.util.JsonReader;
import android.util.JsonToken;
import android.util.Log;

import net.ipsoft.amelia.sdk.AmeliaUser;

import org.json.JSONObject;

public class LoginRspData {
    protected boolean expirationWarning = false;
    protected boolean success = false;
    protected AmeliaUser ameliaUser;

    public boolean getExpirationWarning() {
        return expirationWarning;
    }

    public void setExpirationWarning(boolean expirationWarning) {
        this.expirationWarning = expirationWarning;
    }

    public boolean getSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    @Override
    public String toString() {
        return "{ " + "expirationWarning: " + expirationWarning + ", " + "success: " + success + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        jsonWriter.name("expirationWarning");
        jsonWriter.value(expirationWarning);
        jsonWriter.name("success");
        jsonWriter.value(success);
        jsonWriter.endObject();
    }

    public static LoginRspData deserialize(JsonReader jsonReader) throws IOException {
        LoginRspData loginRspData = new LoginRspData();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("expirationWarning" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                loginRspData.setExpirationWarning(jsonReader.nextBoolean());
            }
            else if("user" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                loginRspData.ameliaUser=new AmeliaUser();
                loginRspData.setSuccess(true);
                jsonReader.beginObject();
                while(jsonReader.hasNext()){
                    name = jsonReader.nextName();
                    if ("userId" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                        loginRspData.ameliaUser.setUserId( jsonReader.nextString());
                    }else if("email".equals(name)&&jsonReader.peek() !=JsonToken.NULL)   {
                        loginRspData.ameliaUser.setEmail(jsonReader.nextString());
                    }else if("name".equals(name)&&jsonReader.peek()!=JsonToken.NULL){
                        loginRspData.ameliaUser.setName(jsonReader.nextString());
                    }else if("anonymous".equals(name)&&jsonReader.peek()!=JsonToken.NULL){
                        loginRspData.ameliaUser.setAnonymous(jsonReader.nextBoolean());
                    }else if("agent".equals(name)&&jsonReader.peek()!=JsonToken.NULL){
                        loginRspData.ameliaUser.setAgent(jsonReader.nextBoolean());
                    }else if("domains".equals(name)&&jsonReader.peek()!=JsonToken.NULL)
                    {
                        ArrayList<String> domains = new ArrayList<>();
                        jsonReader.beginObject();
                        while (jsonReader.hasNext()) {
                            domains.add(jsonReader.nextString());
                        }
                        jsonReader.endObject();
                        loginRspData.ameliaUser.setDomains(domains);
                    }
                    else if("domainCodes".equals(name)&&jsonReader.peek()!=JsonToken.NULL){
                        ArrayList<String> domainCodes = new ArrayList<>();
                        jsonReader.beginObject();
                        while (jsonReader.hasNext()) {
                            domainCodes.add(jsonReader.nextString());
                        }
                        jsonReader.endObject();
                        loginRspData.ameliaUser.setDomainCodes(domainCodes);
                    }else if("domainAuthorities".equals(name)&&jsonReader.peek()!=JsonToken.NULL){
                        ArrayList<String> domainAuthorities = new ArrayList<>();
                        jsonReader.beginObject();
                        while(jsonReader.hasNext()){
                            domainAuthorities.add(jsonReader.nextString());
                        }
                        jsonReader.endObject();
                        loginRspData.ameliaUser.setDomainAuthorities(domainAuthorities);
                    }else if("globalAuthorities".equals(name)&&jsonReader.peek()!=JsonToken.NULL){
                        ArrayList<String> globalAuthorities=new ArrayList<>();
                        jsonReader.beginArray();
                        while(jsonReader.hasNext()){
                            globalAuthorities.add(jsonReader.nextString());
                        }
                        jsonReader.endArray();
                        loginRspData.ameliaUser.setGlobalAuthorities(globalAuthorities);
                    }
                    else{
                        jsonReader.skipValue();
                    }
                }
                jsonReader.endObject();
            }
            else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return loginRspData;
    }

}