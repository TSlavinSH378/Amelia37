package net.ipsoft.amelia.sdk.internal.restapi;

import android.util.JsonReader;

import java.io.IOException;
import java.io.Reader;

public class GenerateSpeechRsp extends HttpResponse {

    public GenerateSpeechRspData data = null;

    @Override
    public String toString() {
        return "{ " + "data: " + data + ", " + "error: " + error + " }";
    }

    public void deserialize(Reader reader) throws IOException {
        JsonReader jsonReader = new JsonReader(reader);
        data = GenerateSpeechRspData.deserialize(jsonReader);
    }
}