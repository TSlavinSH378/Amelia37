package net.ipsoft.amelia.sdk.internal.restapi;

import org.json.JSONObject;

import java.util.LinkedHashMap;

import okhttp3.Request;

public class GenerateSpeechReq extends HttpRequest {

    public String text = null;
    public String voice = null;
    public String conversationId = null;
    public String character;

    public GenerateSpeechReq(String text, String voice,String conversationId) {
        this.text = text;
        this.voice = voice;
        this.conversationId = conversationId;
        this.character = "Amelia";
        this.contentType = "application/json;charset=utf-8";
    }

    @Override
    public String toString() {
        return "{ " + "text: " + text + ", " + "voice: " + voice + "character:"+character+"conversationId"+conversationId+" }";
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/api/speech/generate";
    }

    public JSONObject getJSONObject(){
        if(jsonObject == null){
            jsonObject = new JSONObject();
            try {
                jsonObject.put("text",text);
                jsonObject.put("voice",voice);
                jsonObject.put("character","Amelia");
                jsonObject.put("conversationId",conversationId);
            } catch(Exception ignore){}
        }
        return jsonObject;
    }

}