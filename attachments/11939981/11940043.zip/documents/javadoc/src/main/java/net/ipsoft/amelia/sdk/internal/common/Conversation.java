package net.ipsoft.amelia.sdk.internal.common;


/**
 * Representation of an ongoing conversation
 */
public class Conversation {

    public final String xCsrfToken;
    public final String sessionId;
    public final String conversationId;

    public Conversation(String xCsrfToken, String sessionId, String conversationId) {
        this.sessionId = sessionId;
        this.conversationId = conversationId;
        this.xCsrfToken = xCsrfToken;
    }

}
