package net.ipsoft.amelia.sdk.internal.restapi;

public class AnonymousCreateRsp extends HttpResponse {


}