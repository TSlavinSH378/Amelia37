package net.ipsoft.amelia.sdk.internal.restapi;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;

import net.ipsoft.amelia.sdk.AmeliaError;
import net.ipsoft.amelia.sdk.AmeliaUser;
import net.ipsoft.amelia.sdk.AuthSystem;
import net.ipsoft.amelia.sdk.Domain;
import net.ipsoft.amelia.sdk.LoginOptions;
import net.ipsoft.amelia.sdk.internal.common.ALog;
import net.ipsoft.amelia.sdk.internal.common.AmeliaConfig;
import net.ipsoft.amelia.sdk.internal.common.Conversation;
import net.ipsoft.amelia.sdk.internal.common.Provider;

import java.util.List;

public class SessionHandler {

    private String xCsrfToken = null;
    private Boolean anonymousAllowed = null;
    private AmeliaConfig config = null;
    private IAmeliaBackendApi ameliaBackendApi = null;
    private Conversation conversation;
    private String languageCode;
    private List<Domain> domains;
    private Domain domain = null;
    private List<AuthSystem> authSystems;
    private Context appContext;

    private State currentState = State.inactive;

    private Callback listener;

    private LoginOptions deferredLoginOptions;
    private DeferredEndConversationAction deferredEndConversationAction = DeferredEndConversationAction.none;
    private AmeliaUser ameliaUser;


    public SessionHandler(Context appContext,AmeliaConfig config, Provider provider, Callback callback) {
        this.config = config;
        this.ameliaBackendApi = provider.getAmeliaBackendApi();
        this.ameliaBackendApi.setCallback(ameliaApiListener);
        this.listener = callback;
        this.languageCode = config.languageCode;
        this.appContext = appContext;
    }

    public void activate() {
        currentState = State.loggedOut;
    }

    public void prepareLogin() {
        switch (currentState) {
            case inConversation:
                deferredEndConversationAction = DeferredEndConversationAction.prepareLogin;
                listener.endConversation();
                break;
            case loggedOut:
            case loggedIn:
                handlePrepareLogin();
                break;
            default:
                ALog.w("amelia", "prepareLogin() not supported in state: " + currentState);
                break;
        }

    }

    public void login(LoginOptions loginOptions) {
        switch (currentState) {
            case loggedOut:
                initiateLogin(loginOptions);
                break;
            case loggedIn:
                if (ameliaUser.isAnonymous()) {
                    domains = null;
                    initiateLogin(loginOptions);
                } else {
                    ALog.w("amelia", "Attempt to login already logged in user");
                }
                break;
            case inConversation:
                if (ameliaUser.isAnonymous()) {
                    domains = null;
                    deferredLoginOptions = loginOptions;
                    deferredEndConversationAction = DeferredEndConversationAction.login;
                    listener.endConversation();
                } else {
                    ALog.w("amelia", "Attempt to login already logged in user");
                }
                break;
            default:
                ALog.w("amelia", "login() not supported in state: " + currentState);
                break;
        }
    }

    public void logout() {
        switch (currentState) {
            case loggedIn:
                doLogout();
                break;
            case inConversation:
                deferredEndConversationAction = DeferredEndConversationAction.logout;
                SessionUtil.deletePersistedCookies(appContext);
                listener.endConversation();
                break;
            default:
                ALog.w("amelia", "logout() not supported in state: " + currentState);
                break;
        }
    }

    public void newConversationReq(Domain domain) {
        switch (currentState) {
            case loggedOut:
                newConversationWhileLoggedOut();
                break;
            case loggedIn:
                this.domain = domain;
                newConversationWhileLoggedIn();
                break;
            case inConversation:
                this.domain = domain;
                deferredEndConversationAction = DeferredEndConversationAction.newConversation;
                listener.endConversation();
                break;
            case pendingEndConversation:
                this.domain = domain;
                deferredEndConversationAction = DeferredEndConversationAction.newConversation;
                break;
            default:
                ALog.w("amelia", "selectDomain(Domain) not supported in state: " + currentState);
                break;
        }
    }

    public void endConversation() {
        switch (currentState) {
            case inConversation:
                currentState = State.pendingEndConversation;
                listener.endConversation();
                break;
            default:
                ALog.w("amelia", "endConversation() not supported in state: " + currentState);
                break;
        }
    }

    public void conversationEnded() {
        switch (currentState) {
            case inConversation:
                conversation = null;
                currentState = State.loggedIn;
                break;
            case pendingEndConversation:
                conversation = null;
                currentState = State.loggedIn;
                switch (deferredEndConversationAction) {
                    case logout:
                        doLogout();
                        break;
                    case prepareLogin:
                        handlePrepareLogin();
                        break;
                    case login:
                        initiateLogin(deferredLoginOptions);
                        break;
                    case newConversation:
                        newConversationWhileLoggedIn();
                        break;
                }
                deferredEndConversationAction = DeferredEndConversationAction.none;
                break;
            default:
                ALog.w("amelia", "endConversation() not supported in state: " + currentState);
                break;
        }
    }

    private AmeliaRestApi.Callback ameliaApiListener = new AmeliaRestApi.Callback() {

        @Override
        public void initRsp(InitRsp initRsp) {
            switch (currentState) {
                case pendingAnonymousInit:
                    handleAnonymousInit(initRsp);
                    break;
                case pendingLoginInit:
                    handleLoginInit(initRsp);
                    break;
                case pendingUserInit:
                    handleUserInit(initRsp);
                    break;
                default:
                    ALog.w("amelia", "/init not supported in state: " + currentState);
                    break;
            }
        }

        @Override
        public void whoAmIRsp(WhoAmIRsp whoAmIRsp) {
            switch (currentState) {
                case pendingWhoAmI:
                    handleWhoAmI(whoAmIRsp);
                    break;
                default:
                    ALog.w("amelia", "/whoAmI not supported in state: " + currentState);
                    break;
            }
        }

        @Override
        public void checkSessionRsp(CheckRsp checkRsp) {
            switch (currentState) {
                case pendingSessionCheck:
                    handleSessionCheck(checkRsp);
                    break;
                default:
                    ALog.w("amelia", "/httpSession/check not supported in state: " + currentState);
                    break;
            }
        }

        @Override
        public void authSystems(AuthSystemsRsp authSystemsRsp) {
            switch (currentState) {
                case pendingAuthSystems:
                    handleAuthSystems(authSystemsRsp);
                    break;
                default:
                    ALog.w("amelia", "/whoAmI not supported in state: " + currentState);
                    break;
            }
        }

        @Override
        public void anonymousAllowedRsp(AnonymousAllowedRsp anonymousAllowedRsp) {
            switch (currentState) {
                case pendingAnonymousAllowed:
                    handleAnonymousAllowed(anonymousAllowedRsp);
                    break;
                default:
                    ALog.w("amelia", "/anonymous/allowed not supported in state: " + currentState);
                    break;
            }
        }

        @Override
        public void anonymousCreateRsp(AnonymousCreateRsp anonymousCreateRsp) {
            switch (currentState) {
                case pendingCreateAnon:
                    handleAnonymousCreate(anonymousCreateRsp);
                    break;
                default:
                    ALog.w("amelia", "/anonymous/create not supported in state: " + currentState);
                    break;
            }
        }

        @Override
        public void loginRsp(LoginRsp loginRsp) {
            switch (currentState) {
                case pendingLogin:
                    handleLogin(loginRsp);
                    break;
                default:
                    ALog.w("amelia", "/login not supported in state: " + currentState);
                    break;
            }
        }

        @Override
        public void logoutRsp(LogoutRsp signal) {
            listener.logoutComplete();
        }

        @Override
        public void domainsRsp(DomainsRsp domainsRsp) {
            switch (currentState) {
                case pendingDomains:
                    handleDomains(domainsRsp);
                    break;
                default:
                    ALog.w("amelia", "/conversation/domains not supported in state: " + currentState);
                    break;
            }
        }

        @Override
        public void newConversationRsp(NewConversationRsp newConversationRsp) {
            switch (currentState) {
                case pendingNewConversation:
                    handleNewConversation(newConversationRsp);
                    break;
                default:
                    ALog.w("amelia", "/conversation/new not supported in state: " + currentState);
                    break;
            }
        }

    };

    public String getSessionId() {
        if (conversation != null) {
            return conversation.sessionId;
        }
        return null;
    }

    public String getConversationId() {
        if (conversation != null) {
            return conversation.conversationId;
        }
        return null;
    }

    public Domain getDomain() {
        return domain;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    private String getUserInterface() {
        return "WEB_USER";
    }

    public AmeliaUser getUser() {
        return ameliaUser;
    }

    private void initiateLogin(LoginOptions loginOptions) {
        if (loginOptions.username == null) {//logging in with existing cookie
            String cookies;
            if (loginOptions.sessionCookie != null) {//Passed in session cookie
                cookies = "SESSION=" + loginOptions.sessionCookie;
                SessionUtil.persistCookies(appContext, ameliaBackendApi.baseUrl(), cookies);
            } else {//Did not pass in session cookie, grabbing it from webview cookie storage
                cookies = CookieManager.getInstance().getCookie(ameliaBackendApi.baseUrl() + "/Amelia/index.html");
            }
            if (ameliaBackendApi.addCookies(cookies)) {
                ameliaBackendApi.checkSessionRequest(null);
                currentState = State.pendingSessionCheck;
            } else {
                currentState = State.loggedOut;
                final AmeliaError ameliaError = new AmeliaError(AmeliaError.Code.missingSessionCookie, "Login failed");
                listener.loginFail(ameliaError);
            }
        }else {//logging in with user credentials
            ameliaBackendApi.clearCookies();
            ameliaBackendApi.initReq();
            currentState = State.pendingLoginInit;
            deferredLoginOptions = loginOptions;
        }

    }

    private void handleSessionCheck(CheckRsp checkRsp){
        if(checkRsp.error==null){
            ameliaBackendApi.initReq();
            currentState = State.pendingUserInit;
            listener.loginSuccess();
        }else{
            ameliaBackendApi.clearCookies();
            currentState = State.loggedOut;
            final AmeliaError ameliaError = new AmeliaError(AmeliaError.Code.invalidSession, "Login failed");
            listener.loginFail(ameliaError);
        }
    }

    private void handleAnonymousInit(InitRsp initRsp) {
        if (initRsp.error == null) {
            xCsrfToken = initRsp.data.getCsrfToken();
        }

        if (initRsp.error != null) {
            currentState = State.loggedOut;
            final AmeliaError ameliaError = new AmeliaError(initRsp.error, "Initialization failed");
            listener.sessionFail(ameliaError);
        } else {
            ameliaBackendApi.anonymousAllowedReq(xCsrfToken);
            currentState = State.pendingAnonymousAllowed;
        }
    }

    private void handleAnonymousAllowed(AnonymousAllowedRsp anonymousAllowedRsp) {
        if (anonymousAllowedRsp.error == null) {

            anonymousAllowed = "true".equals(anonymousAllowedRsp.data.getAnonynousAllowed());

            if (!anonymousAllowed) {
                currentState = State.loggedOut;
                final AmeliaError ameliaError = new AmeliaError(AmeliaError.Code.illegalAnonymousLogin, "Illegal anonymous login");
                listener.sessionFail(ameliaError);
            } else {
                ameliaBackendApi.anonymousCreateReq(xCsrfToken);
                currentState = State.pendingCreateAnon;
            }
        } else {
            currentState = State.loggedOut;
            final AmeliaError ameliaError = new AmeliaError(anonymousAllowedRsp.error, "Failed checking anonymous allowed");
            listener.sessionFail(ameliaError);
        }
    }

    private void handleAnonymousCreate(AnonymousCreateRsp anonymousCreateRsp) {
        if (anonymousCreateRsp.error == null) {
            currentState = State.pendingUserInit;
            ameliaBackendApi.initReq();
        } else {
            currentState = State.loggedOut;
            final AmeliaError ameliaError = new AmeliaError(anonymousCreateRsp.error, "Failed to create anonymous user");
            listener.sessionFail(ameliaError);
        }
    }

    private void handleWhoAmI(WhoAmIRsp whoAmIRsp) {
        if (whoAmIRsp.error == null) {
            currentState = State.pendingDomains;
            WhoAmIRspData rspData = whoAmIRsp.data;
            ameliaUser = new AmeliaUser(rspData.getName(), rspData.getEmail(), rspData.getAnonymous());
            listener.userInit(ameliaUser);
            listener.sessionStart();
            ameliaBackendApi.domainsReq(xCsrfToken);
        } else {
            currentState = State.loggedOut;
            final AmeliaError ameliaError = new AmeliaError(whoAmIRsp.error, "Failed fetching user");
            listener.sessionFail(ameliaError);
        }
    }

    private void handleDomains(DomainsRsp domainsRsp) {
        if (domainsRsp.error == null) {
            domains = domainsRsp.domains;
            findConfiguredDomain();
        }
        currentState = State.loggedIn;

        if (domainsRsp.error != null) {
            final AmeliaError ameliaError = new AmeliaError(domainsRsp.error, "Failed fetching domains");
            listener.domainFail(ameliaError);
        } else if (domain == null) {
            listener.domainSelectionRequired(domainsRsp.domains);
        } else {
            newConversationWhileLoggedIn();
        }
    }

    private void findConfiguredDomain() {
        switch (config.domainSelectionMode) {
            case automatic:
                if (domains.size() == 1 && !domains.get(0).getHidden()) {
                    domain = domains.get(0);
                }
                break;
            case manual:
                // always prompt
                break;
            case predefined:
                for (Domain domain : domains) {
                    if (domain.getCode().equals(config.domainCode)) {
                        this.domain = domain;
                    }
                }
                break;
        }
    }

    private void handleNewConversation(NewConversationRsp newConversationRsp) {
        if (newConversationRsp.error == null) {
            currentState = State.inConversation;
            Conversation conversation = new Conversation(xCsrfToken, newConversationRsp.data.getSessionId(), newConversationRsp.data.getConversationId());
            listener.newConversationRsp(conversation);
            domain = null;
        } else {
            currentState = State.loggedIn;
            final AmeliaError ameliaError = new AmeliaError(newConversationRsp.error, "Failed starting new conversation");
            listener.conversationFail(ameliaError);
        }
    }

    private void newConversationWhileLoggedOut() {
        if (config.allowAnonymous) {
            ameliaBackendApi.initReq();
            currentState = State.pendingAnonymousInit;
        } else {
            prepareLogin();
        }
    }

    private void handleAuthSystems(AuthSystemsRsp authSystemsRsp) {
        if (authSystemsRsp.error == null) {
            currentState = State.loggedOut;
            authSystems = authSystemsRsp.authSystems;
            listener.loginRequired(authSystems);
        } else {
            final AmeliaError ameliaError = new AmeliaError(authSystemsRsp.error, "Failed fetching authSystems");
            listener.sessionFail(ameliaError);
        }
    }

    private void handleLoginInit(InitRsp initRsp) {
        if (initRsp.error == null) {
            xCsrfToken = initRsp.data.getCsrfToken();
            currentState = State.pendingLogin;
            finishInternalLogin();
        } else {
            currentState = State.loggedOut;
            final AmeliaError ameliaError = new AmeliaError(initRsp.error, "Failed init before login");
            listener.loginFail(ameliaError);
            deferredLoginOptions = null;
        }
    }

    private void handleUserInit(InitRsp initRsp) {
        if (initRsp.error == null) {
            xCsrfToken = initRsp.data.getCsrfToken();
            currentState = State.pendingDomains;
            listener.userInit(ameliaUser);
            listener.sessionStart();
            ameliaBackendApi.domainsReq(xCsrfToken);

        } else {
            currentState = State.loggedOut;
            final AmeliaError ameliaError = new AmeliaError(initRsp.error, "Failed init before login");
            listener.sessionFail(ameliaError);
        }
    }

    private void finishInternalLogin() {
        LoginReq req = new LoginReq(xCsrfToken, deferredLoginOptions.username, deferredLoginOptions.password);
        ameliaBackendApi.loginReq(req);
        deferredLoginOptions = null;
        currentState = State.pendingLogin;
    }

    private void handlePrepareLogin() {
        if (authSystems == null) {
            currentState = State.pendingAuthSystems;
            ameliaBackendApi.authSystems();
        } else {
            domains = null;
            currentState = State.loggedOut;
            listener.loginRequired(authSystems);
        }
    }

    private void handleLogin(LoginRsp loginRsp) {
        if (loginRsp.error == null && loginRsp.data.getSuccess()) {
            ameliaUser = loginRsp.data.ameliaUser;
            ameliaBackendApi.initReq();
            currentState = State.pendingUserInit;
            listener.loginSuccess();
            SessionUtil.persistCookies(appContext,ameliaBackendApi.baseUrl(),loginRsp.cookies);
        } else {
            currentState = State.loggedOut;
            AmeliaError ameliaError;
            if (loginRsp.error != null) {
                ameliaError = new AmeliaError(loginRsp.error, "Login failed");
            } else {
                ameliaError = new AmeliaError(AmeliaError.Code.authenticationFailure, "Login failed");
            }
            listener.loginFail(ameliaError);
        }
    }

    private void newConversationWhileLoggedIn() {
        if (domains == null) {
            currentState = State.pendingDomains;
            ameliaBackendApi.domainsReq(xCsrfToken);
        } else {
            if (domain != null) {
                String newLang = domain.getLocaleLanguageTag();
                if (!languageCode.equals(newLang)) {
                    listener.languageChange(newLang, languageCode);
                }
                languageCode = newLang;

                final long ts = System.currentTimeMillis();
                final String user = getUserInterface();
                final String domainCode = domain.getCode();
                final String bpnVariables = "{}";
                NewConversationReq req = new NewConversationReq(xCsrfToken, user, ts, domainCode, bpnVariables);
                ameliaBackendApi.newConversationReq(req);
                currentState = State.pendingNewConversation;
            } else {
                currentState = State.loggedIn;
                listener.domainSelectionRequired(domains);
            }
        }
    }

    private void doLogout() {
        ameliaUser = null;
        domains = null;
        conversation = null;
        SessionUtil.deletePersistedCookies(appContext);
        ameliaBackendApi.clearCookies();
        ameliaBackendApi.logoutReq();
        currentState = State.loggedOut;
    }

    public interface Callback {

        void userInit(AmeliaUser user);

        void sessionStart();

        void sessionFail(AmeliaError error);

        void loginRequired(List<AuthSystem> authSystems);

        void loginFail(AmeliaError error);

        void loginSuccess();

        void domainSelectionRequired(List<Domain> domains);

        void domainFail(AmeliaError error);

        void conversationFail(AmeliaError error);

        void newConversationRsp(Conversation conversation);

        void endConversation();

        void languageChange(String newLang, String oldLang);

        void logoutComplete();

    }

    private enum DeferredEndConversationAction {
        none,
        logout,
        prepareLogin,
        login,
        newConversation
    }

    private enum State {
        inactive,
        loggedOut,
        pendingAnonymousInit,
        pendingAuthSystems,
        pendingSessionCheck,
        pendingLoginInit,
        pendingAnonymousAllowed,
        pendingCreateAnon,
        pendingLogin,
        pendingUserInit,
        pendingWhoAmI,
        loggedIn,
        pendingDomains,
        pendingNewConversation,
        pendingEndConversation,
        inConversation;
    }

}