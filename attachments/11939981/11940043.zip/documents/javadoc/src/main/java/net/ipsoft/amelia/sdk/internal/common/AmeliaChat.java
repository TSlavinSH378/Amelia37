package net.ipsoft.amelia.sdk.internal.common;

import android.content.Context;
import android.net.Uri;

import net.ipsoft.amelia.sdk.AmeliaError;
import net.ipsoft.amelia.sdk.AmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.AmeliaUser;
import net.ipsoft.amelia.sdk.Domain;
import net.ipsoft.amelia.sdk.DownloadMessage;
import net.ipsoft.amelia.sdk.FormInputData;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.IConversationListener;
import net.ipsoft.amelia.sdk.ISessionListener;
import net.ipsoft.amelia.sdk.LoginOptions;
import net.ipsoft.amelia.sdk.UploadMessage;
import net.ipsoft.amelia.sdk.internal.chat.ConversationHandler;
import net.ipsoft.amelia.sdk.internal.chat.IAmeliaStompApi;
import net.ipsoft.amelia.sdk.internal.chat.SpeechHandler;
import net.ipsoft.amelia.sdk.internal.restapi.AmeliaRestApi;
import net.ipsoft.amelia.sdk.AuthSystem;
import net.ipsoft.amelia.sdk.internal.restapi.HttpRequestProcessor;
import net.ipsoft.amelia.sdk.internal.restapi.IAmeliaBackendApi;
import net.ipsoft.amelia.sdk.internal.restapi.MmoUploadReq;
import net.ipsoft.amelia.sdk.internal.restapi.MmoUploadRsp;
import net.ipsoft.amelia.sdk.internal.restapi.SessionHandler;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Main entry for the Amelia SDK. This class provides all necessary services to manage sessions and
 * conversations within a session. It also provides chat services to allow clients to participate in
 * a conversation.
 * <p>
 * Clients may register separate listeners, {@link ISessionListener} and {@link IConversationListener}
 * to deal with events emitted by the SDK.
 */
public class AmeliaChat implements IAmeliaChat {

    private static final int MIN_IDLE_TIME = 300000;
    private static final int VAR_IDLE_TIME = 600000;

    private SessionHandler sessionHandler;
    private IAmeliaStompApi conversationHandler;

    private List<ISessionListener> sessionListeners = new ArrayList<>();
    private List<IConversationListener> conversationListeners = new ArrayList<>();
    private String mood;
    private boolean inputEnabled;
    private boolean secureInputEnabled;
    private Conversation conversation;
    private final HttpRequestProcessor httpRequestProcessor;
    private UploadMessage pendingUpload;
    private String pendingUploadRequestUser;
    private long timeOfLastMessage;
    private int minIdleTime;
    private int varIdleTime;
    private SpeechHandler speechHandler;
    private Context applicationContext;

    /**
     * Construct a new instance of the SDK with a custom configuration.
     *
     * @param ameliaConfig
     */
    public AmeliaChat(Context context, AmeliaConfig ameliaConfig) {

        applicationContext = context.getApplicationContext();

        minIdleTime = ameliaConfig.minIdleTime != -1 ? ameliaConfig.minIdleTime : MIN_IDLE_TIME;
        varIdleTime = ameliaConfig.varIdleTime != -1 ? ameliaConfig.varIdleTime : VAR_IDLE_TIME;

        mood = ameliaConfig.initialMood;

        httpRequestProcessor = new HttpRequestProcessor(ameliaConfig.baseUrl);

        if (ameliaConfig.speechParams.enabled) {
            speechHandler = new SpeechHandler(applicationContext, httpRequestProcessor, speechCallback);
        }

        IAmeliaBackendApi ameliaBackendApi = new AmeliaRestApi(httpRequestProcessor);
        IAmeliaStompApi ameliaStompApi = new ConversationHandler(httpRequestProcessor, ameliaConfig);

        Provider provider = ameliaConfig.provider;
        if (provider == null) {
            provider = new Provider(ameliaBackendApi, ameliaStompApi);
        }

        sessionHandler = new SessionHandler(context.getApplicationContext(),ameliaConfig, provider, internalSessionListener);

        conversationHandler = provider.getAmeliaStompApi();
        conversationHandler.setChatListener(internalConversationListener);

        sessionListeners.addAll(ameliaConfig.sessionListeners);
        conversationListeners.addAll(ameliaConfig.conversationListeners);

        sessionHandler.activate();
    }

    /*
     * Public session API
     */
    @Override
    public void stopPlayAudio(){
        speechHandler.stopSpeech();
    }

    @Override
    public void addSessionListener(ISessionListener sessionListener) {
        sessionListeners.add(sessionListener);
    }

    @Override
    public void removeSessionListener(ISessionListener sessionListener) {
        sessionListeners.remove(sessionListener);
    }

    @Override
    public void addConversationListener(IConversationListener conversationListener) {
        conversationListeners.add(conversationListener);
    }

    @Override
    public void removeConversationListener(IConversationListener conversationListener) {
        conversationListeners.remove(conversationListener);
    }

    @Override
    public void stepupLogin() {
        sessionHandler.prepareLogin();
    }

    @Override
    public void login(LoginOptions options) {
        sessionHandler.login(options);
    }

    @Override
    public void logout() {
        sessionHandler.logout();
    }

    @Override
    public void startNewConversation() {
        selectDomain(null);
    }

    @Override
    public void selectDomain(Domain domain) {
        sessionHandler.newConversationReq(domain);
    }

    @Override
    public void endConversation() {
        if (conversation != null) {
            sessionHandler.endConversation();
        }
    }

    @Override
    public String getSessionId() {
        return sessionHandler.getSessionId();
    }

    @Override
    public String getConversationId() {
        return sessionHandler.getConversationId();
    }

    @Override
    public Domain getDomain() {
        return sessionHandler.getDomain();
    }

    @Override
    public String getLangaugeCode() {
        return sessionHandler.getLanguageCode();
    }

    @Override
    public boolean isInputEnabled() {
        return inputEnabled;
    }

    @Override
    public AmeliaUser getUser() {
        return sessionHandler.getUser();
    }

    /*
     * Public chat API
     */

    @Override
    public void say(String statement) {
        if(!secureInputEnabled) {
            ask(statement);
        }else{
            askInSecureWay(statement);

        }
    }

    @Override
    public void ask(String question) {
        timeOfLastMessage = System.currentTimeMillis();
        conversationHandler.ask(question,false);
    }

    @Override
    public void submitForm(FormInputData form, String messageText) {
        toggleInputState(true, "FormSubmit", InputStateChangeReason.form);
        conversationHandler.submitForm(form, messageText);
    }

    @Override
    public void runAction(String processName, String processArgs, String messageText) {
        toggleInputState(true, "FormSubmit", InputStateChangeReason.form);
        conversationHandler.runAction(processName, processArgs, messageText);
    }

    @Override
    public void clearChatHistory() {
        for (IConversationListener conversationListener : conversationListeners) {
            conversationListener.onChatHistoryClear();
        }
    }

    @Override
    public String getCurrentMood() {
        return mood;
    }

    @Override
    public long getTimeOfLastMessage() {
        return timeOfLastMessage;
    }

    @Override
    public void uploadFile(Uri uri) {
        final MmoUploadReq mmoUploadReq = new MmoUploadReq(applicationContext, uri, pendingUpload.fileType, conversation);
        httpRequestProcessor.send(mmoUploadReq, new MmoUploadRsp() {

            @Override
            public void run() {
                if (error != null || "Error".equals(body)) {
                    pendingUpload.setRecentError(new AmeliaError(error, body));
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.onUploadFailed(pendingUploadRequestUser, mmoUploadReq.getFile().getName(), pendingUpload.fileType);
                    }
                } else {
                    pendingUpload.setRecentError(null);
                    pendingUpload.setUploaded(true);
                    toggleInputState(true, "Upload", InputStateChangeReason.upload);
                    String fileUploadSuccessMessage = "The file " + body + "&name=" + mmoUploadReq.getFile().getName() + " was successfully uploaded.";
                    conversationHandler.ask(fileUploadSuccessMessage,false);
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.onUploadSuccess(pendingUploadRequestUser, mmoUploadReq.getFile().getName(), body);
                    }
                }
                File uploadedFile = mmoUploadReq.getFile();
                if (uploadedFile != null) {
                    uploadedFile.delete();
                }
            }
        });
    }

    @Override
    public void mute() {
        if (speechHandler != null) {
            speechHandler.setMuted(true);
        }
    }

    @Override
    public void unmute() {
        if (speechHandler != null) {
            speechHandler.setMuted(false);
        }
    }

    /*
     * Listeners
     */

    private SessionHandler.Callback internalSessionListener = new SessionHandler.Callback() {

        @Override
        public void userInit(AmeliaUser ameliaUser) {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onUserInit(ameliaUser.getName(), ameliaUser.getEmail());
            }
        }

        @Override
        public void sessionStart() {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onSessionStart();
            }
        }

        @Override
        public void sessionFail(AmeliaError error) {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onSessionFail(error);
            }
        }

        @Override
        public void loginRequired(List<AuthSystem> authSystems) {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onLoginRequired(authSystems);
            }
        }

        @Override
        public void loginSuccess() {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onLoginSuccess();
            }
        }

        @Override
        public void loginFail(AmeliaError error) {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onLoginFail(error);
            }
        }

        @Override
        public void domainSelectionRequired(List<Domain> domains) {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onDomainSelectionRequired(domains);
            }
        }

        @Override
        public void domainFail(AmeliaError error) {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onDomainFail(error);
            }
        }

        @Override
        public void conversationFail(AmeliaError error) {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onConversationFail(error);
            }
        }

        @Override
        public void newConversationRsp(Conversation conversation) {
            AmeliaChat.this.conversation = conversation;
            conversationHandler.startConversation(conversation);

            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onConversationStart();
            }
        }

        @Override
        public void endConversation() {
            conversationHandler.endConversationReq();
        }

        @Override
        public void languageChange(String newLang, String oldLang) {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onLanguageChange(newLang, oldLang);
            }
        }

        @Override
        public void logoutComplete() {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onLogout();
            }
        }
    };

    private ConversationHandler.Callback internalConversationListener = new ConversationHandler.Callback() {

        @Override
        public void onSend(String messageType) {
            if ("InboundUserUtteranceMessage".equals(messageType)) {
                if (!inputEnabled) {
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.onErrorInputBlocked();
                    }
                } else {
                    toggleInputState(false, messageType, InputStateChangeReason.unknown);
                }
            }
        }

        @Override
        public void onConnect() {
            for (IConversationListener conversationListener : conversationListeners) {
                conversationListener.onConnect();
            }
        }

        @Override
        public void onReconnect() {
            for (IConversationListener conversationListener : conversationListeners) {
                conversationListener.onReconnect();
            }
            toggleInputState(true, null, InputStateChangeReason.idle);
        }

        @Override
        public void endConversationRsp() {
            onAfterEndConversation();
        }

        @Override
        public void onDisconnect() {
            for (IConversationListener conversationListener : conversationListeners) {
                conversationListener.onDisconnect();
            }
            toggleInputState(false, null, InputStateChangeReason.disconnected);
        }

        @Override
        public void sessionFail(AmeliaError error) {
            for (ISessionListener sessionListener : sessionListeners) {
                sessionListener.onSessionFail(error);
            }
        }

        @Override
        public void onMessage(String text, AmeliaOutboundMessage message) {

            checkInputStatus(message);

            String newMood = message.getAttributes().getMood();
            if (newMood != null) {
                if (!newMood.equals(mood)) {
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.onMoodChange(newMood, mood);
                    }
                    mood = newMood;
                }
            } else {
                // make sure there is a mood on the message
                message.getAttributes().setMood(mood);
            }

            for (IConversationListener conversationListener : conversationListeners) {
                conversationListener.onMessageReceived(text);
            }

            if (speechHandler != null) {
                speechHandler.loadSpeech(message);
                speechHandler.setAvatarVoice(message.getVoice());
            }
            boolean messageConsumed = false;
            switch (message.getMessageType()) {
                case "OutboundTextMessage":
                case "OutboundFinalTextMessage":
                    timeOfLastMessage = System.currentTimeMillis();
                    if (!handleUploadRequest(message) && !transformMultimedia(message)) {
                        for (IConversationListener conversationListener : conversationListeners) {
                            conversationListener.outboundFinalTextMessage(message);
                        }
                    } else {
                        messageConsumed = true;
                    }
                    toggleSecureInputState(message.getAttributes().shouldSecureInput());
                    break;

                case "OutboundProgressTextMessage":
                    timeOfLastMessage = System.currentTimeMillis();
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundProgressTextMessage(message);
                    }
                    break;

                case "OutboundIdleTalkMessage":
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundIdleTalkMessage(message);
                    }
                    break;

                case "OutboundNoIdleTalkMessage":
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundNoIdleTalkMessage(message);
                    }
                    break;

                case "WolframAlphaFinalMessage":
                    timeOfLastMessage = System.currentTimeMillis();
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.wolframAlphaFinalMessage(message);
                    }
                    break;

                case "OutboundEchoMessage":
                    timeOfLastMessage = System.currentTimeMillis();
                    if (!isFileUploadEcho(message)) {
                        for (IConversationListener conversationListener : conversationListeners) {
                            conversationListener.outboundEchoMessage(message);
                        }
                    }
                    break;

                case "OutboundFinalErrorMessage":
                    timeOfLastMessage = System.currentTimeMillis();
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundFinalErrorMessage(message);
                    }
                    break;

                case "OutboundConversationClosedMessage":
                    timeOfLastMessage = System.currentTimeMillis();
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundConversationClosedMessage(message);
                    }
                    break;

                case "OutboundSessionClosedMessage":
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundSessionClosedMessage(message);
                    }
                    break;

                case "OutboundIntegrationMessage":
                    timeOfLastMessage = System.currentTimeMillis();
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundIntegrationMessage(message);
                    }
                    break;

                case "OutboundAckRequestMessage":
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundAckRequestMessage(message);
                    }
                    break;

                case "OutboundAgentSessionChangedMessage":
                    timeOfLastMessage = System.currentTimeMillis();
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundAgentSessionChangedMessage(message);
                    }
                    break;

                case "OutboundFinalReplayMessage":
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundFinalReplayMessage(message);
                    }
                    break;

                case "OutboundEscalationStartedMessage":
                    for (IConversationListener conversationListener : conversationListeners) {
                        conversationListener.outboundEscalationStartedMessage(message);
                    }
                    break;

                case "OutboundAvatarChangeVoiceMessage":
                    String avatarVoice = message.getAttributes().getAvatarVoice();
                    if (speechHandler != null && avatarVoice != null) {
                        speechHandler.setAvatarVoice(avatarVoice);
                    }
                    break;

                default:
                    ALog.d("amelia", "Unrecognized message type: " + message.getMessageType());
                    break;
            }

            if (!messageConsumed) {
                for (IConversationListener conversationListener : conversationListeners) {
                    conversationListener.outboundAmeliaMessage(message);
                }
            }
        }
    };

    SpeechHandler.Callback speechCallback = new SpeechHandler.Callback() {
        @Override
        public void onSpeakStart() {
            for (IConversationListener conversationListener : conversationListeners) {
                conversationListener.onSpeakStart();
            }
        }

        @Override
        public void onSpeakEnd() {
            for (IConversationListener conversationListener : conversationListeners) {
                conversationListener.onSpeakEnd();
            }
        }
    };

    /*
     * Helpers
     */

    private void onAfterEndConversation() {
        clearChatHistory();
        conversation = null;
        secureInputEnabled = false;
        sessionHandler.conversationEnded();

        for (ISessionListener sessionListener : sessionListeners) {
            sessionListener.onConversationEnd();
        }
    }

    private boolean handleUploadRequest(final AmeliaOutboundMessage message) {
        String messageText = message.getMessageText();
        if (messageText.contains("UPLOAD_REQUEST_MESSAGE_EVENT")) {
            int index = messageText.indexOf(':');
            String fileType = messageText.substring(index + 1);
            index = fileType.indexOf(':');
            fileType = index == -1 ? fileType : fileType.substring(0, index);
            fileType = fileType.trim();
            pendingUpload = new UploadMessage(fileType);
            message.setUploadMessage(pendingUpload);
            pendingUploadRequestUser = message.getFromUserDisplayName();

            for (IConversationListener conversationListener : conversationListeners) {
                conversationListener.onUploadRequest(message);
            }
            return true;
        }
        return false;
    }

    private boolean transformMultimedia(final AmeliaOutboundMessage message) {
        String messageText = message.getMessageText();
        if (messageText.toLowerCase().indexOf("amelia-mmo") != -1) {
            String text = messageText.replaceAll("\\s", "");
            Pattern pattern = Pattern.compile("(\\b(amelia-mmo):\\/\\/[-A-Z0-9+&@#\\/%?=~_|!:,.;]*[-A-Z0-9+&@#\\/%=~_|])", Pattern.CASE_INSENSITIVE);
            if (pattern.matcher(text).find()) {
                String key = text.substring(text.lastIndexOf('/') + 1);
                final DownloadMessage downloadMessage = new DownloadMessage(httpRequestProcessor, conversation, key);
                message.setDownloadMessage(downloadMessage);
                downloadMessage.fetchMetadata(new DownloadMessage.OnMetadataFetchedListener() {
                    @Override
                    public void onMetadataFetched() {
                        for (IConversationListener conversationListener : conversationListeners) {
                            conversationListener.outboundMmoDownloadMessage(message);
                        }
                    }
                });
                return true;
            }
        }
        return false;
    }

    private boolean isFileUploadEcho(AmeliaOutboundMessage body) {
        String text = body.getMessageText();
        if (text.contains("getFile")) {
            return text.contains("was successfully uploaded");
        }
        return false;
    }

    private void checkInputStatus(AmeliaOutboundMessage message) {
        boolean shouldEnable;
        InputStateChangeReason reason = InputStateChangeReason.unknown;
        switch (message.getMessageType()) {
            case "OutboundFinalTextMessage":
                //this is an awful hack because we are using OutboundFinalTextMessage to complete an upload request
                if (message.getAttributes().getFormInputData() != null && "FORM_ONLY".equals(message.getAttributes().getFormInputData().getAllowedUserInputs())) {
                    shouldEnable = false;
                    reason = InputStateChangeReason.form;
                } else {
                    shouldEnable = message.getMessageText() == null || !message.getMessageText().contains("UPLOAD_REQUEST_MESSAGE_EVENT");
                    if (!shouldEnable) {
                        inputEnabled = true;
                        reason = InputStateChangeReason.upload;
                    }
                }
                break;
            case "OutboundAckRequestMessage":
                conversationHandler.send("InboundAckMessage");
                if (System.currentTimeMillis() - timeOfLastMessage > minIdleTime + Math.floor(Math.random() * varIdleTime)) {
                    toggleInputState(false, message.getMessageType(), InputStateChangeReason.idle);
                    conversationHandler.send("InboundUserIdleMessage");
                    return;
                }
                shouldEnable = true;
                break;

            default:
                shouldEnable = Boolean.valueOf(message.getHeader("X-Amelia-Input-Enabled"));
                break;
        }
        toggleInputState(shouldEnable, message.getMessageType(), reason);
    }

    private void toggleInputState(boolean newValue, String messageType, InputStateChangeReason reason) {
        if (inputEnabled != newValue) {
            inputEnabled = newValue;
            for (IConversationListener conversationListener : conversationListeners) {
                conversationListener.onInputEnabledChanged(newValue, messageType, reason);
            }
        }
    }

    private void toggleSecureInputState(boolean newValue) {
        if (secureInputEnabled != newValue) {
            secureInputEnabled = newValue;
            for (IConversationListener conversationListener : conversationListeners) {
                conversationListener.onSecureInputEnabledChanged(newValue);
            }
        }
    }
    private void askInSecureWay(String question){
        timeOfLastMessage = System.currentTimeMillis();
        conversationHandler.ask(question,true);
    }

}