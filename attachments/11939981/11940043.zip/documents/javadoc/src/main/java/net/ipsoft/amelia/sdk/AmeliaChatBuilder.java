package net.ipsoft.amelia.sdk;

import android.content.Context;

import net.ipsoft.amelia.sdk.internal.common.AmeliaChat;
import net.ipsoft.amelia.sdk.internal.common.AmeliaConfig;
import net.ipsoft.amelia.sdk.internal.common.Provider;

import java.util.ArrayList;
import java.util.List;

public class AmeliaChatBuilder {

    private Context context;
    private String baseUrl;
    private Provider provider;
    private boolean allowAnonymous;
    private DomainSelectionMode domainSelectionMode = DomainSelectionMode.automatic;
    private String domainCode;
    private String languageCode = "en-US";
    private String initialMood = "HAPPY";
    private int reconnectDelayMs = 2000;
    private int minIdleTime = -1;
    private int varIdleTime = -1;
    private List<ISessionListener> sessionListeners = new ArrayList<>();
    private List<IConversationListener> conversationListeners = new ArrayList<>();
    private SpeechParams speechParams;

    /**
     * @param context
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setContext(Context context) {
        this.context = context;
        return this;
    }

    /**
     * @param baseUrl
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
        return this;
    }

    /* package */ AmeliaChatBuilder setProvider(Provider provider) {
        this.provider = provider;
        return this;
    }

    /**
     * If <code>true</code>, will ask Amelia to create an anonymous user if there is no already logged-in user.
     * If <code>false</code>, a {@link ISessionListener#onLoginRequired(List)} message will be sent,
     * and the chat will not be enabled until a login has occurred. Defaults to <code>false</code>
     *
     * @param allowAnonymous
     * @return <code>this</code> to allow chained method calls
     * @see AmeliaConfig#allowAnonymous
     */
    public AmeliaChatBuilder setAllowAnonymous(boolean allowAnonymous) {
        this.allowAnonymous = allowAnonymous;
        return this;
    }

    /**
     * Sets domain selection mode
     *
     * @see DomainSelectionMode
     *
     * @param domainSelectionMode
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setDomainSelectionMode(DomainSelectionMode domainSelectionMode) {
        this.domainSelectionMode = domainSelectionMode;
        return this;
    }

    /**
     * Set a predefined domain code, applicable when {@link #setDomainSelectionMode(DomainSelectionMode)}
     * is set to {@link DomainSelectionMode#predefined}
     *
     * @see DomainSelectionMode
     *
     * @param domainCode domain code
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setDomainCode(String domainCode) {
        this.domainCode = domainCode;
        return this;
    }

    /**
     * The language code of the chat/current domain. defaults to en-US, and can change as
     * Amelia sends messages
     *
     * @param languageCode new language code
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
        return this;
    }

    /**
     * The initial mood for Amelia.
     *
     * @see AmeliaOutboundMessageAttributes#getMood()
     * @param initialMood
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setInitialMood(String initialMood) {
        this.initialMood = initialMood;
        return this;
    }


    /**
     * Time in ms before a reconnect attempt is made after connection is lost during a
     * conversation
     *
     * @param reconnectDelayMs time in ms before a reconnect attempt is made
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setReconnectDelayMs(int reconnectDelayMs) {
        this.reconnectDelayMs = reconnectDelayMs;
        return this;
    }

    /**
     * The minimum ms before the client will tell Amelia the user has gone idle
     *
     * @param minIdleTime minimum idle time in ms
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setMinIdleTime(int minIdleTime) {
        this.minIdleTime = minIdleTime;
        return this;
    }

    /**
     * Additional millis as a random seed – between 0 and varIdleTime will be added to minIdleTime
     *
     * @param varIdleTime variable idle time in ms
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setVarIdleTime(int varIdleTime) {
        this.varIdleTime = varIdleTime;
        return this;
    }

    /**
     * Possibility to add a session listener as part of the instantiation process
     * @param sessionListener
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder addSessionListener(ISessionListener sessionListener) {
        sessionListeners.add(sessionListener);
        return this;
    }

    /**
     * Possibility to add a chat listener as part of the instantiation process
     *
     * @param conversationListener
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder addConversationListener(IConversationListener conversationListener) {
        conversationListeners.add(conversationListener);
        return this;
    }

    /**
     * Parameters controlling playback of Amelia's voice
     *
     * @param speechParams voice playback params
     * @return <code>this</code> to allow chained method calls
     */
    public AmeliaChatBuilder setSpeechParams(SpeechParams speechParams) {
        this.speechParams = speechParams;
        return this;
    }

    /**
     * Construct a new {@link AmeliaChat} based on this builder.
     *
     * @return the new configuration
     */
    public IAmeliaChat build() {
        if (provider == null && context == null) {
            throw new IllegalArgumentException("context is a required field");
        }

        if (baseUrl == null) {
            throw new IllegalArgumentException("baseUrl is a required field");
        }

        if (domainCode != null && domainSelectionMode != DomainSelectionMode.predefined) {
            throw new IllegalArgumentException("When a domain code is provided, domainSelectionMode must be set to DomainSelectionMode.predefined");
        } else if (domainSelectionMode == DomainSelectionMode.predefined && domainCode == null) {
            throw new IllegalArgumentException("When domainSelectionMode is set to DomainSelectionMode.predefined a domainCode must be supplied");
        }

        if (speechParams == null) {
            speechParams = new SpeechParams(true, false);
        }

        return new AmeliaChat(
                context,
                new AmeliaConfig(
                        baseUrl,
                        provider,
                        allowAnonymous,
                        domainSelectionMode,
                        domainCode,
                        languageCode,
                        initialMood,
                        reconnectDelayMs,
                        minIdleTime,
                        varIdleTime,
                        sessionListeners,
                        conversationListeners,
                        speechParams
                )
        );
    }
}
