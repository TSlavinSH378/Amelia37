package net.ipsoft.amelia.sdk.internal.stomp;

public class StompHeartBeat extends StompMessage {

}
