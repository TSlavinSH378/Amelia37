package net.ipsoft.amelia.sdk;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import java.io.IOException;

/**
 * Conversations takes place in a given domain, instances of this class describe available domains
 * for a given {@link AmeliaUser}.
 */
public class Domain implements Parcelable {

    protected String domainId = null;
    protected String name = null;
    protected String code = null;
    protected String localeDisplayName = null;
    protected String localeLanguageTag = null;
    protected boolean requireLogin = false;
    protected boolean hidden = false;

    /**
     * Unique (within an organization) identifier of this domain
     *
     * @return domain id
     */
    public String getDomainId() {
        return domainId;
    }

    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    /**
     * Display name of domain
     *
     * @return domain name
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * Code used to identify a domain when starting a new conversation
     *
     * @return domain code
     */
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    /**
     * UI friendly locale display name representing the domain's language
     *
     * @return locale display name
     */
    public String getLocaleDisplayName() {
        return localeDisplayName;
    }

    public void setLocaleDisplayName(String localeDisplayName) {
        this.localeDisplayName = localeDisplayName;
    }

    /**
     * Standardized locale name representing the domain's language
     *
     * @return standardized locale name
     */
    public String getLocaleLanguageTag() {
        return localeLanguageTag;
    }

    public void setLocaleLanguageTag(String localeLanguageTag) {
        this.localeLanguageTag = localeLanguageTag;
    }

    /**
     *
     *
     * @return <code>true</code> if login is required
     */
    public boolean getRequireLogin() {
        return requireLogin;
    }

    public void setRequireLogin(boolean requireLogin) {
        this.requireLogin = requireLogin;
    }

    /**
     *
     * @return <code>true</code> if domain is hidden
     */
    public boolean getHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    @Override
    public String toString() {
        return "{ " + "domainId: " + domainId + ", " + "name: " + name + ", " + "code: " + code + ", " + "localeDisplayName: " + localeDisplayName + ", " + "localeLanguageTag: " + localeLanguageTag + ", " + "requireLogin: " + requireLogin + ", " + "hidden: " + hidden + " }";
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeString(domainId);
        out.writeString(name);
        out.writeString(code);
        out.writeString(localeDisplayName);
        out.writeString(localeLanguageTag);
        out.writeInt(requireLogin ? 1 : 0);
        out.writeInt(hidden ? 1 : 0);
    }

    public static final Parcelable.Creator<Domain> CREATOR = new Parcelable.Creator<Domain>() {
        public Domain createFromParcel(Parcel in) {
            Domain obj = new Domain();
            obj.domainId = in.readString();
            obj.name = in.readString();
            obj.code = in.readString();
            obj.localeDisplayName = in.readString();
            obj.localeLanguageTag = in.readString();
            obj.requireLogin = in.readInt() != 0;
            obj.hidden = in.readInt() != 0;
            return obj;
        }

        public Domain[] newArray(int size) {
            return new Domain[size];
        }
    };

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        jsonWriter.name("domainId");
        jsonWriter.value(domainId);
        if (name != null) {
            jsonWriter.name("name");
            jsonWriter.value(name);
        }
        if (code != null) {
            jsonWriter.name("code");
            jsonWriter.value(code);
        }
        if (localeDisplayName != null) {
            jsonWriter.name("localeDisplayName");
            jsonWriter.value(localeDisplayName);
        }
        if (localeLanguageTag != null) {
            jsonWriter.name("localeLanguageTag");
            jsonWriter.value(localeLanguageTag);
        }
        jsonWriter.name("requireLogin");
        jsonWriter.value(requireLogin);
        jsonWriter.name("hidden");
        jsonWriter.value(hidden);
        jsonWriter.endObject();
    }

    public static Domain deserialize(JsonReader jsonReader) throws IOException {
        Domain domain = new Domain();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("domainId" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                domain.setDomainId(jsonReader.nextString());
            } else if ("name" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                domain.setName(jsonReader.nextString());
            } else if ("code" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                domain.setCode(jsonReader.nextString());
            } else if ("localeDisplayName" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                domain.setLocaleDisplayName(jsonReader.nextString());
            } else if ("localeLanguageTag" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                domain.setLocaleLanguageTag(jsonReader.nextString());
            } else if ("requireLogin" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                domain.setRequireLogin(jsonReader.nextBoolean());
            } else if ("hidden" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                domain.setHidden(jsonReader.nextBoolean());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return domain;
    }
}