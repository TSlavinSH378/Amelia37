package net.ipsoft.amelia.sdk.internal.common;

import net.ipsoft.amelia.sdk.DomainSelectionMode;
import net.ipsoft.amelia.sdk.IConversationListener;
import net.ipsoft.amelia.sdk.ISessionListener;
import net.ipsoft.amelia.sdk.SpeechParams;

import java.util.List;

/**
 * Immutable configuration class for an instance of {@link AmeliaChat}
 */
public class AmeliaConfig {

    public final String baseUrl;
    public final Provider provider;
    public final boolean allowAnonymous;
    public final DomainSelectionMode domainSelectionMode;
    public final String domainCode;
    public final String languageCode;
    public final String initialMood;
    public final int reconnectDelayMs;
    public final int minIdleTime;
    public final int varIdleTime;
    public final SpeechParams speechParams;

    public final List<ISessionListener> sessionListeners;
    public final List<IConversationListener> conversationListeners;

    public AmeliaConfig(String baseUrl,
                        Provider provider,
                        boolean allowAnonymous,
                        DomainSelectionMode domainSelectionMode,
                        String domainCode,
                        String languageCode,
                        String initialMood,
                        int reconnectDelayMs,
                        int minIdleTime,
                        int varIdleTime,
                        List<ISessionListener> sessionListeners,
                        List<IConversationListener> conversationListeners,
                        SpeechParams speechParams) {
        this.baseUrl = baseUrl;
        this.provider = provider;
        this.allowAnonymous = allowAnonymous;
        this.domainSelectionMode = domainSelectionMode;
        this.domainCode = domainCode;
        this.languageCode = languageCode;
        this.initialMood = initialMood;
        this.reconnectDelayMs = reconnectDelayMs;
        this.minIdleTime = minIdleTime;
        this.varIdleTime = varIdleTime;
        this.sessionListeners = sessionListeners;
        this.conversationListeners = conversationListeners;
        this.speechParams = speechParams;
    }

    @Override
    public String toString() {
        return "{ " +
                "baseUrl: " + baseUrl + ", " +
                "allowAnonymous: " + allowAnonymous + ", " +
                "domainSelectionMode: " + domainSelectionMode + ", " +
                "domainCode: " + domainCode + ", " +
                "languageCode: " + languageCode + ", " +
                "initialMood: " + initialMood + ", " +
                "reconnectDelayMs: " + reconnectDelayMs + ", " +
                "minIdleTime: " + minIdleTime + ", " +
                "varIdleTime: " + varIdleTime + ", " +
                "speechParams: " + speechParams +
                " }";
    }

}