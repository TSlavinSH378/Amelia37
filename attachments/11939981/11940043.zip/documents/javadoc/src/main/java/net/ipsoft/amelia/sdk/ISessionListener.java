package net.ipsoft.amelia.sdk;


import net.ipsoft.amelia.sdk.internal.common.AmeliaChat;
import net.ipsoft.amelia.sdk.internal.common.AmeliaConfig;

import java.util.List;

/**
 * Primary interface for events related to establishment of sessions and conversations
 */
public interface ISessionListener {

    /**
     * Called when a user has been identified including anonymous users
     *
     * @param name user's name
     * @param email user's email
     */
    void onUserInit(String name, String email);

    /**
     * Callback when the logged in user is known and the session is started
     */
    void onSessionStart();

    /**
     * Unable to start a new session, any attempts to establish a new session will start from scratch.
     *
     * @param error a detailed error description
     */
    void onSessionFail(AmeliaError error);

    /**
     * Callback when anonymous users are disabled via {@link AmeliaConfig} and a login is
     * required to proceed with a new conversation.
     */
    void onLoginRequired(List<AuthSystem> authSystems);

    /**
     * Callback when {@link AmeliaChat#login(LoginOptions)} fails
     *
     * @param error a detailed error description
     */
    void onLoginFail(AmeliaError error);

    /**
     * Callback when {@link AmeliaChat#login(LoginOptions)} succeeds
     */
    void onLoginSuccess();

    /**
     * Callback during a manual domain selection when the list of domains is fetched
     *
     * @param domains list of domains available to the current user
     */
    void onDomainSelectionRequired(List<Domain> domains);

    /**
     * Callback when the user attempts to access an invalid or unauthorized
     * domain, or when an error occurs establishing a domain
     *
     * @param error a detailed error description
     */
    void onDomainFail(AmeliaError error);

    /**
     * Callback when a new conversation has successfully been started
     */
    void onConversationStart();

    /**
     * Callback when a new conversation has successfully been ended
     */
    void onConversationEnd();

    /**
     * There was an error trying to start a new conversation
     *
     * @param error a detailed error description
     */
    void onConversationFail(AmeliaError error);

    /**
     * Callback when a message from Amelia has triggered a change in the current language
     * @param newLang the new language code
     * @param oldLang the old language code
     */
    void onLanguageChange(String newLang, String oldLang);

    /**
     * Callback when logout has completed
     */
    void onLogout();
}
