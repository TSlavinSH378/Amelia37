package net.ipsoft.amelia.sdk.internal.restapi;

import java.io.IOException;

import android.util.JsonWriter;
import android.util.JsonReader;
import android.util.JsonToken;

public class FileMetadata {
    protected int id = 0;
    protected String name = null;
    protected String path = null;
    protected boolean isImage = false;
    protected String description = null;
    protected int domainId = 0;
    protected int parent_id = 0;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public boolean getIsImage() {
        return isImage;
    }

    public void setIsImage(boolean isImage) {
        this.isImage = isImage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDomainId() {
        return domainId;
    }

    public void setDomainId(int domainId) {
        this.domainId = domainId;
    }

    public int getParent_id() {
        return parent_id;
    }

    public void setParent_id(int parent_id) {
        this.parent_id = parent_id;
    }

    @Override
    public String toString() {
        return "{ " + "id: " + id + ", " + "name: " + name + ", " + "path: " + path + ", " + "isImage: " + isImage + ", " + "description: " + description + ", " + "domainId: " + domainId + ", " + "parent_id: " + parent_id + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        jsonWriter.name("id");
        jsonWriter.value(id);
        if (name != null) {
            jsonWriter.name("name");
            jsonWriter.value(name);
        }
        if (path != null) {
            jsonWriter.name("path");
            jsonWriter.value(path);
        }
        jsonWriter.name("isImage");
        jsonWriter.value(isImage);
        if (description != null) {
            jsonWriter.name("description");
            jsonWriter.value(description);
        }
        jsonWriter.name("domainId");
        jsonWriter.value(domainId);
        jsonWriter.name("parent_id");
        jsonWriter.value(parent_id);
        jsonWriter.endObject();
    }

    public static FileMetadata deserialize(JsonReader jsonReader) throws IOException {
        FileMetadata fileMetadata = new FileMetadata();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("id".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                fileMetadata.setId(jsonReader.nextInt());
            } else if ("name".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                fileMetadata.setName(jsonReader.nextString());
            } else if ("path".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                fileMetadata.setPath(jsonReader.nextString());
            } else if ("isImage".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                fileMetadata.setIsImage(jsonReader.nextBoolean());
            } else if ("description".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                fileMetadata.setDescription(jsonReader.nextString());
            } else if ("domainId".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                fileMetadata.setDomainId(jsonReader.nextInt());
            } else if ("parent_id".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                fileMetadata.setParent_id(jsonReader.nextInt());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return fileMetadata;
    }
}