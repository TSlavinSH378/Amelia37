package net.ipsoft.amelia.sdk.internal.restapi;

import net.ipsoft.amelia.sdk.internal.common.Conversation;

public class MmoDownloadReq extends HttpRequest {

    private final int fileId;
    private final Conversation conversation;

    public MmoDownloadReq(int fileId, Conversation conversation) {
        this.fileId = fileId;
        this.conversation = conversation;
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/getFile?fileId=" + fileId + "&conversationId=" + conversation.conversationId;
    }

    @Override
    public String accept() {
        return "*/*";
    }
}
