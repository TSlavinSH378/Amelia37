package net.ipsoft.amelia.sdk.internal.common;

import net.ipsoft.amelia.sdk.internal.chat.IAmeliaStompApi;
import net.ipsoft.amelia.sdk.internal.restapi.IAmeliaBackendApi;

/**
 * Simple instance provider to allow dependency injection without 3d party DI frameworks.
 */
public class Provider {

    private IAmeliaBackendApi ameliaBackendApi;
    private IAmeliaStompApi ameliaStompApi;

    public Provider(IAmeliaBackendApi ameliaBackendApi, IAmeliaStompApi ameliaStompApi) {
        this.ameliaBackendApi = ameliaBackendApi;
        this.ameliaStompApi = ameliaStompApi;
    }

    public IAmeliaBackendApi getAmeliaBackendApi() {
        return ameliaBackendApi;
    }

    public IAmeliaStompApi getAmeliaStompApi() {
        return ameliaStompApi;
    }

}
