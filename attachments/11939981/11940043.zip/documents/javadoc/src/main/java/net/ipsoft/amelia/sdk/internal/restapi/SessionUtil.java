package net.ipsoft.amelia.sdk.internal.restapi;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;

import java.net.HttpCookie;
import java.util.List;

/**
 * Created by yyang on 7/31/17.
 */

class SessionUtil {
    @SuppressWarnings("deprecation")
    public static void deletePersistedCookies(Context context)
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        } else
        {
            CookieSyncManager cookieSyncMngr=CookieSyncManager.createInstance(context);
            cookieSyncMngr.startSync();
            CookieManager cookieManager=CookieManager.getInstance();
            cookieManager.removeAllCookie();
            cookieManager.removeSessionCookie();
            cookieSyncMngr.stopSync();
            cookieSyncMngr.sync();
        }
    }

    public static void persistCookies(Context context,String baseUrl,String cookiesAsString){
        if (cookiesAsString != null) {
            List<HttpCookie> cookies = HttpCookie.parse(cookiesAsString);
            for (HttpCookie cookie : cookies) {
                if ("SESSION".equals(cookie.getName())) {
                    String domain = Uri.parse(baseUrl).getHost();
                    cookie.setDomain(domain);
                    cookie.setPath("/Amelia");
                    String cookieString = cookie.getName()+"="+cookie.getValue()+"; Domain="+cookie.getDomain();
                    android.webkit.CookieManager.getInstance().setCookie(cookie.getDomain(), cookieString);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        android.webkit.CookieManager.getInstance().flush();
                    } else {
                        CookieSyncManager syncManager = CookieSyncManager.createInstance(context);
                        syncManager.sync();
                    }
                }
            }
        }

    }
}
