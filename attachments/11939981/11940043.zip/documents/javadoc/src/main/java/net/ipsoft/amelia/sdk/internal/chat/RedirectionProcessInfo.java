package net.ipsoft.amelia.sdk.internal.chat;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import java.io.IOException;

public class RedirectionProcessInfo {
    protected String processName = null;
    protected String processArgs = null;

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public String getProcessArgs() {
        return processArgs;
    }

    public void setProcessArgs(String processArgs) {
        this.processArgs = processArgs;
    }

    @Override
    public String toString() {
        return "{ " + "processName: " + processName + ", " + "processArgs: " + processArgs + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (processName != null) {
            jsonWriter.name("processName");
            jsonWriter.value(processName);
        }
        if (processArgs != null) {
            jsonWriter.name("processArgs");
            jsonWriter.value(processArgs);
        }
        jsonWriter.endObject();
    }

    public static RedirectionProcessInfo deserialize(JsonReader jsonReader) throws IOException {
        RedirectionProcessInfo redirectionProcessInfo = new RedirectionProcessInfo();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("processName".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                redirectionProcessInfo.setProcessName(jsonReader.nextString());
            } else if ("processArgs".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                redirectionProcessInfo.setProcessArgs(jsonReader.nextString());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return redirectionProcessInfo;
    }
}