package net.ipsoft.amelia.sdk.internal.restapi;

import net.ipsoft.amelia.sdk.internal.common.FileUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MmoDownloadRsp extends HttpResponse {

    private final File file;

    public MmoDownloadRsp(File file) {
        this.file = file;
    }

    @Override
    public void deserialize(InputStream inputStream) throws IOException {
        FileUtils.copyInputStreamToFile(inputStream, file);
    }
}
