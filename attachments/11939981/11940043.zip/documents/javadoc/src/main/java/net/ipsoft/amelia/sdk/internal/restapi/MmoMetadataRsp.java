package net.ipsoft.amelia.sdk.internal.restapi;

import android.util.JsonReader;

import java.io.IOException;
import java.io.Reader;

public class MmoMetadataRsp extends HttpResponse {

    public MmoMetadata mmoMetadata = null;

    @Override
    public String toString() {
        return "{ " + "mmoMetadata: " + (mmoMetadata == null ? null : mmoMetadata.hashCode()) + ", " + "error: " + (error == null ? null : error.hashCode()) + " }";
    }

    public void deserialize(Reader reader) throws IOException {
        JsonReader jsonReader = new JsonReader(reader);
        mmoMetadata = MmoMetadata.deserialize(jsonReader);
    }
}