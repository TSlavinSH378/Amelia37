package net.ipsoft.amelia.sdk.internal.restapi;

public class WhoAmIReq extends HttpRequest {

    public WhoAmIReq(String xCsrfToken) {
        super(xCsrfToken);
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/httpSession/whoami";
    }
}