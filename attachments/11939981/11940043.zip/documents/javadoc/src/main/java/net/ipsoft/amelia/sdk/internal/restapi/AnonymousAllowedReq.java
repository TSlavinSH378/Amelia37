package net.ipsoft.amelia.sdk.internal.restapi;

public class AnonymousAllowedReq extends HttpRequest {

    public AnonymousAllowedReq(String xCsrfToken) {
        super(xCsrfToken);
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/api/anonymous/allowed";
    }

}