package net.ipsoft.amelia.sdk.internal.restapi;

import java.util.LinkedHashMap;

import okhttp3.Request;

public class AnonymousCreateReq extends HttpRequest {

    public AnonymousCreateReq(String xCsrfToken) {
        super(xCsrfToken);
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/api/anonymous/create";
    }

    @Override
    public LinkedHashMap<String, String> getForm() {
        if (form == null) {
            // empty form to force request method post
            form = new LinkedHashMap<>();
        }
        return form;
    }
}