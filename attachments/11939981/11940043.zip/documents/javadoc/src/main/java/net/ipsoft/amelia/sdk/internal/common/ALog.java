package net.ipsoft.amelia.sdk.internal.common;

import android.util.Log;

public class ALog {

    public static boolean enabled;

    public static void d(String tag, String message) {
        if (enabled) {
            Log.d(tag, message);
        }
    }

    public static void w(String tag, String message) {
        if (enabled) {
            Log.w(tag, message);
        }
    }
}
