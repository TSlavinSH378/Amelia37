package net.ipsoft.amelia.sdk;

/**
 * Convenience class for clients that wish to implement a subset of methods exposed by
 * {@link IConversationListener}.
 */
public class BaseConversationListener implements IConversationListener {

    @Override
    public void onSecureInputEnabledChanged(boolean enabled){

    }

    @Override
    public void onMoodChange(String newMood, String oldMood) {

    }

    @Override
    public void onInputEnabledChanged(boolean enabled, String messageType, IAmeliaChat.InputStateChangeReason reason) {

    }


    @Override
    public void onMessageReceived(String message) {

    }

    @Override
    public void onErrorInputBlocked() {

    }

    @Override
    public void onChatHistoryClear() {

    }

    @Override
    public void onConnect() {

    }

    @Override
    public void onDisconnect() {

    }

    @Override
    public void onReconnect() {

    }

    @Override
    public void onSpeakStart() {

    }

    @Override
    public void onSpeakEnd() {

    }

    @Override
    public void outboundFinalTextMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundProgressTextMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundIdleTalkMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundNoIdleTalkMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void wolframAlphaFinalMessage(AmeliaOutboundMessage ameliaOutboundMessages) {

    }

    @Override
    public void outboundFinalErrorMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundConversationClosedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundIntegrationMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundSessionClosedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundEchoMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundMmoDownloadMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void onUploadRequest(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void onUploadSuccess(String fromUserDisplayName, String fileName, String url) {

    }

    @Override
    public void onUploadFailed(String fromUserDisplayName, String fileName, String fileType) {

    }

    @Override
    public void outboundAckRequestMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundAgentSessionChangedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundFinalReplayMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundEscalationStartedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }

    @Override
    public void outboundAmeliaMessage(AmeliaOutboundMessage ameliaOutboundMessage) {

    }
}
