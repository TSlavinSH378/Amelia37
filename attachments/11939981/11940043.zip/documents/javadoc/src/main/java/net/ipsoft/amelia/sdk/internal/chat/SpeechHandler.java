package net.ipsoft.amelia.sdk.internal.chat;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.ArrayMap;

import net.ipsoft.amelia.sdk.AmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.internal.restapi.GenerateSpeechReq;
import net.ipsoft.amelia.sdk.internal.restapi.GenerateSpeechRsp;
import net.ipsoft.amelia.sdk.internal.restapi.HttpRequestProcessor;

import java.io.IOException;
import java.net.HttpCookie;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

public class SpeechHandler {

    private Queue<Uri> speechQueue = new LinkedList<>();
    private boolean isPlaying;
    private HttpRequestProcessor httpRequestProcessor;
    private String avatarVoice;
    private Context applicationContext;
    private MediaPlayer mediaPlayer;
    private Callback callback;
    private boolean isMuted;

    public SpeechHandler(Context applicationContext, HttpRequestProcessor httpRequestProcessor, Callback callback) {
        this.applicationContext = applicationContext;
        this.httpRequestProcessor = httpRequestProcessor;
        this.callback = callback;
        mediaPlayer = new MediaPlayer();
    }

    public void setAvatarVoice(String avatarVoice) {
        this.avatarVoice = avatarVoice;
    }

    public void loadSpeech(AmeliaOutboundMessage message) {
        List<String> speech = message.getAttributes().getSpeech();
        if (speech != null && !isMuted) {
            for (String fragment : speech) {
                httpRequestProcessor.send(new GenerateSpeechReq(fragment, avatarVoice==null?"VW Julie":avatarVoice,message.getConversationId()), new GenerateSpeechRsp() {
                    @Override
                    public void run() {
                        if (error == null) {
                            speak(data.getAudio());
                        }
                    }
                });
            }
        }
    }

    private void speak(String audioUrl) {
        String url = httpRequestProcessor.getBaseUrl() + audioUrl;
        Uri uri = Uri.parse(url);
        speak(uri);
    }

    private void speak(Uri uri) {

        if (isPlaying) {
            speechQueue.add(uri);
            return;
        }

        Map<String, String> headers = new ArrayMap<>(1);
        String cookieString = "";
        for (HttpCookie cookie : httpRequestProcessor.getCookies()) {
            cookieString = cookie.getName() + "=" + cookie.getValue() + ";";
        }

        headers.put("Cookie", cookieString);
        try {

            isPlaying = true;
            callback.onSpeakStart();
            mediaPlayer.reset();
            mediaPlayer.setDataSource(applicationContext,uri,headers);
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mediaPlayer.start();
                }
            });
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    isPlaying = false;
                    callback.onSpeakEnd();
                    if (!speechQueue.isEmpty()) {
                        speak(speechQueue.poll());
                    }
                }
            });
            mediaPlayer.prepareAsync();
        } catch (IOException e) {
            isPlaying = false;
            callback.onSpeakEnd();
            e.printStackTrace();
        }
    }

    public void setMuted(boolean muted) {
        isMuted = muted;
    }

    public void stopSpeech(){
        if(isPlaying) {
            mediaPlayer.stop();// Stop it
            isPlaying = false;
            callback.onSpeakEnd();
        }
    }
    public interface Callback {
        void onSpeakStart();
        void onSpeakEnd();
    }
}
