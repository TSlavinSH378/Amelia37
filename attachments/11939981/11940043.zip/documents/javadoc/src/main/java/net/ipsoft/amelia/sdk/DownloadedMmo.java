package net.ipsoft.amelia.sdk;

import android.net.Uri;


public class DownloadedMmo {

    /*
     * Uri of the downloaded MMO, typically a file on disc
     */
    public final Uri uri;

    /*
     * mimeType of downloaded MMO
     */
    public final String mimeType;

    /*
     * recent error when trying to download this MMO
     */
    public final AmeliaError recentError;

    public DownloadedMmo(Uri uri, String mimeType) {
        this.uri = uri;
        this.mimeType = mimeType;
        this.recentError = null;
    }

    public DownloadedMmo(AmeliaError recentError) {
        this.uri = null;
        this.mimeType = null;
        this.recentError = recentError;
    }
}
