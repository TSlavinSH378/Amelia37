package net.ipsoft.amelia.sdk.internal.restapi;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import java.io.IOException;

public class WhoAmIRspData {

    protected String userId = null;
    protected String email = null;
    protected String name = null;
    protected boolean anonymous = false;
    protected boolean agent = false;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public boolean getAgent() {
        return agent;
    }

    public void setAgent(boolean agent) {
        this.agent = agent;
    }

    @Override
    public String toString() {
        return "{ " + "userId: " + userId + ", " + "email: " + email + ", " + "name: " + name + ", " + "anonymous: " + anonymous + ", " + "agent: " + agent + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (userId != null) {
            jsonWriter.name("userId");
            jsonWriter.value(userId);
        }
        if (email != null) {
            jsonWriter.name("email");
            jsonWriter.value(email);
        }
        if (name != null) {
            jsonWriter.name("name");
            jsonWriter.value(name);
        }
        jsonWriter.name("anonymous");
        jsonWriter.value(anonymous);
        jsonWriter.name("agent");
        jsonWriter.value(agent);
        jsonWriter.endObject();
    }

    public static WhoAmIRspData deserialize(JsonReader jsonReader) throws IOException {
        WhoAmIRspData whoAmIRspData = new WhoAmIRspData();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("userId" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                whoAmIRspData.setUserId(jsonReader.nextString());
            } else if ("email" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                whoAmIRspData.setEmail(jsonReader.nextString());
            } else if ("name" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                whoAmIRspData.setName(jsonReader.nextString());
            } else if ("anonymous" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                whoAmIRspData.setAnonymous(jsonReader.nextBoolean());
            } else if ("agent" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                whoAmIRspData.setAgent(jsonReader.nextBoolean());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return whoAmIRspData;
    }
}