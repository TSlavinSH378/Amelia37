package net.ipsoft.amelia.sdk.internal.restapi;

import org.json.JSONObject;

import java.util.LinkedHashMap;


public class NewConversationReq extends HttpRequest {

    public String ui = null;
    public long cts = 0L;
    public String domainCode = null;
    public String bpnVariables = null;

    public NewConversationReq(String xCsrfToken, String ui, long cts, String domainCode, String bpnVariables) {
        super(xCsrfToken);
        this.ui = ui;
        this.cts = cts;
        this.domainCode = domainCode;
        this.bpnVariables = bpnVariables;
        this.contentType = "application/json;charset=utf-8";
    }

    @Override
    public String toString() {
        return "{ " + "xCsrfToken: " + xCsrfToken + ", " + "userInterface: " + ui + ", " + "cts: " + cts + ", " + "domainCode: " + domainCode + ", " + "bpnVariables: " + bpnVariables + " }";
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/api/conversations/new";
    }

    @Override
    public JSONObject getJSONObject(){
        if(jsonObject==null) {
            jsonObject = new JSONObject();
            try {
                jsonObject.put("userInterface", String.valueOf(ui));
                jsonObject.put("domainCode", String.valueOf(domainCode));
            } catch (Exception ignore) {
            }
        }
        return jsonObject;
    }

}