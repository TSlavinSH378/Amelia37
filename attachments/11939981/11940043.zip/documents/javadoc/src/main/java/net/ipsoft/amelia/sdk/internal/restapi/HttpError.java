package net.ipsoft.amelia.sdk.internal.restapi;

public class HttpError {

	public final Code code;
	public final int httpCode;
    public final String message;
    public final Throwable cause;

	public HttpError(Code code, int httpCode, String message, Throwable cause) {
		this.code = code;
		this.httpCode = httpCode;
        this.message = message;
		this.cause = cause;
	}

	public enum Code {
		badRequestError,
		networkError,
        backendError
	}

	public String toString(){
		return "httpCode " + httpCode + " message '" + message + "' cause '" + cause + "'";
	}
}