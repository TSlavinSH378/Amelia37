package net.ipsoft.amelia.sdk.internal.restapi;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.webkit.CookieSyncManager;

import net.ipsoft.amelia.sdk.internal.common.ALog;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.CertificateException;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.JavaNetCookieJar;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class HttpRequestProcessor extends Handler {

    public static final String MIME_TYPE_JSON = "application/json;charset=UTF-8";
    public static final String MIME_TYPE_PLAIN = "text/plain; text/html;";

    protected OkHttpClient client;
    protected CookieManager cookieManager;
    private ThreadPoolExecutor threadPoolExecutor;
    private String baseUrl;

    public HttpRequestProcessor(String baseUrl) {
        cookieManager = new CookieManager();
        threadPoolExecutor = (ThreadPoolExecutor) Executors.newFixedThreadPool(5);
        this.baseUrl = baseUrl;
    }

    public List<HttpCookie> getCookies() {
        return cookieManager.getCookieStore().getCookies();
    }

    public boolean addCookies(String cookiesAsString) {
        if (cookiesAsString != null) {
            List<HttpCookie> cookies = HttpCookie.parse(cookiesAsString);
            for (HttpCookie cookie : cookies) {
                if ("SESSION".equals(cookie.getName())) {
                    String domain = Uri.parse(baseUrl).getHost();
                    cookie.setDomain(domain);
                    cookie.setPath("/Amelia");
                    cookieManager.getCookieStore().add(null, cookie);
                    return true;
                }
            }
        }
        return false;
    }

    //only for use in testing
    public OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder().connectTimeout(40, TimeUnit.SECONDS)
                    .writeTimeout(40, TimeUnit.SECONDS)
                    .readTimeout(40, TimeUnit.SECONDS)
                    .cookieJar(new JavaNetCookieJar(cookieManager));
            builder.sslSocketFactory(sslSocketFactory, (X509TrustManager)trustAllCerts[0]);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void clearCookies(){
        cookieManager.getCookieStore().removeAll();
    }
    public FullRequest send(final HttpRequest request, final HttpResponse response) {
        final FullRequest fullRequest = new FullRequest(request, response);

        // create a message to be used to return to the UI thread
        final Message msg = Message.obtain(this);
        msg.obj = fullRequest;
        threadPoolExecutor.execute(new Runnable() {
            public void run() {
                send(fullRequest, msg);
            }
        });
        return fullRequest;
    }

    public OkHttpClient getClient() {
        if (client == null) {
            OkHttpClient.Builder builder = new OkHttpClient.Builder()
                    .connectTimeout(40, TimeUnit.SECONDS)
                    .writeTimeout(40, TimeUnit.SECONDS)
                    .readTimeout(40, TimeUnit.SECONDS)
                    .cookieJar(new JavaNetCookieJar(cookieManager))
                    .followRedirects(false);
            client = builder.build();
        }
        return client;
    }

    protected void setHeaders(Request.Builder builder, FullRequest fullRequest) {
        builder.header("Accept", fullRequest.request.accept());
        fullRequest.request.writeHeaders(builder);
    }

    protected void postForm(Request.Builder builder, FullRequest fullRequest) {
        FormBody.Builder formBuilder = new FormBody.Builder();
        for (Map.Entry<String, String> keyValuePair : fullRequest.request.getForm().entrySet()) {
            formBuilder.add(keyValuePair.getKey(), keyValuePair.getValue());
        }
        RequestBody formBody = formBuilder.build();
        builder.post(formBody);
    }

    protected void postFile(Request.Builder builder, FullRequest fullRequest) {
        MediaType mediaType = MediaType.parse(fullRequest.request.getContentType());
        File file = fullRequest.request.getFile();
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("fileName", file.getName())
                .addFormDataPart("file", file.getName(), RequestBody.create(mediaType, file))
                .build();

        builder.post(requestBody);
    }

    protected void postJSON(Request.Builder builder, FullRequest fullRequest){
        MediaType mediaType = MediaType.parse(fullRequest.request.getContentType());
        RequestBody requestBody = RequestBody.create(mediaType,fullRequest.request.getJSONObject().toString());
        builder.post(requestBody);
    }


    private void send(FullRequest fullRequest, Message msg) {

        try {
            fullRequest.request.prepare();
        } catch (IOException e) {
            fullRequest.response.error = new HttpError(HttpError.Code.badRequestError, -1, e.getMessage(), e);
            msg.sendToTarget();
            e.printStackTrace();
            return;
        }

        try {

            //OkHttpClient client = getClient();
            OkHttpClient client = getClient();


            Request.Builder builder = new Request.Builder();

            builder.url(fullRequest.request.getUrl(baseUrl));

            if (fullRequest.request.getForm() != null) {
                postForm(builder, fullRequest);
            } else if (fullRequest.request.getFile() != null) {
                postFile(builder, fullRequest);
            } else if(fullRequest.request.getJSONObject()!=null) {
                postJSON(builder, fullRequest);
            }else {
                builder.get();
            }

            setHeaders(builder, fullRequest);

            Request request = builder.build();

            fullRequest.okHttpRequest = request;

            ALog.d("sdk", request.url().toString());

            // blocking call
            fullRequest.call = client.newCall(request);
            Response response = fullRequest.call.execute();

            fullRequest.okHttpResponse = response;

            if (response.isSuccessful()) {
                try {
                    MediaType mediaType = response.body().contentType();
                    if (mediaType != null) {
                        fullRequest.response.setMimeType(mediaType.type() + "/" + mediaType.subtype());
                    }
                    processBody(fullRequest, response);
                    msg.sendToTarget();
                } catch (IOException e) {
                    fullRequest.response.error = new HttpError(HttpError.Code.backendError, response.code(), response.message(), e);
                    msg.sendToTarget();
                    e.printStackTrace();
                }
            } else {
                fullRequest.response.error = new HttpError(HttpError.Code.backendError, response.code(), response.message(), null);
                msg.sendToTarget();
                ALog.w("sdk error", fullRequest.response.error.toString());
            }
        } catch (IOException e) {
            fullRequest.response.error = new HttpError(HttpError.Code.networkError, -1, null, e);
            msg.sendToTarget();
            e.printStackTrace();
        }
    }

    protected void processBody(FullRequest fullRequest, Response response) throws IOException {
        switch (fullRequest.request.accept()) {
            case MIME_TYPE_JSON:
                Reader reader = response.body().charStream();
                try {
                    fullRequest.response.deserialize(reader);
                    fullRequest.response.setCookies(response.header("Set-Cookie"));
                } catch (IOException e) {
                    throw e;
                } finally {
                    reader.close();
                }
                break;
            case MIME_TYPE_PLAIN:
                fullRequest.response.deserialize(response.body().string());
                break;
            default: // */*
                InputStream inputStream = response.body().byteStream();
                try {
                    fullRequest.response.deserialize(inputStream);
                } catch (IOException e) {
                    throw e;
                } finally {
                    inputStream.close();
                }
                break;
        }
    }

    public void handleMessage(Message msg) {
        FullRequest fullRequest = (FullRequest) msg.obj;
        fullRequest.response.run();
    }

    public void shutdown() {
        threadPoolExecutor.shutdown();
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public static class FullRequest {
        public final HttpRequest request;
        public final HttpResponse response;
        public Request okHttpRequest;
        public Response okHttpResponse;
        public Call call;

        public FullRequest(HttpRequest request, HttpResponse response) {
            this.request = request;
            this.response = response;
        }

        public void cancel() {
            response.cancel();
            if (call != null) {
                call.cancel();
            }
        }
    }
}
