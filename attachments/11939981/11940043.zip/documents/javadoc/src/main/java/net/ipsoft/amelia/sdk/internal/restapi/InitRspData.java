package net.ipsoft.amelia.sdk.internal.restapi;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import java.io.IOException;

public class InitRspData {

    protected String csrfToken = null;
    protected String SESSION = null;

    public String getCsrfToken() {
        return csrfToken;
    }

    public void setX_CSRF_TOKEN(String X_CSRF_TOKEN) {
        this.csrfToken = X_CSRF_TOKEN;
    }

    public String getSESSION() {
        return SESSION;
    }

    public void setSESSION(String SESSION) {
        this.SESSION = SESSION;
    }

    @Override
    public String toString() {
        return "{ " + "csrfToken: " + csrfToken + ", " + "SESSION: " + SESSION + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (csrfToken != null) {
            jsonWriter.name("csrfToken");
            jsonWriter.value(csrfToken);
        }
        if (SESSION != null) {
            jsonWriter.name("SESSION");
            jsonWriter.value(SESSION);
        }
        jsonWriter.endObject();
    }

    public static InitRspData deserialize(JsonReader jsonReader) throws IOException {
        InitRspData initRspData = new InitRspData();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("csrfToken" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                initRspData.setX_CSRF_TOKEN(jsonReader.nextString());
            } else if ("SESSION" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                initRspData.setSESSION(jsonReader.nextString());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return initRspData;
    }
}