package net.ipsoft.amelia.sdk;

import android.content.Context;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.RequiresApi;

/**
 * Immutable class storing credentials and login type.
 */
public class LoginOptions implements Parcelable {

    public final AuthSystem authSystem;
    public final String username;
    public final String password;
    public final String sessionCookie;
    public final Context context;

    private LoginOptions(AuthSystem authSystem, String username, String password, String sessionCookie, Context context) {
        this.authSystem = authSystem;
        this.username = username;
        this.password = password;
        this.sessionCookie = sessionCookie;
        this.context = context;
    }

    /**
     *
     * @param authSystem auth system to use
     * @param username username
     * @param password password
     */
    public LoginOptions(AuthSystem authSystem, String username, String password) {
        this(authSystem, username, password, null, null);
    }

    /**
     * This constructor assumes a non-internal auth system has been used and the session cookie
     * is expected to be found in the app's WebView cookie store.
     *
     * @param authSystem auth system to use
     */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public LoginOptions(AuthSystem authSystem) {
        this(authSystem, null, null, null, null);
    }

    /**
     * This constructor assumes a non-internal auth system has been used and the session cookie
     * is expected to be found in the app's WebView cookie store. For use with apps supporting
     * Android versions before Lollipop.
     *
     * @param authSystem selected auth system
     * @param context context
     */
    public LoginOptions(AuthSystem authSystem, Context context) {
        this(authSystem, null, null, null, context);
    }

    /**
     * This constructor assumes a non-internal auth system has been used and the session cookie
     * is provided here.
     *
     * @param authSystem selected auth system
     * @param sessionCookie
     */
    public LoginOptions(AuthSystem authSystem, String sessionCookie) {
        this(authSystem, null, null, sessionCookie, null);
    }

    @Override
    public String toString() {
        return "{ " +
                "authSystem: " + authSystem + ", " +
                "username: " + username + ", " +
                "password: " + password + ", " +
                "sessionCookie: " + sessionCookie +
                " }";
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeParcelable(authSystem, 0);
        out.writeString(username);
        out.writeString(password);
        out.writeString(sessionCookie);
    }

    public static final Parcelable.Creator<LoginOptions> CREATOR = new Parcelable.Creator<LoginOptions>() {
        @Override
        public LoginOptions createFromParcel(Parcel in) {
            LoginOptions obj = new LoginOptions(
                    (AuthSystem) in.readParcelable(getClass().getClassLoader()),
                    in.readString(),
                    in.readString(),
                    in.readString(),
                    null
            );
            return obj;
        }

        @Override
        public LoginOptions[] newArray(int size) {
            return new LoginOptions[size];
        }
    };
}