package net.ipsoft.amelia.sdk.internal.restapi;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import java.io.IOException;

public class NewConversationRspData {

    protected String sessionId = null;
    protected String conversationId = null;

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    @Override
    public String toString() {
        return "{ " + "sessionId: " + sessionId + ", " + "conversationId: " + conversationId + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        jsonWriter.name("sessionId");
        jsonWriter.value(sessionId);
        jsonWriter.name("conversationId");
        jsonWriter.value(conversationId);
        jsonWriter.endObject();
    }

    public static NewConversationRspData deserialize(JsonReader jsonReader) throws IOException {
        NewConversationRspData newConversationRspData = new NewConversationRspData();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("sessionId" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                newConversationRspData.setSessionId(jsonReader.nextString());
            } else if ("conversationId" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                newConversationRspData.setConversationId(jsonReader.nextString());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return newConversationRspData;
    }
}