package net.ipsoft.amelia.sdk;

import net.ipsoft.amelia.sdk.internal.common.AmeliaChat;

import java.util.List;

public enum DomainSelectionMode {

    /**
     * A domain code must be supplied using {@link AmeliaChatBuilder#setDomainCode(String)}
     */
    predefined,

    /**
     * The client will select a domain from the list of domains the user can
     * access. If there is more than one, a domainFail message will be sent.
     * If there is one, it will be selected, unless it is hidden.
     * <p>
     * This is the default value
     */
    automatic,

    /**
     * client will fetch all domains the user can access, and pass them out in
     * a {@link ISessionListener#onDomainSelectionRequired(List)}.
     * The listener is responsible for setting up some manner of selecting
     * a domain code, and starting the conversation manually.
     */
    manual
}
