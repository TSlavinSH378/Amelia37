package net.ipsoft.amelia.sdk;

public class SpeechParams {

    public final boolean enabled;
    public final boolean muted;

    /**
     *
     * @param enabled permanently enable or disable text to speech
     * @param muted initial state for text to speech
     */
    public SpeechParams(boolean enabled, boolean muted) {
        this.enabled = enabled;
        this.muted = muted;
    }

    /**
     *
     * @param enabled permanently enable or disable text to speech
     */
    public SpeechParams(boolean enabled) {
        this(enabled, false);
    }
}
