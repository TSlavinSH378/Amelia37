package net.ipsoft.amelia.sdk.internal.restapi;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import java.io.IOException;

public class GenerateSpeechRspData {

    protected String id;
    protected String audio;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAudio() {
        return audio;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }

    @Override
    public String toString() {
        return "{ " + "id: " + id + ", " + "audio: " + audio + " }";
    }

    public static GenerateSpeechRspData deserialize(JsonReader jsonReader) throws IOException {
        GenerateSpeechRspData generateSpeechRspData = new GenerateSpeechRspData();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("id" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                generateSpeechRspData.setId(jsonReader.nextString());
            } else if ("audio" .equals(name) && jsonReader.peek() != JsonToken.NULL) {
                generateSpeechRspData.setAudio(jsonReader.nextString());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return generateSpeechRspData;
    }
}