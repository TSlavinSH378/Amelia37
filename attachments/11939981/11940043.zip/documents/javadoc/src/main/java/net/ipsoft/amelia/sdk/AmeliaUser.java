package net.ipsoft.amelia.sdk;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Immutable representation of an Amelia user
 */
public class AmeliaUser {
    private String name;

    private String email;

    private String userId;

    private ArrayList<String> globalAuthorities;

    private ArrayList<String> domains;

    private ArrayList<String> domainCodes;

    private ArrayList<String> domainAuthorities;

    private boolean isAnonymous;

    private boolean agent;


    /**
     *
     * @param name user's name
     * @param email user's email
     * @param isAnonymous true if user is logged in anonymously
     */
    public AmeliaUser(String name, String email, boolean isAnonymous) {
        this.name = name;
        this.email = email;
        this.isAnonymous = isAnonymous;
    }

    public AmeliaUser(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public ArrayList<String> getGlobalAuthorities() {
        return globalAuthorities;
    }

    public void setGlobalAuthorities(ArrayList<String> globalAuthorities) {
        this.globalAuthorities = globalAuthorities;
    }

    public ArrayList<String> getDomains() {
        return domains;
    }

    public void setDomains(ArrayList<String> domains) {
        this.domains = domains;
    }

    public ArrayList<String> getDomainCodes() {
        return domainCodes;
    }

    public void setDomainCodes(ArrayList<String> domainCodes) {
        this.domainCodes = domainCodes;
    }

    public ArrayList<String> getDomainAuthorities() {
        return domainAuthorities;
    }

    public void setDomainAuthorities(ArrayList<String> domainAuthorities) {
        this.domainAuthorities = domainAuthorities;
    }

    public boolean isAnonymous() {
        return isAnonymous;
    }

    public void setAnonymous(boolean anonymous) {
        isAnonymous = anonymous;
    }

    public boolean isAgent() {
        return agent;
    }

    public void setAgent(boolean agent) {
        this.agent = agent;
    }

    @Override
    public String toString() {
        return "{ name: " + name + ", email: " + email + ", isAnonymous: " + isAnonymous + " }";
    }
}