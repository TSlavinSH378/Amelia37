package net.ipsoft.amelia.sdk;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import net.ipsoft.amelia.sdk.internal.chat.SelectionUtteranceMetadata;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;

@SuppressWarnings("all")
public class FormInputData {
    protected String name = null;
    protected String nameForDisplay = null;
    protected String formType = null;
    protected ArrayList<FormInputField> fields = new ArrayList<>();
    protected SelectionUtteranceMetadata selectionUtteranceMetadata = null;
    protected String allowedUserInputs = null;

    /**
     * A name for the form, useful as id
     *
     * @return form name
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * A display name for the form section
     *
     * @return display name
     */
    public String getNameForDisplay() {
        return nameForDisplay;
    }

    public void setNameForDisplay(String nameForDisplay) {
        this.nameForDisplay = nameForDisplay;
    }

    /**
     * The type of the form, can be used to make decisions on placement or layout
     *
     * @return form type
     */
    public String getFormType() {
        return formType;
    }

    public void setFormType(String formType) {
        this.formType = formType;
    }

    /**
     * The fields in this form
     * @return form fields
     */
    public ArrayList<FormInputField> getFields() {
        return fields;
    }

    public void setFields(ArrayList<FormInputField> fields) {
        this.fields = fields;
    }

    /**
     * A struct indicating how to formulate the message in the chat window after submission
     *
     * @return selection utterance metadata
     */
    public SelectionUtteranceMetadata getSelectionUtteranceMetadata() {
        return selectionUtteranceMetadata;
    }

    public void setSelectionUtteranceMetadata(SelectionUtteranceMetadata selectionUtteranceMetadata) {
        this.selectionUtteranceMetadata = selectionUtteranceMetadata;
    }

    /**
     * What manner of input Amelia will accept, must be:
     * <ol>
     *     <li>FORM_ONLY</li>
     *     <li>CHAT_ONLY</li>
     *     <li>BOTH</li>
     * </ol>
     * If FORM_ONLY, the inputDisabled event will be called.
     *
     * @return allowed user inputs
     */
    public String getAllowedUserInputs() {
        return allowedUserInputs;
    }

    public void setAllowedUserInputs(String allowedUserInputs) {
        this.allowedUserInputs = allowedUserInputs;
    }

    @Override
    public String toString() {
        return "{ " + "name: " + name + ", " + "nameForDisplay: " + nameForDisplay + ", " + "formType: " + formType + ", " + "fields: " + (fields == null ? null : fields.hashCode()) + ", " + "selectionUtteranceMetadata: " + (selectionUtteranceMetadata == null ? null : selectionUtteranceMetadata.hashCode()) + ", " + "allowedUserInputs: " + allowedUserInputs + " }";
    }

    public String serialize() throws IOException {
        StringWriter stringWriter = new StringWriter();
        BufferedWriter bufferedWriter = new BufferedWriter(stringWriter);
        JsonWriter jsonWriter = new JsonWriter(bufferedWriter);
        serialize(jsonWriter);
        jsonWriter.close();
        return stringWriter.toString();
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (name != null) {
            jsonWriter.name("name");
            jsonWriter.value(name);
        }
        if (nameForDisplay != null) {
            jsonWriter.name("nameForDisplay");
            jsonWriter.value(nameForDisplay);
        }
        if (formType != null) {
            jsonWriter.name("formType");
            jsonWriter.value(formType);
        }
        if (fields != null) {
            jsonWriter.name("fields");
            jsonWriter.beginArray();
            for (int i = 0; i < fields.size(); i++) {
                fields.get(i).serialize(jsonWriter);
            }
            jsonWriter.endArray();
        }
        if (selectionUtteranceMetadata != null) {
            jsonWriter.name("selectionUtteranceMetadata");
            selectionUtteranceMetadata.serialize(jsonWriter);
        }
        if (allowedUserInputs != null) {
            jsonWriter.name("allowedUserInputs");
            jsonWriter.value(allowedUserInputs);
        }
        jsonWriter.endObject();
    }

    public static FormInputData deserialize(JSONObject jsonObject) throws JSONException {
        FormInputData formInputData = new FormInputData();

        formInputData.setName(jsonObject.optString("name"));
        formInputData.setNameForDisplay(jsonObject.optString("nameForDisplay"));
        formInputData.setFormType(jsonObject.optString("formType"));
        if (jsonObject.has("fields") && !jsonObject.isNull("fields")) {
            ArrayList fields = new ArrayList<FormInputField>();
            JSONArray jsonArray = jsonObject.getJSONArray("fields");
            for (int i = 0; i < jsonArray.length(); i++) {
                fields.add(FormInputField.deserialize(jsonArray.getJSONObject(i)));
            }
            formInputData.setFields(fields);
        }
        if (jsonObject.has("selectionUtteranceMetadata") && !jsonObject.isNull("selectionUtteranceMetadata")) {
            formInputData.setSelectionUtteranceMetadata(SelectionUtteranceMetadata.deserialize(jsonObject.getJSONObject("selectionUtteranceMetadata")));
        }
        formInputData.setAllowedUserInputs(jsonObject.optString("allowedUserInputs"));
        return formInputData;
    }

    public static FormInputData deserialize(JsonReader formReader) throws IOException {
        FormInputData formInputData = new FormInputData();
        String formInputDataString = formReader.nextString();

        StringReader reader = new StringReader(formInputDataString);
        BufferedReader bufferedReader = new BufferedReader(reader);
        JsonReader jsonReader = new JsonReader(bufferedReader);

        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("name".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputData.setName(jsonReader.nextString());
            } else if ("nameForDisplay".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputData.setNameForDisplay(jsonReader.nextString());
            } else if ("formType".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputData.setFormType(jsonReader.nextString());
            } else if ("fields".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ArrayList<FormInputField> outArray = new ArrayList<>();
                jsonReader.beginArray();
                while (jsonReader.hasNext()) {
                    if (jsonReader.peek() != JsonToken.NULL) {
                        FormInputField item = FormInputField.deserialize(jsonReader);
                        outArray.add(item);
                    } else {
                        jsonReader.skipValue();
                    }
                }
                jsonReader.endArray();
                formInputData.setFields(outArray);
            } else if ("selectionUtteranceMetadata".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputData.setSelectionUtteranceMetadata(SelectionUtteranceMetadata.deserialize(jsonReader));
            } else if ("allowedUserInputs".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputData.setAllowedUserInputs(jsonReader.nextString());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        jsonReader.close();

        return formInputData;
    }
}