package net.ipsoft.amelia.sdk.internal.restapi;

public class MmoMetadataReq extends HttpRequest {
    public String key = null;
    public String conversationId;

    public MmoMetadataReq(String xCsrfToken, String key, String conversationId) {
        super(xCsrfToken);
        this.key = key;
        this.conversationId = conversationId;
    }

    @Override
    public String toString() {
        return "{ " + "xCsrfToken: " + xCsrfToken + ", " + "key: " + key + ", " + "conversationId: " + conversationId + " }";
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/getKeyMetadata?key=" + key + "&conversationId=" + conversationId;
    }
}