package net.ipsoft.amelia.sdk.internal.restapi;

public class AuthSystemsReq extends HttpRequest {

    public AuthSystemsReq() {
    }

    @Override
    public String toString() {
        return "{}";
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/api/loginwindow/authSystems";
    }
}