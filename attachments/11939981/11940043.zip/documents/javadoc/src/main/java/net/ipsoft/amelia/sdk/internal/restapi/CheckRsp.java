package net.ipsoft.amelia.sdk.internal.restapi;

public class CheckRsp extends HttpResponse {

}