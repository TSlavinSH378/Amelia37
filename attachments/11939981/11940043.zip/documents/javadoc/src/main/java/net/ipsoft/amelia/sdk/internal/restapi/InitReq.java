package net.ipsoft.amelia.sdk.internal.restapi;

public class InitReq extends HttpRequest {
    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/api/init";
    }
}