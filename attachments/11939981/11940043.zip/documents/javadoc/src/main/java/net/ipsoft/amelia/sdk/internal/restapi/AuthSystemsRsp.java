package net.ipsoft.amelia.sdk.internal.restapi;

import android.util.JsonReader;

import net.ipsoft.amelia.sdk.AuthSystem;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

public class AuthSystemsRsp extends HttpResponse {

    public ArrayList<AuthSystem> authSystems = new ArrayList<>();

    public AuthSystemsRsp() {
    }

    @Override
    public String toString() {
        return "{ " + "authSystems: " + (authSystems == null ? null : authSystems.hashCode()) + ", " + "error: " + (error == null ? null : error.hashCode()) + " }";
    }

    public void deserialize(Reader reader) throws IOException {
        try {
            JsonReader jsonReader = new JsonReader(reader);
            jsonReader.beginArray();
            while (jsonReader.hasNext()) {
                authSystems.add(AuthSystem.deserialize(jsonReader));
            }
            jsonReader.endArray();
        }catch(Exception ignore){}
    }
}