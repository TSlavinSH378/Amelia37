package net.ipsoft.amelia.sdk.internal.restapi;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;

public class MmoUploadRsp extends HttpResponse {

    protected String body;

    public MmoUploadRsp() {
    }

    @Override
    public void deserialize(String body) {
        this.body = body;
    }

}
