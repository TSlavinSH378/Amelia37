package net.ipsoft.amelia.sdk.internal.restapi;

public class AmeliaRestApi implements IAmeliaBackendApi {
    private HttpRequestProcessor httpRequestProcessor;

    public Callback callback;

    public AmeliaRestApi(HttpRequestProcessor httpRequestProcessor) {
        this.httpRequestProcessor = httpRequestProcessor;
    }

    @Override
    public void setCallback(Callback callback) {
        this.callback = callback;
    }

    @Override
    public void initReq() {
        httpRequestProcessor.send(new InitReq(), new InitRsp() {
            @Override
            public void run() {
                callback.initRsp(this);
            }
        });
    }

    @Override
    public void whoAmIReq(String xCsrfToken) {
        httpRequestProcessor.send(new WhoAmIReq(xCsrfToken), new WhoAmIRsp() {
            @Override
            public void run() {
                callback.whoAmIRsp(this);
            }
        });
    }

    @Override
    public void checkSessionRequest(String xCsrfToken) {
        httpRequestProcessor.send(new CheckReq(xCsrfToken), new CheckRsp() {
            @Override
            public void run() {
                callback.checkSessionRsp(this);
            }
        });
    }

    @Override
    public void authSystems() {
        httpRequestProcessor.send(new AuthSystemsReq(), new AuthSystemsRsp() {
            @Override
            public void run() {
                callback.authSystems(this);
            }
        });
    }

    @Override
    public void anonymousAllowedReq(String xCsrfToken) {
        httpRequestProcessor.send(new AnonymousAllowedReq(xCsrfToken), new AnonymousAllowedRsp() {
            @Override
            public void run() {
                callback.anonymousAllowedRsp(this);
            }
        });
    }

    @Override
    public void anonymousCreateReq(String xCsrfToken) {
        httpRequestProcessor.send(new AnonymousCreateReq(xCsrfToken), new AnonymousCreateRsp() {
            @Override
            public void run() {
                callback.anonymousCreateRsp(this);
            }
        });
    }

    @Override
    public void loginReq(LoginReq loginReq) {
        httpRequestProcessor.send(loginReq, new LoginRsp() {
            @Override
            public void run() {
                callback.loginRsp(this);
            }
        });
    }

    @Override
    public void logoutReq() {
        httpRequestProcessor.send(new LogoutReq(), new LogoutRsp() {
            @Override
            public void run() {
                callback.logoutRsp(this);
            }
        });
    }

    @Override
    public void domainsReq(String xCsrfToken) {
        httpRequestProcessor.send(new DomainsReq(xCsrfToken), new DomainsRsp() {
            @Override
            public void run() {
                callback.domainsRsp(this);
            }
        });
    }

    @Override
    public void newConversationReq(NewConversationReq newConversationReq) {
        httpRequestProcessor.send(newConversationReq, new NewConversationRsp() {
            @Override
            public void run() {
                callback.newConversationRsp(this);
            }
        });
    }

    @Override
    public String baseUrl() {
        return httpRequestProcessor.getBaseUrl();
    }

    @Override
    public boolean addCookies(String cookies) {
        return httpRequestProcessor.addCookies(cookies);
    }

    @Override
    public void clearCookies() {
         httpRequestProcessor.clearCookies();
    }
}