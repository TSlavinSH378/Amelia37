package net.ipsoft.amelia.sdk;

import android.util.ArrayMap;
import android.util.JsonReader;
import android.util.JsonToken;

import java.io.IOException;
import java.util.Map;

/**
 * This class is mainly a direct reflection of the JSON the comes with each conversation message
 * from Amelia. However it has been enriched with the Stomp headers accompanying the message and
 * it contains any detected download / upload messages.
 */
public class AmeliaOutboundMessage {
    
    protected String sourceClass = null;
    protected String messageText = null;
    protected AmeliaOutboundMessageAttributes attributes = null;
    protected String messageType = null;
    protected String inResponseToMessageId = null;
    protected boolean retry = false;
    protected String sourceSessionId = null;
    protected String conversationId = null;
    protected String fromUserDisplayName = null;
    protected String id = null;
    protected String voice = null;
    protected Map<String, String> headers = new ArrayMap<>();
    protected DownloadMessage downloadMessage;
    protected UploadMessage uploadMessage;


    public String getVoice() {
        return voice;
    }

    public void setVoice(String voice) {
        this.voice = voice;
    }

    /**
     * The server side generator of this comment
     *
     * @return server side generator of this comment
     */
    public String getSourceClass() {
        return sourceClass;
    }

    public void setSourceClass(String sourceClass) {
        this.sourceClass = sourceClass;
    }

    /**
     * the text of the message
     *
     * @return message text
     */
    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    /**
     * An object that differs between message types. Will not be necessary to use in most cases.
     *
     * @return outbound message attributes
     */
    public AmeliaOutboundMessageAttributes getAttributes() {
        return attributes;
    }

    public void setAttributes(AmeliaOutboundMessageAttributes attributes) {
        this.attributes = attributes;
    }

    /**
     * The type of the message
     *
     * @return message type
     */
    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    /**
     * The id of the message this is a direct response to, if a response
     *
     * @return id of the message this is a direct response to
     */
    public String getInResponseToMessageId() {
        return inResponseToMessageId;
    }

    public void setInResponseToMessageId(String inResponseToMessageId) {
        this.inResponseToMessageId = inResponseToMessageId;
    }

    /**
     * TBD
     *
     * @return retry
     */
    public boolean getRetry() {
        return retry;
    }

    public void setRetry(boolean retry) {
        this.retry = retry;
    }

    /**
     * The id of the session
     *
     * @return session id
     */
    public String getSourceSessionId() {
        return sourceSessionId;
    }

    public void setSourceSessionId(String sourceSessionId) {
        this.sourceSessionId = sourceSessionId;
    }

    /**
     * The conversation id
     *
     * @return conversation id
     */
    public String getConversationId() {
        return conversationId;
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    /**
     * The name of the Amelia user responding
     *
     * @return name of Amelia user
     */
    public String getFromUserDisplayName() {
        return fromUserDisplayName;
    }

    public void setFromUserDisplayName(String fromUserDisplayName) {
        this.fromUserDisplayName = fromUserDisplayName;
    }

    /**
     * The message id
     *
     * @return message id
     */
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets a Stomp header by name
     *
     * @param name
     * @return stomp header
     */
    public String getHeader(String name) {
        return headers.get(name);
    }

    /**
     * Gets all stomp headers
     *
     * @return all headers
     */
    public Map<String, String> getHeaders() {
        return headers;
    }

    /**
     * For internal use only
     *
     * @param name
     * @param value
     */
    public void addHeader(String name, String value) {
        headers.put(name, value);
    }

    /**
     * If set, file(s) are ready for download
     *
     * @return description of downloadable files
     */
    public DownloadMessage getDownloadMessage() {
        return downloadMessage;
    }

    public void setDownloadMessage(DownloadMessage downloadMessage) {
        this.downloadMessage = downloadMessage;
    }

    /**
     * If set, a file has been requested
     *
     * @return description of requested files
     */
    public UploadMessage getUploadMessage() {
        return uploadMessage;
    }

    public void setUploadMessage(UploadMessage uploadMessage) {
        this.uploadMessage = uploadMessage;
    }

    /**
     * Helper method to work out whether the message originates the client (self) or Amelia (or some Agent)
     *
     * @return true if message is to be displayed as if the client (self) was saying something
     */
    public boolean isSelfEcho() {
        String selfEcho = getHeader("X-Amelia-Self-Echo").trim();
        return "true".equals(selfEcho);
    }

    @Override
    public String toString() {
        return "{ " +
                "sourceClass: " + sourceClass + ", " +
                "messageText: " + messageText + ", " +
                "attributes: " + (attributes == null ? null : attributes.hashCode()) + ", " +
                "messageType: " + messageType + ", " +
                "inResponseToMessageId: " + inResponseToMessageId + ", " +
                "retry: " + retry + ", " +
                "sourceSessionId: " + sourceSessionId + ", " +
                "conversationId: " + conversationId + ", " +
                "fromUserDisplayName: " + fromUserDisplayName + ", " +
                "id: " + id +
                "voice: "+ voice +
                " }";
    }

    public static AmeliaOutboundMessage deserialize(JsonReader jsonReader) throws IOException {
        AmeliaOutboundMessage ameliaOutboundMessage = new AmeliaOutboundMessage();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("sourceClass".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setSourceClass(jsonReader.nextString());
            } else if ("messageText".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setMessageText(jsonReader.nextString());
            } else if ("attributes".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setAttributes(AmeliaOutboundMessageAttributes.deserialize(jsonReader));
            } else if ("messageType".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setMessageType(jsonReader.nextString());
            } else if ("inResponseToMessageId".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setInResponseToMessageId(jsonReader.nextString());
            } else if ("retry".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setRetry(jsonReader.nextBoolean());
            } else if ("sourceSessionId".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setSourceSessionId(jsonReader.nextString());
            } else if ("conversationId".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setConversationId(jsonReader.nextString());
            } else if ("fromUserDisplayName".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setFromUserDisplayName(jsonReader.nextString());
            } else if ("id".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setId(jsonReader.nextString());
            }else if ("voice".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessage.setVoice(jsonReader.nextString());
            }  else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return ameliaOutboundMessage;
    }
}