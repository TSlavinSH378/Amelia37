package net.ipsoft.amelia.sdk;

import android.net.Uri;

import net.ipsoft.amelia.sdk.internal.common.AmeliaConfig;

import java.util.List;

public interface IAmeliaChat {

    /**
     * Add an {@link ISessionListener}
     *
     * @param sessionListener listener to be added
     */
    void addSessionListener(ISessionListener sessionListener);

    /**
     * Remove an {@link ISessionListener}
     *
     * @param sessionListener listener to be removed
     */
    void removeSessionListener(ISessionListener sessionListener);

    /**
     * Add an {@link IConversationListener}
     *
     * @param conversationListener listener to be added
     */
    void addConversationListener(IConversationListener conversationListener);

    /**
     * Remove an {@link IConversationListener}
     *
     * @param conversationListener listener to be removed
     */
    void removeConversationListener(IConversationListener conversationListener);

    /**
     * In case you are logged in anonymously, clients may trigger a login using this method.
     * Auth systems will be fetched and be returned to {@link ISessionListener#onLoginRequired(List)}
     */
    void stepupLogin();

    /**
     * Login in an user with credentials, SDK will respond with either
     * {@link ISessionListener#onLoginFail(AmeliaError)} or {@link ISessionListener#onLoginSuccess()}
     *
     * @param options login credentials
     */
    void login(LoginOptions options);

    /**
     * Logout currently logged in user
     */
    void logout();

    /**
     * Start a new conversation. If a domain code hasn't been provided using
     * {@link AmeliaChatBuilder#setDomainCode(String)} this call will result in a callback to
     * {@link ISessionListener#onDomainSelectionRequired(List)} or
     * {@link ISessionListener#onLoginRequired(List)}
     *
     * @see AmeliaConfig
     */
    void startNewConversation();

    /**
     * Select a domain and resume attempt to start a new conversation
     *
     * @param domain one of the domains return by {@link ISessionListener#onDomainSelectionRequired(List)}
     */
    void selectDomain(Domain domain);

    /**
     * Ends the ongoing conversation
     */
    void endConversation();

    /**
     * @return sessionId of current conversation
     */
    String getSessionId();

    /**
     * Gets the conversationId of current conversation
     *
     * @return conversationId of ongoing conversation
     */
    String getConversationId();

    /**
     * Gets the domain code of the conversation, or <code>null</code> if no conversation is open
     *
     * @return domain code of the conversation
     */
    Domain getDomain();

    /**
     * Gets the language code of the chat or current conversation
     *
     * @return language code
     */
    String getLangaugeCode();

    /**
     * Current input state
     *
     * @return <code>true</code> if input is expected to be enabled, <code>false</code> otherwise
     */
    boolean isInputEnabled();

    /**
     * Currently logged in user, possibly an anonymous user, or null if there's no current login
     * session.
     *
     * @return current user
     */
    AmeliaUser getUser();

    /**
     * Alias for {@link #ask(String)}
     *
     * @param statement
     */
    void say(String statement);

    /**
     * Send a user text message to amelia and updates the chat's {@link #getTimeOfLastMessage()}
     *
     * @param question the text to send to Amelia
     */
    void ask(String question);

    /**
     * Submits a form
     * @param form form to submit
     * @param messageText a text message to be the user utterance when the form is submitted
     */
    void submitForm(FormInputData form, String messageText);

    /**
     * Submit an integration action to Amelia, which will run a named BPN with
     * the provided arguments, along with a custom message provided to the method.
     *
     * @param processName the name of the BPN process to run
     * @param processArgs the arguments to pass to that BPN process
     * @param messageText a custom message to send
     */
    void runAction(String processName, String processArgs, String messageText);

    /**
     * Clear chat history of the ongoing conversation. The SDK doesn't maintain a chat history,
     * but other listeners will be notified via {@link IConversationListener#onChatHistoryClear()}
     */
    void clearChatHistory();

    /**
     * @return Amelia's current mood
     */
    String getCurrentMood();

    /**
     * Gets the time of the last message sent to/from the chat in millis since 1 Jan 1970
     *
     * @return time of last message sent to/from the chat
     */
    long getTimeOfLastMessage();

    /**
     * Clients are expected to call this in response to
     * {@link IConversationListener#onUploadRequest(AmeliaOutboundMessage)}. If upload is successful
     * {@link IConversationListener#onUploadSuccess(String, String, String)} is called otherwise
     * {@link IConversationListener#onUploadFailed(String, String, String)} is called.
     *
     * @param uri file uri
     */
    void uploadFile(Uri uri);

    /**
     * Mute upcoming messages, already received messages will not be affected
     */
    void mute();

    /**
     * Resume scheduling new message for playback
     */
    void unmute();

    /**
     * stop playback of speech, while it is playing
     */
    void stopPlayAudio();

    enum InputStateChangeReason {
        unknown,

        /**
         * input state affected because a file upload is being processed
         */
        upload,

        /**
         * input state affected because a form is being processed
         */
        form,

        /**
         * input state affected because client has gone idle
         */
        idle,

        /**
         * input state affected because of a connectivity issue
         */
        disconnected
    }
}
