package net.ipsoft.amelia.sdk.internal.restapi;

import net.ipsoft.amelia.sdk.BuildConfig;

import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedHashMap;

import okhttp3.Request;

public abstract class HttpRequest {
        
    protected LinkedHashMap<String, String> form;
    protected JSONObject jsonObject;
    protected File file;
    protected String contentType;
    public final String xCsrfToken;

    public HttpRequest() {
        this.xCsrfToken = null;
    }

    public HttpRequest(String xCsrfToken) {
        this.xCsrfToken = xCsrfToken;
    }

    public void prepare() throws IOException {}

    public abstract String getUrl(String baseUrl);

    public void writeHeaders(Request.Builder builder) {
        if (xCsrfToken != null) {
            builder.header("X-CSRF-TOKEN", xCsrfToken);
        }
        builder.header("X-Amelia-SDK", BuildConfig.X_AMELIA_SDK_VERSION);
        builder.header("X-Amelia-Protocol", BuildConfig.X_AMELIA_PROTOCOL_VERSION);
    }

    public String getContentType() {
        return contentType;
    }

    public LinkedHashMap<String, String> getForm() {
        return form;
    }

    public File getFile() {
        return file;
    }

    public String accept() {
        return HttpRequestProcessor.MIME_TYPE_JSON;
    }

    public JSONObject getJSONObject(){
        return jsonObject;
    }

    @Override
    public String toString() {
        return "{ " + "xCsrfToken: " + xCsrfToken + " }";
    }
}
