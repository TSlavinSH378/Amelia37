package net.ipsoft.amelia.sdk.internal.restapi;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.Request;

import java.util.LinkedHashMap;

public class LoginReq extends HttpRequest {

    public String username = null;
    public String password = null;

    public LoginReq(String xCsrfToken, String username, String password) {
        super(xCsrfToken);
        this.username = username;
        this.password = password;
        this.contentType = "application/json;charset=utf-8";
    }

    @Override
    public String toString() {
        return "{ " + "xCsrfToken: " + xCsrfToken + ", " + "username: " + username + ", " + "password: " + password + " }";
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/api/login";
    }

    @Override public JSONObject getJSONObject() {
        if (jsonObject == null) {
            jsonObject = new JSONObject();
            try {
                jsonObject.put("username", String.valueOf(username));
                jsonObject.put("password", String.valueOf(password));
            } catch (JSONException ignore) {
            }
        }
        return jsonObject;
    }
}