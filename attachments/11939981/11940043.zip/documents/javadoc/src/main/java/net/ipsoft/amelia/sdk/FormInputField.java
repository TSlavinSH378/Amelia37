package net.ipsoft.amelia.sdk;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

public class FormInputField {
    protected String name = null;
    protected String fieldType = null;
    protected ArrayList<FormInputFieldOptions> options = new ArrayList<FormInputFieldOptions>();

    /**
     * The name of this form field
     *
     * @return field name
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * The type of this form field; note that this is an arbitrary string set in the BPN;
     * the client code is responsible for handling all possible types
     *
     * @return field type
     */
    public String getFieldType() {
        return fieldType;
    }

    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    /**
     * The options available, e.g. for widgets that demand it, such as banks of checkboxes or radio buttons
     *
     * @return field options
     */
    public ArrayList<FormInputFieldOptions> getOptions() {
        return options;
    }

    public void setOptions(ArrayList<FormInputFieldOptions> options) {
        this.options = options;
    }

    @Override
    public String toString() {
        return "{ " + "name: " + name + ", " + "fieldType: " + fieldType + ", " + "options: " + (options == null ? null : options.hashCode()) + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (name != null) {
            jsonWriter.name("name");
            jsonWriter.value(name);
        }
        if (fieldType != null) {
            jsonWriter.name("fieldType");
            jsonWriter.value(fieldType);
        }
        if (options != null) {
            jsonWriter.name("options");
            jsonWriter.beginArray();
            for (int i = 0; i < options.size(); i++) {
                options.get(i).serialize(jsonWriter);
            }
            jsonWriter.endArray();
        }
        jsonWriter.endObject();
    }

    public static FormInputField deserialize(JSONObject jsonObject) throws JSONException {
        FormInputField formInputField = new FormInputField();
        formInputField.setName(jsonObject.optString("name"));
        formInputField.setFieldType(jsonObject.optString("fieldType"));
        if (jsonObject.has("options") && !jsonObject.isNull("options")) {
            ArrayList options = new ArrayList<FormInputFieldOptions>();
            JSONArray jsonArray = jsonObject.getJSONArray("options");
            for (int i = 0; i < jsonArray.length(); i++) {
                options.add(FormInputFieldOptions.deserialize(jsonArray.getJSONObject(i)));
            }
            formInputField.setOptions(options);
        }
        return formInputField;
    }

    public static FormInputField deserialize(JsonReader jsonReader) throws IOException {
        FormInputField formInputField = new FormInputField();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("name".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputField.setName(jsonReader.nextString());
            } else if ("fieldType".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputField.setFieldType(jsonReader.nextString());
            } else if ("options".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ArrayList<FormInputFieldOptions> outArray = new ArrayList<>();
                jsonReader.beginArray();
                while (jsonReader.hasNext()) {
                    if (jsonReader.peek() != JsonToken.NULL) {
                        FormInputFieldOptions item = FormInputFieldOptions.deserialize(jsonReader);
                        outArray.add(item);
                    } else {
                        jsonReader.skipValue();
                    }
                }
                jsonReader.endArray();
                formInputField.setOptions(outArray);
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return formInputField;
    }
}