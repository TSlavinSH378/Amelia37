package net.ipsoft.amelia.sdk;

import java.util.List;

/**
 * Convenience class for clients that wish to implement a subset of methods exposed by
 * {@link ISessionListener}.
 */
public class BaseSessionListener implements ISessionListener {

    @Override
    public void onUserInit(String name, String email) {

    }

    @Override
    public void onSessionStart() {

    }

    @Override
    public void onSessionFail(AmeliaError error) {

    }

    @Override
    public void onLoginRequired(List<AuthSystem> authSystems) {

    }

    @Override
    public void onLoginFail(AmeliaError error) {

    }

    @Override
    public void onLoginSuccess() {

    }

    @Override
    public void onDomainSelectionRequired(List<Domain> domains) {

    }

    @Override
    public void onDomainFail(AmeliaError error) {

    }

    @Override
    public void onConversationStart() {

    }

    @Override
    public void onConversationEnd() {

    }

    @Override
    public void onConversationFail(AmeliaError error) {

    }

    @Override
    public void onLanguageChange(String newLang, String oldLang) {

    }

    @Override
    public void onLogout() {

    }
}
