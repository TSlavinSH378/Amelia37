package net.ipsoft.amelia.sdk.internal.chat;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class SelectionUtteranceMetadata {
    protected String prefixSingle = null;
    protected String prefixMultiple = null;
    protected String conjunction = null;

    public String getPrefixSingle() {
        return prefixSingle;
    }

    public void setPrefixSingle(String prefixSingle) {
        this.prefixSingle = prefixSingle;
    }

    public String getPrefixMultiple() {
        return prefixMultiple;
    }

    public void setPrefixMultiple(String prefixMultiple) {
        this.prefixMultiple = prefixMultiple;
    }

    public String getConjunction() {
        return conjunction;
    }

    public void setConjunction(String conjunction) {
        this.conjunction = conjunction;
    }

    @Override
    public String toString() {
        return "{ " + "prefixSingle: " + prefixSingle + ", " + "prefixMultiple: " + prefixMultiple + ", " + "conjunction: " + conjunction + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (prefixSingle != null) {
            jsonWriter.name("prefixSingle");
            jsonWriter.value(prefixSingle);
        }
        if (prefixMultiple != null) {
            jsonWriter.name("prefixMultiple");
            jsonWriter.value(prefixMultiple);
        }
        if (conjunction != null) {
            jsonWriter.name("conjunction");
            jsonWriter.value(conjunction);
        }
        jsonWriter.endObject();
    }

    public static SelectionUtteranceMetadata deserialize(JSONObject jsonObject) throws JSONException {
        SelectionUtteranceMetadata selectionUtteranceMetadata = new SelectionUtteranceMetadata();

        if (jsonObject.has("prefixSingle") && !jsonObject.isNull("prefixSingle")) {
            selectionUtteranceMetadata.setPrefixSingle(jsonObject.getString("prefixSingle"));
        }
        if (jsonObject.has("prefixMultiple") && !jsonObject.isNull("prefixMultiple")) {
            selectionUtteranceMetadata.setPrefixMultiple(jsonObject.getString("prefixMultiple"));
        }
        if (jsonObject.has("conjunction") && !jsonObject.isNull("conjunction")) {
            selectionUtteranceMetadata.setConjunction(jsonObject.getString("conjunction"));
        }
        return selectionUtteranceMetadata;
    }

    public static SelectionUtteranceMetadata deserialize(JsonReader jsonReader) throws IOException {
        SelectionUtteranceMetadata selectionUtteranceMetadata = new SelectionUtteranceMetadata();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("prefixSingle".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                selectionUtteranceMetadata.setPrefixSingle(jsonReader.nextString());
            } else if ("prefixMultiple".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                selectionUtteranceMetadata.setPrefixMultiple(jsonReader.nextString());
            } else if ("conjunction".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                selectionUtteranceMetadata.setConjunction(jsonReader.nextString());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return selectionUtteranceMetadata;
    }
}