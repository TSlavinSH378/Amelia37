package net.ipsoft.amelia.sdk;

import android.os.Parcel;
import android.os.Parcelable;

import net.ipsoft.amelia.sdk.internal.restapi.HttpError;

import java.net.HttpURLConnection;

/**
 * All failures reported from the Amelia SDK contains an instance of AmeliaError
 */
public class AmeliaError implements Parcelable {

    /*
     * Specific code to the failure that occurred
     */
    public final Code code;

    /*
     * Descriptive message, mainly for development purposes, i.e. not intended to be display in a UI
     */
    public final String message;

    /*
     * If the failure occurred as a result of a caught exception, this is it
     */
    public final Throwable cause;


    public AmeliaError(String message) {
        this(Code.error, message);
    }

    public AmeliaError(Code code, String message) {
        this.code = code;
        this.message = message;
        this.cause = null;
    }

    public AmeliaError(String message, Throwable cause) {
        this(Code.error, message, cause);
    }

    public AmeliaError(Code code, String message, Throwable cause) {
        this.code = code;
        this.message = message;
        this.cause = cause;
    }

    public AmeliaError(HttpError error, String message) {

        if (message != null) {
            this.message = message;
            switch (error.code) {
                case networkError:
                    this.code = Code.networkError;
                    break;
                case backendError:
                    switch (error.httpCode) {
                        case HttpURLConnection.HTTP_MOVED_TEMP:
                            this.code = Code.invalidSession;
                            break;
                        case HttpURLConnection.HTTP_GONE:
                            this.code = Code.unsupportedSdkVersion;
                            break;
                        default:
                            this.code = Code.unexpectedResponse;
                            break;
                    }
                    break;
                default:
                    this.code = Code.error;
            }
        } else {
            switch (error.code) {
                case badRequestError:
                    this.code = Code.invalidContent;
                    this.message = error.message;
                    break;
                case networkError:
                    this.code = Code.networkError;
                    this.message = "Network error";
                    break;
                case backendError:
                    this.code = Code.unexpectedResponse;
                    this.message = "Internal server error";
                    break;
                default:
                    this.code = Code.error;
                    this.message = error.message;
            }
        }
        this.cause = error.cause;
    }


    @Override
    public String toString() {
        return "{ " + "code: " + code + ", " + "message: " + message + " }";
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(code.ordinal());
        out.writeString(message);
    }

    public static final Parcelable.Creator<AmeliaError> CREATOR = new Parcelable.Creator<AmeliaError>() {
        public AmeliaError createFromParcel(Parcel in) {
            Integer codeAsInt = in.readInt();
            Code code = Code.values()[codeAsInt];
            String message = in.readString();
            return new AmeliaError(code, message);
        }
        public AmeliaError[] newArray(int size) {
            return new AmeliaError[size];
        }
    };

    public enum Code {
        /**
         * Default error code
         */
        error,

        /**
         * Missing content or content could not be read
         */
        invalidContent,

        /**
         * An http request failed because of a network error
         */
        networkError,

        /**
         * An http request was successful, but the response wasn't read properly
         */
        unexpectedResponse,

        /**
         * An attempt to create an anonymous user when anonymous login is not available
         */
        illegalAnonymousLogin,

        /**
         * Session has expired or is invalid
         */
        invalidSession,

        /**
         * Server reported that the SDK needs to be updated
         */
        unsupportedSdkVersion,

        /**
         * Unable to extract session cookie from app's web view cookie store
         */
        missingSessionCookie,
        /**
         * Attempt to log in user, but failed
         */
        authenticationFailure
    }
}