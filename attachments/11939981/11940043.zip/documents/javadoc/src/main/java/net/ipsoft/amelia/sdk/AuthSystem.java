package net.ipsoft.amelia.sdk;

import java.io.IOException;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.JsonReader;
import android.util.JsonToken;

/**
 * Authentication system describes a support authentication method for non-anonymous logins.
 */
public class AuthSystem implements Parcelable {

    protected boolean redirect = false;
    protected String code = null;
    protected String name = null;
    protected String description = null;
    protected String cls = null;
    protected String loginPath = null;

    public static AuthSystem getDefaultAuthSystem(){
        AuthSystem authSystem = new AuthSystem();
        authSystem.setCls("Amelia.view.login.EmailPasswordLoginForm");
        authSystem.setCode("internal");
        authSystem.setLoginPath("/login");
        authSystem.setName("Internal");
        authSystem.setDescription("Amelia Default Authentication");
        authSystem.setRedirect(false);
        return authSystem;
    }

    /**
     *
     * @return true if {@link #getLoginPath()} will redirect
     */
    public boolean getRedirect() {
        return redirect;
    }

    public void setRedirect(boolean redirect) {
        this.redirect = redirect;
    }

    /**
     * The internal auth system has code "internal"
     *
     * @return unique code of this auth system
     */
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Name of auth system
     *
     * @return auth system's name
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * Description of auth system
     *
     * @return auth system description
     */
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCls() {
        return cls;
    }

    public void setCls(String cls) {
        this.cls = cls;
    }

    /**
     * Login path to be appended to the Amalia base url + "/Amelia"
     * Login path is constructed via:
     * <p>
     *     <code>ameliaBaseUrl + "/Amelia" + getLoginPath()</code>
     * </p>
     *
     * @return the login path
     */
    public String getLoginPath() {
        return loginPath;
    }

    public void setLoginPath(String loginPath) {
        this.loginPath = loginPath;
    }

    @Override
    public String toString() {
        return "{ " + "redirect: " + redirect + ", " + "code: " + code + ", " + "name: " + name + ", " + "description: " + description + ", " + "cls: " + cls + ", " + "loginPath: " + loginPath + " }";
    }

    public static AuthSystem deserialize(JsonReader jsonReader) throws IOException {
        AuthSystem authSystem = new AuthSystem();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("redirect".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                authSystem.setRedirect(jsonReader.nextBoolean());
            } else if ("code".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                authSystem.setCode(jsonReader.nextString());
            } else if ("name".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                authSystem.setName(jsonReader.nextString());
            } else if ("description".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                authSystem.setDescription(jsonReader.nextString());
            } else if ("cls".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                authSystem.setCls(jsonReader.nextString());
            } else if ("loginPath".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                authSystem.setLoginPath(jsonReader.nextString());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return authSystem;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(redirect ? 1 : 0);
        out.writeString(code);
        out.writeString(name);
        out.writeString(description);
        out.writeString(cls);
        out.writeString(loginPath);
    }

    public static final Parcelable.Creator<AuthSystem> CREATOR = new Parcelable.Creator<AuthSystem>() {
        @Override
        public AuthSystem createFromParcel(Parcel in) {
            AuthSystem obj = new AuthSystem();
            obj.redirect = in.readInt() == 0 ? false : true;
            obj.code = in.readString();
            obj.name = in.readString();
            obj.description = in.readString();
            obj.cls = in.readString();
            obj.loginPath = in.readString();
            return obj;
        }

        public AuthSystem[] newArray(int size) {
            return new AuthSystem[size];
        }
    };
}