package net.ipsoft.amelia.sdk.internal.stomp;

import net.ipsoft.amelia.sdk.internal.common.ALog;

import java.nio.charset.Charset;
import java.util.Arrays;

public class StompParser {

    public String serialize(StompFrame frame) throws StompException {
        StringBuilder builder = new StringBuilder();
        builder.append(frame.command).append('\n');

        for (StompHeader header : frame.headers) {
            builder.append(header.serialize()).append('\n');
        }

        builder.append('\n');

        if (frame.body != null) {
            builder.append(frame.body);
        }
        builder.append('\0');
        String serializedFrame = builder.toString();
        ALog.d("amelia", "out:\n" + serializedFrame);
        return serializedFrame;
//
//        NSMutableData * frameData = [NSMutableData dataWithData:[str dataUsingEncoding:NSUTF8StringEncoding]];
//
//        if (frame.body != nil) {
//            //
//            // Send according to mime type and encoding, (or defaults)
//            //
//
//            NSData * bodyData = nil;
//
//            if ([frame.body isKindOfClass:[NSData class]]) {
//                bodyData = frame.body;
//            } else if (frame.mimeType == nil || [frame.mimeType hasPrefix:@"text/"]) {
//                //
//                // Assumes that frame.body is a string
//                //
//                bodyData = [frame.body dataUsingEncoding:NSUTF8StringEncoding];
//            } else if ([frame.mimeType isEqualToString:@"application/json"]) {
//                //
//                // Assumes that frame.body can be JSON encoded
//                //
//
//                bodyData = [NSJSONSerialization dataWithJSONObject:frame.body options:NSJSONWritingPrettyPrinted error:error];
//                if (bodyData == nil) {
//                    return NO;
//                }
//            }
//
//            if (bodyData == nil)
//            {
//                if (error != nil) {
//                *error = [NSError errorWithDomain:StompErrorDomain code:0 userInfo:@{
//                        @"localizeableDescription" : @"Don't know how to handle specified mime type."
//                    }];
//                }
//
//                return NO;
//            }
//
//        [frameData appendData:bodyData];
    }

    public StompMessage deserialize(String string) throws StompException {
        if ("\n".equals(string)) {
            return new StompHeartBeat();
        } else {
            return deserializeFrame(string);
        }
    }

    public StompFrame deserializeFrame(String string) throws StompException {
        StompFrame.Builder builder = new StompFrame.Builder();
        String[] lines = string.split("\n");
        if (lines.length < 3) {
            throw new StompException("Invalid stomp frame, too few lines (" + lines.length + " lines).");
        }
        int lineIndex = 0;
        try {
            String command = lines[lineIndex++];
            if (!isCommandValid(command)) {
                throw new StompException("Invalid stomp command: " + command);
            }
            builder.command(command);
            String nextLine = lines[lineIndex++];

            int contentLength = -1;

            while (!nextLine.isEmpty()) {
                StompHeader stompHeader = StompHeader.deserialize(nextLine);
                if (stompHeader.isContentLength()) {
                    contentLength = Integer.valueOf(stompHeader.value);
                }
                builder.addHeader(stompHeader);
                nextLine = lines[lineIndex++];
            }

            if (contentLength >= 0) {
                StringBuilder remainingMessage = new StringBuilder();
                while (lineIndex < lines.length) {
                    nextLine = lines[lineIndex++];
                    remainingMessage.append(nextLine);
                }
                String remainingMessageString = remainingMessage.toString();
                Charset utf8 = java.nio.charset.StandardCharsets.UTF_8;
                byte[] remainingMessageBytes = remainingMessageString.getBytes(utf8);
                byte[] bobyBytes = Arrays.copyOf(remainingMessageBytes, contentLength);
                String body = new String(bobyBytes, utf8);

                builder.body(body);

            } else {

                StringBuilder body = new StringBuilder();
                do {
                    nextLine = lines[lineIndex++];
                    body.append(nextLine);
                } while (!(isEndOfFrame(nextLine)));

                builder.body(body.toString());
            }

        } catch (Exception e) {
            throw new StompException("Unable to parse frame.", e);
        }

        return builder.build();
    }

    private boolean isEndOfFrame(String line) {
        return line.charAt(line.length() - 1) == '\0';
    }

    private boolean isCommandValid(String command) {
        switch (command) {
            case "MESSAGE":
            case "CONNECT":
            case "CONNECTED":
            case "SUBSCRIBE":
            case "UNSUBSCRIBE":
            case "ERROR":
            case "ACK":
            case "NACK":
            case "BEGIN":
            case "COMMIT":
            case "ABORT":
            case "DISCONNECT":
                return true;
            default:
                return false;
        }
    }
}
