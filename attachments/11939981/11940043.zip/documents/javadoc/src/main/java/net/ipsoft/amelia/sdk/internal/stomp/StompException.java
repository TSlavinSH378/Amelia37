package net.ipsoft.amelia.sdk.internal.stomp;

public class StompException extends Exception {

    public StompException(String message) {
        super(message);
    }

    public StompException(String message, Throwable cause) {
        super(message, cause);
    }

}
