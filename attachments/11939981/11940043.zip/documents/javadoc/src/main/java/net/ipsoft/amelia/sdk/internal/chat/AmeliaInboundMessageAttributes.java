package net.ipsoft.amelia.sdk.internal.chat;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import java.io.IOException;

public class AmeliaInboundMessageAttributes {
    protected String formInputData = null;
    protected RedirectionProcessInfo redirectionProcessInfo = null;

    public String getFormInputData() {
        return formInputData;
    }

    public void setFormInputData(String formInputData) {
        this.formInputData = formInputData;
    }

    public RedirectionProcessInfo getRedirectionProcessInfo() {
        return redirectionProcessInfo;
    }

    public void setRedirectionProcessInfo(RedirectionProcessInfo redirectionProcessInfo) {
        this.redirectionProcessInfo = redirectionProcessInfo;
    }

    @Override
    public String toString() {
        return "{ " + "formInputData: " + formInputData + ", " + "redirectionProcessInfo: " + (redirectionProcessInfo == null ? null : redirectionProcessInfo.hashCode())+" }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (formInputData != null) {
            jsonWriter.name("formInputData");
            jsonWriter.value(formInputData);
        }
        if (redirectionProcessInfo != null) {
            jsonWriter.name("redirectionProcessInfo");
            redirectionProcessInfo.serialize(jsonWriter);
        }
        jsonWriter.endObject();
    }

    public static AmeliaInboundMessageAttributes deserialize(JsonReader jsonReader) throws IOException {
        AmeliaInboundMessageAttributes ameliaInboundMessageAttributes = new AmeliaInboundMessageAttributes();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("formInputData".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaInboundMessageAttributes.setFormInputData(jsonReader.nextString());
            } else if ("redirectionProcessInfo".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaInboundMessageAttributes.setRedirectionProcessInfo(RedirectionProcessInfo.deserialize(jsonReader));
            }
            else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return ameliaInboundMessageAttributes;
    }
}