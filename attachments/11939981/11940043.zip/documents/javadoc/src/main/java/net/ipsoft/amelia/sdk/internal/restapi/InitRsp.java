package net.ipsoft.amelia.sdk.internal.restapi;

import android.content.Context;
import android.util.JsonReader;

import java.io.IOException;
import java.io.Reader;

public class InitRsp extends HttpResponse {

    public InitRspData data = null;

    @Override
    public String toString() {
        return "{ " + "data: " + (data == null ? null : data.hashCode()) + ", " + "error: " + (error == null ? null : error.hashCode()) + " }";
    }

    public void deserialize(Reader reader) throws IOException {
        JsonReader jsonReader = new JsonReader(reader);
        data = InitRspData.deserialize(jsonReader);
    }
}