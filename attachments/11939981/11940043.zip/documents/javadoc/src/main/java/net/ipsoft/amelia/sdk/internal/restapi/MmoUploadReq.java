package net.ipsoft.amelia.sdk.internal.restapi;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.webkit.MimeTypeMap;

import net.ipsoft.amelia.sdk.internal.common.Conversation;
import net.ipsoft.amelia.sdk.internal.common.FileUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class MmoUploadReq extends HttpRequest {

    private final Context context;
    private final Uri uri;
    private final Conversation conversation;
    private final String fileType;
    private final String fileExtension;

    public MmoUploadReq(Context context, Uri uri, String fileType, Conversation conversation) {
        this.file = null;
        this.context = context;
        this.uri = uri;
        this.fileType = fileType;
        ContentResolver contentResolver = context.getContentResolver();
        this.contentType = contentResolver.getType(uri);
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        String fileExtension = mimeTypeMap.getExtensionFromMimeType(this.contentType);
        this.fileExtension = fileExtension == null ? null : "." + fileExtension;
        this.conversation = conversation;
    }

    @Override
    public void prepare() throws IOException {
        ContentResolver contentResolver = context.getContentResolver();
        InputStream inputStream = contentResolver.openInputStream(uri);
        File cacheDir = context.getCacheDir();
        file = File.createTempFile("amelia_upload_", fileExtension, cacheDir);
        FileUtils.copyInputStreamToFile(inputStream, file);
    }

    @Override
    public String getUrl(String baseUrl) {
        return baseUrl + "/Amelia/bpn/uploadDraggedFile" + "?" +
                "_csrf=" + conversation.xCsrfToken + "&" +
                "conversationId=" + conversation.conversationId + "&" +
                "fileType=" + fileType + "&" +
                "name=" + file.getName();
    }

    @Override
    public String accept() {
        return HttpRequestProcessor.MIME_TYPE_PLAIN;
    }
}
