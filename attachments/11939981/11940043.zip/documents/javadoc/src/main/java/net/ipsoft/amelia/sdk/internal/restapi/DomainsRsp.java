package net.ipsoft.amelia.sdk.internal.restapi;

import android.content.Context;
import android.util.JsonReader;

import net.ipsoft.amelia.sdk.Domain;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

public class DomainsRsp extends HttpResponse {

    public ArrayList<Domain> domains = new ArrayList<>();

    @Override
    public String toString() {
        return "{ " + "domains: " + (domains == null ? null : domains.hashCode()) + ", " + "error: " + (error == null ? null : error.hashCode()) + " }";
    }

    public void deserialize(Reader reader) throws IOException {
        JsonReader jsonReader = new JsonReader(reader);
        try {
            jsonReader.beginArray();
            while (jsonReader.hasNext()) {
                domains.add(Domain.deserialize(jsonReader));
            }
            jsonReader.endArray();
        }catch(Exception ex){
            Domain domain = new Domain();
            domain.setName("global");
            domain.setCode("global");
            domain.setDomainId("1");
            domain.setLocaleDisplayName("global");
            domains.add(domain);
        }
    }
}