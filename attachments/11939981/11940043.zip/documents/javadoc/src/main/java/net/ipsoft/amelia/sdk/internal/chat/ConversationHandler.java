package net.ipsoft.amelia.sdk.internal.chat;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.JsonReader;
import android.util.JsonWriter;

import net.ipsoft.amelia.sdk.AmeliaError;
import net.ipsoft.amelia.sdk.AmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.FormInputData;
import net.ipsoft.amelia.sdk.internal.common.ALog;
import net.ipsoft.amelia.sdk.internal.common.AmeliaConfig;
import net.ipsoft.amelia.sdk.internal.common.Conversation;
import net.ipsoft.amelia.sdk.internal.restapi.CheckReq;
import net.ipsoft.amelia.sdk.internal.restapi.CheckRsp;
import net.ipsoft.amelia.sdk.internal.restapi.HttpRequestProcessor;
import net.ipsoft.amelia.sdk.internal.stomp.StompException;
import net.ipsoft.amelia.sdk.internal.stomp.StompFrame;
import net.ipsoft.amelia.sdk.internal.stomp.StompHeader;
import net.ipsoft.amelia.sdk.internal.stomp.StompHeartBeat;
import net.ipsoft.amelia.sdk.internal.stomp.StompMessage;
import net.ipsoft.amelia.sdk.internal.stomp.StompParser;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class ConversationHandler implements IAmeliaStompApi {

    private static final int CODE_NORMAL_CLOSURE = 1000;

    private WebSocket webSocket;
    private StompParser stompParser = new StompParser();
    private Conversation conversation;
    private String xCsrfToken;
    private Callback chatListener;
    private Handler handler;
    private HttpRequestProcessor httpRequestProcessor;
    private AmeliaConfig config;
    private State currentState = State.idle;
    private HttpRequestProcessor.FullRequest checkRequest;

    private Runnable delayedRestartAttempt = new Runnable() {
        @Override
        public void run() {
            rejoinConversation();
        }
    };

    public ConversationHandler(HttpRequestProcessor httpRequestProcessor, AmeliaConfig config) {
        handler = new Handler(Looper.getMainLooper());
        this.httpRequestProcessor = httpRequestProcessor;
        this.config = config;
    }

    @Override
    public void setChatListener(Callback chatListener) {
        this.chatListener = chatListener;
    }

    @Override
    public void startConversation(Conversation conversation) {
        this.xCsrfToken = conversation.xCsrfToken;
        this.conversation = conversation;
        joinConversation(false);
    }

    private void rejoinConversation() {
        currentState = State.checkingHttpSession;

        checkRequest = httpRequestProcessor.send(new CheckReq(xCsrfToken), new CheckRsp() {
            @Override
            public void run() {
                if (cancelled) {
                    // disconnected by client, ignore
                } else if (error != null) {
                    AmeliaError ameliaError = new AmeliaError(error, "Reconnect failed");
                    if (ameliaError.code == AmeliaError.Code.invalidSession) {
                        currentState = State.idle;
                        chatListener.sessionFail(ameliaError);
                    } else {
                        currentState = State.pendingReconnect;
                        handler.postDelayed(delayedRestartAttempt, config.reconnectDelayMs);
                    }
                } else {
                    ALog.d("amelia", "continue rejoin");
                    joinConversation(true);
                }
            }
        });
    }

    private void joinConversation(final boolean isRestart) {

        Uri uri = Uri.parse(config.baseUrl);
        String scheme = uri.getScheme();
        Uri.Builder builder;
        if ("https".equals(scheme)) {
            builder = uri.buildUpon().scheme("wss");
        } else {
            builder = uri.buildUpon().scheme("ws");
        }
        String baseUrl = builder.build().toString();

        Request request = new Request.Builder()
                .url(baseUrl + "/Amelia/api/sock/websocket")
                .build();

        WebSocketListener listener = new WebSocketListener() {

            public void onOpen(WebSocket webSocket, Response response) {
                ALog.d("amelia", "onOpen");
                connect();
                if (isRestart) {
                    sendOnReconnect();
                } else {
                    sendOnConnect();
                }
            }

            /** Invoked when a text (type {@code 0x1}) message has been received. */
            public void onMessage(WebSocket webSocket, String text) {
                ALog.d("amelia", "onMessage:\n" + text);
                try {
                    StompMessage stompMessage = stompParser.deserialize(text);
                    if (stompMessage instanceof StompHeartBeat) {
                        ALog.d("amelia", "stomp heart beat");
                    } else {
                        StompFrame stompFrame = (StompFrame) stompMessage;
                        switch (stompFrame.command) {
                            case "MESSAGE":
                                handleMessage(text, stompFrame);
                                break;
                            case "CONNECTED":
                                subscribe();
                                if (!isRestart) {
                                    start();
                                }
                                break;
                        }
                    }
                } catch (StompException | IOException e) {
                    e.printStackTrace();
                }
            }

            /** Invoked when a binary (type {@code 0x2}) message has been received. */
            public void onMessage(WebSocket webSocket, ByteString bytes) {
                ALog.d("amelia", "onMessage: <binary>");
            }

            /** Invoked when the peer has indicated that no more incoming messages will be transmitted. */
            public void onClosing(WebSocket webSocket, int code, String reason) {
                ALog.d("amelia", "onClosing: " + reason);
                internalOnDisconnect(false);
            }

            /**
             * Invoked when both peers have indicated that no more messages will be transmitted and the
             * connection has been successfully released. No further calls to this callback will be made.
             */
            public void onClosed(WebSocket webSocket, int code, String reason) {
                ALog.d("amelia", "onClosed: " + reason);
                internalOnDisconnect(false);
            }

            /**
             * Invoked when a web socket has been closed due to an error reading from or writing to the
             * network. Both outgoing and incoming messages may have been lost. No further calls to this
             * callback will be made.
             */
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                ALog.d("amelia", "onFailure");
                t.printStackTrace();
                internalOnDisconnect(true);
            }
        };

        webSocket = httpRequestProcessor.getClient().newWebSocket(request, listener);

        currentState = State.wsCreated;
    }

    private void disconnect() {
        webSocket.close(CODE_NORMAL_CLOSURE, null);
        currentState = State.wsClosing;
    }

    private void handleMessage(String text, StompFrame stompFrame) throws IOException {
        StompHeader stompHeader = stompFrame.getHeader("X-Amelia-Message-Type");
        message(text, stompHeader.value, stompFrame);
    }

    private void sendOnConnect() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                chatListener.onConnect();
            }
        });
    }
    private void sendOnReconnect() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                chatListener.onReconnect();
            }
        });
    }

    private void internalOnDisconnect(final boolean failure) {
        handler.post(new Runnable() {
            @Override
            public void run() {

                if (failure) {
                    switch (currentState) {
                        case wsClosing:
                            sendEndConversationRsp();
                            break;

                        case wsCreated:
                            currentState = State.pendingReconnect;
                            handler.postDelayed(delayedRestartAttempt, config.reconnectDelayMs);
                            chatListener.onDisconnect();
                            break;
                    }
                } else {
                    sendEndConversationRsp();
                }
            }
        });
    }

    private void connect() {
        List<StompHeader> headers = new ArrayList<>(2);
        headers.add(StompHeader.withAcceptVersion("1.1"));
        headers.add(new StompHeader("X-CSRF-TOKEN", xCsrfToken));

        StompFrame frame = new StompFrame.Builder()
                .command("CONNECT")
                .headers(headers)
                .build();

        String payload;
        try {
            payload = stompParser.serialize(frame);
            webSocket.send(payload);
        } catch (StompException e) {
            e.printStackTrace();
        }
    }

    private void subscribe() {
        StompFrame frame = new StompFrame.Builder()
                .command("SUBSCRIBE")
                .addHeader(StompHeader.withId("sub-0"))
                .addHeader(StompHeader.withDestination("/topic/session." + conversation.sessionId))
                .addHeader(new StompHeader("X-CSRF-TOKEN", xCsrfToken))
                .build();

        String payload;
        try {
            payload = stompParser.serialize(frame);
            webSocket.send(payload);
        } catch (StompException e) {
            e.printStackTrace();
        }
    }

    private void start() {
        send("InboundStartConversationMessage");
    }

    private void message(final String text, final String messageType, final StompFrame stompFrame) throws IOException {
        StringReader reader = new StringReader(stompFrame.body);
        BufferedReader bufferedReader = new BufferedReader(reader);
        JsonReader jsonReader = new JsonReader(bufferedReader);
        final AmeliaOutboundMessage ameliaMessage = AmeliaOutboundMessage.deserialize(jsonReader);
        ALog.d("amelia", "Amelia says: " + ameliaMessage.getMessageText());

        // Don't want to stomp classes to public API, copy to generic header format
        for (StompHeader header : stompFrame.headers) {
            ameliaMessage.addHeader(header.name, header.value);
        }

        handler.post(new Runnable() {
            @Override
            public void run() {
                switch (messageType) {
                    case "OutboundConversationClosedMessage":
                    case "OutboundSessionClosedMessage":
                        disconnect();
                        break;
                }
                chatListener.onMessage(text, ameliaMessage);
            }
        });
    }

    @Override
    public void ask(String messageText,boolean secure) {
        if(secure){
            sendSecure(messageText, "InboundUserUtteranceMessage");
        }else{
            send(messageText, "InboundUserUtteranceMessage");
        }
    }

    @Override
    public void endConversationReq() {
        switch (currentState) {
            case wsCreated:
                currentState = State.wsClosing;
                send("InboundConversationClosedMessage");
                break;
            case idle:
            case wsClosing:
                // ignore
                break;
            case checkingHttpSession:
                checkRequest.cancel();
                sendEndConversationRsp();
                break;
            case pendingReconnect:
                handler.removeCallbacks(delayedRestartAttempt);
                sendEndConversationRsp();
                break;
        }
    }

    private void sendEndConversationRsp() {
        conversation = null;
        xCsrfToken = null;
        webSocket = null;
        currentState = State.idle;
        chatListener.endConversationRsp();
    }

    @Override
    public void send(String messageText, String messageType) {
        AmeliaInboundMessage message = new AmeliaInboundMessage();
        message.setMessageText(messageText);
        send(message, messageType);
    }

    @Override
    public void sendSecure(String messageText,String messageType){
        AmeliaInboundMessage message = new AmeliaInboundMessage();
        message.setMessageText(messageText);
        message.setSecure(true);
        send(message, messageType);
    }

    @Override
    public void submitForm(FormInputData form, String messageText) {
        AmeliaInboundMessage message = new AmeliaInboundMessage();
        message.setMessageText(messageText);
        AmeliaInboundMessageAttributes attributes = new AmeliaInboundMessageAttributes();
        try {
            attributes.setFormInputData(form.serialize());
            message.setAttributes(attributes);
            send(message, "InboundUserUtteranceMessage");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void runAction(String processName, String argumentsJson, String messageText) {
        AmeliaInboundMessage message = new AmeliaInboundMessage();
        message.setMessageText(messageText);
        AmeliaInboundMessageAttributes attributes = new AmeliaInboundMessageAttributes();
        RedirectionProcessInfo redirectionProcessInfo = new RedirectionProcessInfo();
        redirectionProcessInfo.setProcessName(processName);
        redirectionProcessInfo.setProcessArgs(argumentsJson);
        attributes.setRedirectionProcessInfo(redirectionProcessInfo);
        message.setAttributes(attributes);
        send(message, "InboundUserUtteranceMessage");
    }

    @Override
    public void send(String messageType) {
        send(new AmeliaInboundMessage(), messageType);
    }

    private void send(AmeliaInboundMessage ameliaInboundMessage, String messageType) {
        chatListener.onSend(messageType);
        String json;
        int contentLength;
        try {
            StringWriter stringWriter = new StringWriter();
            BufferedWriter bufferedWriter = new BufferedWriter(stringWriter);
            JsonWriter jsonWriter = new JsonWriter(bufferedWriter);
            ameliaInboundMessage.serialize(jsonWriter);
            jsonWriter.close();
            json = stringWriter.toString();

            Charset utf8 = java.nio.charset.StandardCharsets.UTF_8;
            contentLength = json.getBytes(utf8).length;
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        StompFrame frame = new StompFrame.Builder()
                .command("SEND")
                .addHeader(new StompHeader("X-Amelia-Session-Id", conversation.sessionId))
                .addHeader(new StompHeader("X-Amelia-Conversation-Id", conversation.conversationId))
                .addHeader(new StompHeader("X-Amelia-Message-Type", messageType))
                .addHeader(new StompHeader("X-Amelia-Timestamp", String.valueOf(System.currentTimeMillis())))
                .addHeader(StompHeader.withDestination("/amelia/session.in"))
                .addHeader(StompHeader.withContentLength(contentLength))
                .body(json)
                .build();

        String payload;
        try {
            payload = stompParser.serialize(frame);
            webSocket.send(payload);
        } catch (StompException e) {
            e.printStackTrace();
        }
    }
    private enum State {
        idle,
        wsCreated,
        pendingReconnect,
        checkingHttpSession,
        wsClosing
    }

}
