package net.ipsoft.amelia.sdk;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class FormInputFieldOptions {
    protected String name = null;
    protected String value = null;
    protected boolean selected = false;
    protected boolean disabled = false;
    protected boolean hidden = false;

    /**
     * The displayable name
     *
     * @return display name
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * The value of the submission when selected
     *
     * @return submission value
     */
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    /**
     * If it should be selected by default
     *
     * @return <code>true</code> if selected
     */
    public boolean getSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    /**
     * If it should be disabled by default
     *
     * @return <code>true</code> if disabled
     */
    public boolean getDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    /**
     * If it should be hidden by default
     *
     * @return <code>true</code> if hidden
     */
    public boolean getHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    @Override
    public String toString() {
        return "{ " + "name: " + name + ", " + "value: " + value + ", " + "selected: " + selected + ", " + "disabled: " + disabled + ", " + "hidden: " + hidden + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (name != null) {
            jsonWriter.name("name");
            jsonWriter.value(name);
        }
        if (value != null) {
            jsonWriter.name("value");
            jsonWriter.value(value);
        }
        jsonWriter.name("selected");
        jsonWriter.value(selected);
        jsonWriter.name("disabled");
        jsonWriter.value(disabled);
        jsonWriter.name("hidden");
        jsonWriter.value(hidden);
        jsonWriter.endObject();
    }

    public static FormInputFieldOptions deserialize(JSONObject jsonObject) throws JSONException {
        FormInputFieldOptions formInputFieldOptions = new FormInputFieldOptions();
        formInputFieldOptions.setName(jsonObject.optString("name"));
        formInputFieldOptions.setValue(jsonObject.optString("value"));
        formInputFieldOptions.setSelected(jsonObject.optBoolean("selected"));
        formInputFieldOptions.setDisabled(jsonObject.optBoolean("disabled"));
        formInputFieldOptions.setHidden(jsonObject.optBoolean("hidden"));
        return formInputFieldOptions;
    }

    public static FormInputFieldOptions deserialize(JsonReader jsonReader) throws IOException {
        FormInputFieldOptions formInputFieldOptions = new FormInputFieldOptions();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("name".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputFieldOptions.setName(jsonReader.nextString());
            } else if ("value".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputFieldOptions.setValue(jsonReader.nextString());
            } else if ("selected".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputFieldOptions.setSelected(jsonReader.nextBoolean());
            } else if ("disabled".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputFieldOptions.setDisabled(jsonReader.nextBoolean());
            } else if ("hidden".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                formInputFieldOptions.setHidden(jsonReader.nextBoolean());
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return formInputFieldOptions;
    }
}