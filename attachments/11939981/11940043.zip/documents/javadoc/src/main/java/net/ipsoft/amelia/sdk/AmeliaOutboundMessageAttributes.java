package net.ipsoft.amelia.sdk;

import android.util.JsonReader;
import android.util.JsonToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class AmeliaOutboundMessageAttributes {

    protected String mood = null;
    protected FormInputData formInputData = null;
    protected String integrationMessageData = null;
    protected String avatarVoice = null;
    protected List<String> speech;
    protected boolean secureUserInput;

    /**
     * Currently available moods are:
     * <ul>
     * <li>NEUTRAL</li>
     * <li>HAPPY</li>
     * <li>SAD</li>
     * <li>SURPRISED</li>
     * <li>ANGRY</li>
     * <li>DISGUSTED</li>
     * <li>FEAR</li>
     * <li>CONTEMPT</li>
     * </ul>
     *
     * @return the current mood
     */
    public String getMood() {
        return mood;
    }

    public void setMood(String mood) {
        this.mood = mood;
    }

    /**
     * indicates whether the next user input should be masked
     */
    public boolean shouldSecureInput(){
        return secureUserInput;
    }

    public void setSecureUserInput(boolean secureUserInput){
        this.secureUserInput = secureUserInput;
    }

    /**
     * This will contain the BPN-driven semantic definition of a form in JSON format
     *
     * @return JSON formatted form data
     */
    public FormInputData getFormInputData() {
        return formInputData;
    }

    /**
     * This will contain the BPN-drive semantic definition of a more freeform widget in JSON format
     *
     * @return JSON formatted integration data
     */
    public String getIntegrationMessageData() {
        return integrationMessageData;
    }

    /**
     * Used internally for speech playback
     *
     * @return avatar voice
     */
    public String getAvatarVoice() {
        return avatarVoice;
    }

    /**
     * Used internally for speech playback
     * @return texts to speak
     */
    public List<String> getSpeech() {
        return speech;
    }

    @Override
    public String toString() {
        return "{ " +
                "Emoticon: " + mood + ", " +
                "formInputData: " + formInputData + ", " +
                "integrationMessageData: " + integrationMessageData + ", " +
                "avatarVoice: " + avatarVoice + ", " +
                "speech: " + speech +
                " }";
    }

    public static AmeliaOutboundMessageAttributes deserialize(JsonReader jsonReader) throws IOException {
        AmeliaOutboundMessageAttributes ameliaOutboundMessageAttributes = new AmeliaOutboundMessageAttributes();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("Emoticon".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessageAttributes.mood = jsonReader.nextString();
            } else if ("formInputData".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessageAttributes.formInputData = FormInputData.deserialize(jsonReader);
            } else if ("integrationMessageData".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessageAttributes.integrationMessageData = jsonReader.nextString();
            } else if ("avatarVoice".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ameliaOutboundMessageAttributes.avatarVoice = jsonReader.nextString();
            } else if ("bml".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                String bml = jsonReader.nextString();
                ameliaOutboundMessageAttributes.speech = extractSpeechFromBml(bml);
            }
            else if("secureUserInput".equals(name) &&jsonReader.peek()!= JsonToken.NULL){
                String secureUserInput = jsonReader.nextString();
                ameliaOutboundMessageAttributes.secureUserInput = secureUserInput.equals("yes");
            }
            else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return ameliaOutboundMessageAttributes;
    }

    private static List<String> extractSpeechFromBml(String bmlString) throws IOException {
        if (bmlString != null) {
            List<String> textsToSpeak = new ArrayList<>();
            StringReader reader = new StringReader(bmlString);
            BufferedReader bufferedReader = new BufferedReader(reader);
            JsonReader jsonReader = new JsonReader(bufferedReader);
            try {
                jsonReader.beginArray();
                while (jsonReader.hasNext()) {
                    jsonReader.beginArray();
                    while (jsonReader.hasNext()) {
                        StringReader bmlReader = new StringReader(jsonReader.nextString());
                        BufferedReader bmlBufferedReader = new BufferedReader(bmlReader);
                        JsonReader bmlJsonReader = new JsonReader(bmlBufferedReader);
                        try {
                            bmlJsonReader.beginObject();
                            while (bmlJsonReader.hasNext()) {
                                String nextItem = bmlJsonReader.nextName();
                                if (nextItem.contains("Speech") && bmlJsonReader.peek() != JsonToken.NULL) {
                                    bmlJsonReader.beginObject();
                                    while (bmlJsonReader.hasNext()) {
                                        String nextField = bmlJsonReader.nextName();
                                        if ("text".equals(nextField) && bmlJsonReader.peek() != JsonToken.NULL) {
                                            String textToSpeak = bmlJsonReader.nextString();
                                            if (!textToSpeak.toLowerCase().contains("amelia-mmo") && !textToSpeak.contains("UPLOAD_REQUEST_MESSAGE_EVENT")) {
                                                textToSpeak = textToSpeak.replaceAll("_SyncWord\\d+_", "");
                                                textToSpeak = textToSpeak.replaceAll("<nospeak>.*?</nospeak>", "");
                                                textsToSpeak.add(textToSpeak);
                                            }
                                        } else {
                                            bmlJsonReader.skipValue();
                                        }
                                    }
                                    bmlJsonReader.endObject();
                                } else {
                                    bmlJsonReader.skipValue();
                                }
                            }
                            bmlJsonReader.endObject();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } finally {
                            try {
                                bmlJsonReader.close();
                            } catch (IOException e) {
                            }
                        }
                    }
                    jsonReader.endArray();
                }
                jsonReader.endArray();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    jsonReader.close();
                } catch (IOException e) {
                }
            }
            return textsToSpeak;
        }
        return null;
    }
}