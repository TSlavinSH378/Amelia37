package net.ipsoft.amelia.sdk.internal.stomp;

import java.util.ArrayList;
import java.util.List;

public class StompFrame extends StompMessage {

    public final String command;
    public final List<StompHeader> headers;
    public final String body;
    public final String mimeType;
    public final String mimeEncoding;

    public StompFrame(String command, List<StompHeader> headers, String body, String mimeType, String mimeEncoding) {
        this.command = command;
        this.headers = headers;
        this.body = body;
        this.mimeType = mimeType;
        this.mimeEncoding = mimeEncoding;
    }

    public StompHeader getHeader(String name) {
        for (StompHeader header : headers) {
            if (header.name.equals(name)) {
                return header;
            }
        }
        return null;
    }

    public static class Builder {
        private String command;
        private List<StompHeader> headers;
        private String body;
        private String mimeType;
        private String mimeEncoding;

        public Builder command(String command) {
            this.command = command;
            return this;
        }

        public Builder addHeader(StompHeader header) {
            if (this.headers == null) {
                headers = new ArrayList<>();
            }
            headers.add(header);
            return this;
        }

        public Builder headers(List<StompHeader> headers) {
            this.headers = headers;
            return this;
        }

        public Builder body(String body) {
            this.body = body;
            return this;
        }

        public Builder mimeType(String mimeType) {
            this.mimeType = mimeType;
            return this;
        }

        public Builder mimeEncoding(String mimeEncoding) {
            this.mimeEncoding = mimeEncoding;
            return this;
        }

        public StompFrame build() {
            return new StompFrame(
                    command,
                    headers,
                    body,
                    mimeType,
                    mimeEncoding
            );
        }
    }
}
