package net.ipsoft.amelia.sdk.internal.restapi;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;

import java.io.IOException;
import java.util.ArrayList;

@SuppressWarnings("all")
public class MmoMetadata {
    protected String type = null;
    protected ArrayList<FileMetadata> value = new ArrayList<FileMetadata>();
    protected ArrayList<String> urls = new ArrayList<String>();

    public String getType() {
        return type;
    }

    public ArrayList<FileMetadata> getValue() {
        return value;
    }

    public String getUrl() {
        return urls.get(0);
    }

    @Override
    public String toString() {
        return "{ " + "type: " + type + ", " + "value: " + (value == null ? null : value.hashCode()) + " }";
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (type != null) {
            jsonWriter.name("type");
            jsonWriter.value(type);
        }
        if (value != null) {
            jsonWriter.name("value");
            jsonWriter.beginArray();
            for (int i = 0; i < value.size(); i++) {
                value.get(i).serialize(jsonWriter);
            }
            jsonWriter.endArray();
        }
        jsonWriter.endObject();
    }

    public static MmoMetadata deserialize(JsonReader jsonReader) throws IOException {
        MmoMetadata mmoMetadata = new MmoMetadata();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String name = jsonReader.nextName();
            if ("type".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                mmoMetadata.type = jsonReader.nextString();
            } else if ("value".equals(name) && jsonReader.peek() != JsonToken.NULL) {
                ArrayList<FileMetadata> fileArray = new ArrayList<>();
                ArrayList<String> urlArray = new ArrayList<>();
                jsonReader.beginArray();
                while (jsonReader.hasNext()) {
                    if (jsonReader.peek() != JsonToken.NULL) {
                        if (jsonReader.peek() == JsonToken.STRING) {
                            urlArray.add(jsonReader.nextString());
                        } else {
                            FileMetadata item = FileMetadata.deserialize(jsonReader);
                            fileArray.add(item);
                        }
                    } else {
                        jsonReader.skipValue();
                    }
                }
                jsonReader.endArray();
                mmoMetadata.value = fileArray;
                mmoMetadata.urls = urlArray;
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        return mmoMetadata;
    }
}