/**
 * <h1>Amelia SDK 3.0.0</h1>
 */
package net.ipsoft.amelia.sdk;