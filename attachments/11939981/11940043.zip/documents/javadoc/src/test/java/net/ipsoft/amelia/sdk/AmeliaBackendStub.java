package net.ipsoft.amelia.sdk;

import net.ipsoft.amelia.sdk.internal.restapi.IAmeliaBackendApi;
import net.ipsoft.amelia.sdk.internal.restapi.LoginReq;
import net.ipsoft.amelia.sdk.internal.restapi.NewConversationReq;

public class AmeliaBackendStub implements IAmeliaBackendApi {

    @Override
    public void setCallback(Callback callback) {

    }

    @Override
    public void initReq() {

    }

    @Override
    public void whoAmIReq(String xCsrfToken) {

    }

    @Override
    public void checkReq(String xCsrfToken) {

    }

    @Override
    public void authSystems() {

    }

    @Override
    public void anonymousAllowedReq(String xCsrfToken) {

    }

    @Override
    public void anonymousCreateReq(String xCsrfToken) {

    }

    @Override
    public void loginReq(LoginReq loginReq) {

    }

    @Override
    public void logoutReq() {

    }

    @Override
    public void domainsReq(String xCsrfToken) {

    }

    @Override
    public void newConversationReq(NewConversationReq newConversationReq) {

    }

    @Override
    public String baseUrl() {
        return null;
    }

    @Override
    public boolean addCookies(String cookies) {
        return false;
    }
}
