package net.ipsoft.amelia.sdk;

import net.ipsoft.amelia.sdk.internal.chat.IAmeliaStompApi;
import net.ipsoft.amelia.sdk.internal.common.Conversation;

public class AmeliaStompApiStub implements IAmeliaStompApi {

    @Override
    public void setChatListener(Callback chatListener) {

    }

    @Override
    public void startConversation(Conversation conversation) {

    }

    @Override
    public void ask(String messageText) {

    }

    @Override
    public void endConversationReq() {

    }

    @Override
    public void send(String messageType) {

    }

    @Override
    public void send(String messageText, String messageType) {

    }

    @Override
    public void submitForm(FormInputData form, String messageText) {

    }

    @Override
    public void runAction(String processName, String argumentsJson, String messageText) {

    }
}
