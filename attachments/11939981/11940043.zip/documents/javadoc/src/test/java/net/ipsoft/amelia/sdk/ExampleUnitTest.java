package net.ipsoft.amelia.sdk;

import net.ipsoft.amelia.sdk.internal.chat.IAmeliaStompApi;
import net.ipsoft.amelia.sdk.internal.common.Provider;
import net.ipsoft.amelia.sdk.internal.restapi.IAmeliaBackendApi;

import org.junit.Test;

public class ExampleUnitTest {

    @Test
    public void successfulAnonymousLogin() throws Exception {
        IAmeliaBackendApi ameliaBackendApi = new AmeliaBackendStub();
        IAmeliaStompApi ameliaStompApi = new AmeliaStompApiStub();
        Provider provider = new Provider(ameliaBackendApi, ameliaStompApi);

        new AmeliaChatBuilder()
                .setBaseUrl("net.amelia.test")
                .setProvider(provider)
                .setDomainCode("auto")
                .setAllowAnonymous(true)
                .addSessionListener(new BaseSessionListener() {
                    @Override
                    public void onConversationStart() {
                        System.out.println("test succeeded");
                    }
                })
                .build();

    }
}