package com.ipsoft.amelia.sampleapp;

import net.ipsoft.amelia.sdk.AmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.FormInputData;

/**
 * Immutable record of interaction between the app and Amelia
 */
public class ChatRecord {

    /**
     * <code>true</code> when the message comes from the app, <code>false</code> if it came from
     * Amelia
     */
    public final boolean isSelf;

    /**
     * A UI friendly display name
     */
    public final String userDisplayName;

    /**
     * The spoken message
     */
    public final String messageText;

    /**
     * Amelia's mood
     */
    public final String mood;

    /**
     * Any form supplied in the message represented by this ChatRecord
     */
    public final FormInputData form;

    /**
     * Any BPN JSON formatted integration data supplied in the message represented by this ChatRecord
     */
    public final String integration;


    /**
     * indicates if the user input needs to be secured
     */
    public final boolean shouldSecureInput;
    /**
     * @param message
     */
    public ChatRecord(AmeliaOutboundMessage message) {

        this.isSelf = message.isSelfEcho();
        this.userDisplayName = message.getFromUserDisplayName();
        this.messageText = message.getMessageText();
        this.mood = message.getAttributes().getMood();

        if (message.getAttributes() != null) {
            form = message.getAttributes().getFormInputData();
            integration = message.getAttributes().getIntegrationMessageData();
            shouldSecureInput = message.getAttributes().shouldSecureInput();
        } else {
            form = null;
            integration = null;
            shouldSecureInput = false;
        }
    }

}
