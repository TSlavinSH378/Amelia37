package com.ipsoft.amelia.sampleapp;

import net.ipsoft.amelia.sdk.AmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.BaseConversationListener;

import java.util.ArrayList;
import java.util.List;

public class ChatHistory extends BaseConversationListener {

    private List<ChatRecord> chatRecords = new ArrayList<>();

    public List<ChatRecord> getRecords() {
        return chatRecords;
    }

    @Override
    public void onChatHistoryClear() {
        chatRecords.clear();
    }

    @Override
    public void outboundFinalTextMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundProgressTextMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundIdleTalkMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void wolframAlphaFinalMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundEchoMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundFinalErrorMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundConversationClosedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundSessionClosedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundIntegrationMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundAgentSessionChangedMessage(AmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void onUploadRequest(AmeliaOutboundMessage message) {
        chatRecords.add(new UploadChatRecord(message));
    }

    @Override
    public void outboundMmoDownloadMessage(AmeliaOutboundMessage message) {
        chatRecords.add(new DownloadChatRecord(message));
    }
}
