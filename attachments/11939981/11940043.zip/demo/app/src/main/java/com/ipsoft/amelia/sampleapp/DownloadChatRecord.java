package com.ipsoft.amelia.sampleapp;

import net.ipsoft.amelia.sdk.AmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.DownloadMessage;

/**
 * A specific chat record for MMO downloads
 */
public class DownloadChatRecord extends ChatRecord {

    public final DownloadMessage downloadMessage;

    public DownloadChatRecord(AmeliaOutboundMessage message) {
        super(message);
        downloadMessage = message.getDownloadMessage();
    }

}
