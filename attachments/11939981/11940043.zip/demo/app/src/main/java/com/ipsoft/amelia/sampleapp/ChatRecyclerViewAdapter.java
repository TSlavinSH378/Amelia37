package com.ipsoft.amelia.sampleapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ipsoft.amelia.sampleapp.accordion.Section;

import net.ipsoft.amelia.sdk.AmeliaError;
import net.ipsoft.amelia.sdk.FormInputData;

import java.io.File;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.regex.Pattern;

public class ChatRecyclerViewAdapter extends RecyclerView.Adapter<ChatRecyclerViewAdapter.ViewHolder> {

    private static final int VIEW_TYPE_ME = 0;
    private static final int VIEW_TYPE_AMELIA = 1;
    private static final int VIEW_TYPE_MMO_ME = 2;
    private static final int VIEW_TYPE_MMO_AMELIA = 3;
    private static final int VIEW_TYPE_FORM = 4;

    private final List<ChatRecord> mValues;

    private FormSubmitListener mFormSubmitListener;
    private View.OnClickListener onPdfClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Uri uri = (Uri) v.getTag();
            uri = FileProvider.getUriForFile(v.getContext(), v.getContext().getApplicationContext().getPackageName() + ".provider", new File(uri.getPath()));
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            v.getContext().startActivity(intent);
        }
    };

    public ChatRecyclerViewAdapter(ChatHistory chatHistory, @Nullable FormSubmitListener formSubmitListener) {
        mValues = chatHistory.getRecords();
        mFormSubmitListener = formSubmitListener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case VIEW_TYPE_ME:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_me , parent, false);
                return new ViewHolder(view);
            case VIEW_TYPE_AMELIA:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_amelia, parent, false);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_MMO_ME:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_mmo_me, parent, false);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_MMO_AMELIA:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_mmo_amelia, parent, false);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_FORM:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_form, parent, false);
                return new FormViewHolder(view);

        }
        return null;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.mItem = mValues.get(position);
        holder.mContentView.setOnClickListener(null);
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_ME:
            case VIEW_TYPE_AMELIA:
                TextView messageTextView = (TextView) holder.mContentView;
                Context context = messageTextView.getContext();
                if (holder.mItem instanceof DownloadChatRecord) {
                    String text = ((DownloadChatRecord) holder.mItem).downloadMessage.getMetadata().getUrl();
                    messageTextView.setText(text);
                } else if (holder.mItem instanceof UploadChatRecord) {
                    UploadChatRecord uploadChatRecord = (UploadChatRecord) holder.mItem;
                    if (uploadChatRecord.uploadMessage.getRecentError() != null) {
                        messageTextView.setText(uploadChatRecord.uploadMessage.getRecentError().message);
                    } else if (uploadChatRecord.uploadMessage.isUploaded()) {
                        messageTextView.setText(context.getString(R.string.uploaded, uploadChatRecord.uploadMessage.fileType));
                    } else {
                        messageTextView.setText(R.string.uploading);
                    }
                } else if (holder.mItem.integration != null && holder.mItem.integration.length() > 0) {
                    final Section section;
                    try {
                        section = Section.deserialize(new JSONObject(holder.mItem.integration));
                        messageTextView.setText(context.getString(R.string.tap_to_open_integration, section.getTitle()));
                        messageTextView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (holder.mView.getContext() instanceof ChatActivity) {
                                    ((ChatActivity) holder.mView.getContext()).showIntegration(section);
                                }
                            }
                        });
                    } catch (JSONException e) {
                        //Log.e("chat-fragment", "Failed to parse integration message");
                    }
                } else {
                    String textMessage = holder.mItem.messageText;
                   Pattern htmlPattern
                            = Pattern.compile("^(.*?)(<\\w){1}(.|\\s)*(>){1}(.*?)$");
                    if(htmlPattern.matcher(textMessage).matches()){
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            messageTextView.setText(Html.fromHtml(textMessage,Html.FROM_HTML_MODE_LEGACY));
                        } else {
                            messageTextView.setText(Html.fromHtml(textMessage));
                        }
                    }else {
                        messageTextView.setText(textMessage);
                    }
                }
                break;
            case VIEW_TYPE_MMO_ME: {
                DownloadChatRecord mmoItem = (DownloadChatRecord) holder.mItem;
                ImageView imageView = ((ImageView) holder.mContentView);
                if (mmoItem.downloadMessage.getMimeType(0).contains("/pdf")) {
                    imageView.setImageDrawable(ContextCompat.getDrawable(imageView.getContext(), R.drawable.ic_pdf_black_40dp));
                } else {
                    imageView.setImageURI(mmoItem.downloadMessage.getUri(0));
                }
                break;
            } case VIEW_TYPE_MMO_AMELIA: {
                final DownloadChatRecord mmoItem = (DownloadChatRecord) holder.mItem;
                ViewGroup container = (ViewGroup) holder.mContentView;

                final int marginSmall = container.getContext().getResources().getDimensionPixelOffset(R.dimen.margin_small);

                container.removeAllViews();
                for (int i = 0; i < mmoItem.downloadMessage.getMetadata().getValue().size(); i++) {
                    ImageView imageView = new ImageView(container.getContext());
                    imageView.setBackgroundResource(R.drawable.chat_bubble_amelia);
                    imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                    imageView.setPadding(marginSmall, marginSmall, marginSmall, marginSmall);
                    container.addView(imageView);
                    LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) imageView.getLayoutParams();
                    lp.setMargins(0, marginSmall, 0, marginSmall);
                    lp.width = ViewGroup.LayoutParams.WRAP_CONTENT;
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                }

                for (int i = 0; i < mmoItem.downloadMessage.getMetadata().getValue().size(); i++) {
                    final String mimeType = mmoItem.downloadMessage.getMimeType(0);

                    final AmeliaError recentError = mmoItem.downloadMessage.getRecentError(i);
                    final ImageView imageView = (ImageView) container.getChildAt(i);

                    if (recentError != null || mimeType == null) {
                        imageView.setBackgroundColor(Color.RED);
                        imageView.setMinimumWidth(200);
                        imageView.setMinimumHeight(200);
                        continue;
                    }

                    if (mimeType.contains("/pdf")) {
                        imageView.setImageDrawable(ContextCompat.getDrawable(container.getContext(), R.drawable.ic_pdf_black_40dp));
                        imageView.setTag(mmoItem.downloadMessage.getUri(0));
                        imageView.setOnClickListener(onPdfClickListener);
                    } else if(mimeType.contains("image")){
                        imageView.setImageURI(mmoItem.downloadMessage.getUri(0));
                        imageView.setTag(null);
                        imageView.setOnClickListener(null);
                    }else{//other types of file downloaded.
                        imageView.setImageDrawable(ContextCompat.getDrawable(container.getContext(), R.drawable.file_icon));
                        imageView.setTag(null);
                        imageView.setOnClickListener(null);
                        imageView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String fileUrl = mmoItem.downloadMessage.getUri(0).toString();
                                Toast.makeText(holder.mContentView.getContext(),"file downloaded at: "+fileUrl,Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }
                break;
            } case VIEW_TYPE_FORM:
                final FormInputData form = holder.mItem.form;

                TextView msgTextView = (TextView) holder.mContentView;
                msgTextView.setText(holder.mItem.messageText);

                final ViewGroup placeHolderView = ((FormViewHolder) holder).getFormPlaceholder();

                FormView formView = new FormView(placeHolderView.getContext());
                formView.setFormInputData(form);
                formView.setFormSubmitListener(new FormView.FormSubmittedListener() {
                    @Override
                    public void onFormSubmitted(String value) {
                        if (mFormSubmitListener != null) {
                            mFormSubmitListener.onFormSubmitted(form, value);
                        }
                    }
                });

                // Replace the placeholder with the actual formView
                final ViewGroup parent = (ViewGroup) placeHolderView.getParent();
                final int placeholderIndex = parent.indexOfChild(placeHolderView);
                parent.removeView(placeHolderView);
                formView.setId(placeHolderView.getId());
                parent.addView(formView, placeholderIndex);

                break;
        }
        if (!holder.mItem.isSelf) {
            ((AmeliaViewHolder) holder).emoticon.setText(getEmoticon(holder.mItem));
        }

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // retry
            }
        });
    }

    private String getEmoticon(ChatRecord chatRecord) {
        if (chatRecord instanceof UploadChatRecord) {
            UploadChatRecord uploadChatRecord = (UploadChatRecord) chatRecord;
            if (uploadChatRecord.uploadMessage.isUploaded()) {
                return new String(Character.toChars(0x1F44D));
            } else {
                return new String(Character.toChars(0x1F449));
            }
        } else {
            switch (chatRecord.mood) {
                case "NEUTRAL":
                    return new String(Character.toChars(0x1F610));
                case "HAPPY":
                    return new String(Character.toChars(0x1F603));
                case "SAD":
                    return new String(Character.toChars(0x1F622));
                case "SURPRISED":
                    return new String(Character.toChars(0x1F632));
                case "ANGRY":
                    return new String(Character.toChars(0x1F621));
                case "DISGUSTED":
                    return new String(Character.toChars(0x1F623));
                case "FEAR":
                    return new String(Character.toChars(0x1F631));
                case "CONTEMPT":
                    return new String(Character.toChars(0x1F620));
                default:
                    return chatRecord.mood;
            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        ChatRecord item = mValues.get(position);
        if (item instanceof DownloadChatRecord && "file".equals(((DownloadChatRecord) item).downloadMessage.getMetadata().getType())) {
            return mValues.get(position).isSelf ? VIEW_TYPE_MMO_ME : VIEW_TYPE_MMO_AMELIA;
        }

        // Display as form if there is a form and it is the last item
        if (item.form != null && position == (mValues.size() - 1)) {
            return VIEW_TYPE_FORM;
        }
        return mValues.get(position).isSelf ? VIEW_TYPE_ME : VIEW_TYPE_AMELIA;
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public void removeFormSubmitListener() {
        mFormSubmitListener = null;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final View mContentView;
        public ChatRecord mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mContentView = view.findViewById(R.id.message);
        }
    }

    public class AmeliaViewHolder extends ViewHolder {
        public final TextView emoticon;
        public AmeliaViewHolder(View view) {
            super(view);
            emoticon = (TextView) view.findViewById(R.id.emoticon);
        }
    }

    public class FormViewHolder extends AmeliaViewHolder {

        public FormViewHolder(View view) {
            super(view);
        }

        public ViewGroup getFormPlaceholder() {
            return (ViewGroup) itemView.findViewById(R.id.fields_container);
        }
    }

    interface FormSubmitListener {
        void onFormSubmitted(FormInputData form, String message);
    }
}
