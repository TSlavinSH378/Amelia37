package com.ipsoft.amelia.sampleapp;

import net.ipsoft.amelia.sdk.AmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.UploadMessage;

/**
 * A specific chat record for MMO upload request
 */
public class UploadChatRecord extends ChatRecord {

    public final UploadMessage uploadMessage;

    public UploadChatRecord(AmeliaOutboundMessage message) {
        super(message);
        this.uploadMessage = message.getUploadMessage();
    }

}
