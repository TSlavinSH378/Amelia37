package com.ipsoft.amelia.sampleapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import net.ipsoft.amelia.sdk.AmeliaError;
import net.ipsoft.amelia.sdk.AuthSystem;
import net.ipsoft.amelia.sdk.BaseSessionListener;
import net.ipsoft.amelia.sdk.Domain;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.ISessionListener;
import net.ipsoft.amelia.sdk.LoginOptions;

import java.util.List;

import static java.security.AccessController.getContext;

public class DomainFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {

    private static final String ARG_COLUMN_COUNT = "column-count";
    private static final int LOGIN_INTERNAL_REQUEST_CODE = 1002;
    private static final int LOGIN_SAML_REQUEST_CODE = 1003;
    private int mColumnCount = 1;
    private OnListFragmentInteractionListener mListener;
    private DomainRecyclerViewAdapter adapter;
    private IAmeliaChat ameliaChat;
    private SwipeRefreshLayout swipeToRefresh;
    private AmeliaApplication app;
    private boolean isSamlLogin;
    private AuthSystem authSystem;
    private boolean pendingNewConversation;

    private ISessionListener sessionListener = new BaseSessionListener() {

        @Override
        public void onDomainSelectionRequired(List<Domain> domains) {
            if (isAdded()) {
                adapter.setValues(domains);
                swipeToRefresh.setRefreshing(false);
                swipeToRefresh.setEnabled(false);
            }
            unsetPendingState();
        }

        @Override
        public void onDomainFail(AmeliaError error) {
            if (isAdded()) {
                Snackbar.make(getView(), "There was error fetching domains.", Snackbar.LENGTH_SHORT).show();
                swipeToRefresh.setRefreshing(false);
                swipeToRefresh.setEnabled(true);
            }
            unsetPendingState();
        }

        @Override
        public void onSessionStart() {
            if (isAdded()) {
                getActivity().supportInvalidateOptionsMenu();
            }
            unsetPendingState();
        }

        @Override
        public void onSessionFail(AmeliaError error) {
            if (isAdded()) {
                Snackbar.make(getView(), "There was error starting the session.", Snackbar.LENGTH_SHORT).show();
                swipeToRefresh.setRefreshing(false);
                swipeToRefresh.setEnabled(true);
            }
            unsetPendingState();
        }

        @Override
        public void onLoginRequired(List<AuthSystem> authSystems) {
            if (isAdded()) {
                authSystem = findAuthSystem(authSystems);
                Log.d("steve","auth system: "+authSystem);
                if (!isSamlLogin) {
                    Intent intent = new Intent(getContext(), LoginActivity.class);
                    intent.putExtra(LoginActivity.EXTRA_AUTH_SYSTEM, authSystem);
                    startActivityForResult(intent, LOGIN_INTERNAL_REQUEST_CODE);
                } else {
                    if (authSystem != null) {
                        AmeliaApplication app = (AmeliaApplication)DomainFragment.this.getActivity().getApplication();
                        Intent ssoLoginIntent = new Intent(getContext(), SsoLoginActivity.class);
                        //loginMode can be anything, depending on how it is configured on server, for SAML authentication
                        ssoLoginIntent.putExtra(SsoLoginActivity.EXTRA_LOGIN_URL, app.getBaseUrl()+"/Amelia" + authSystem.getLoginPath()+"?loginMode=mobileios");
                        startActivityForResult(ssoLoginIntent, LOGIN_SAML_REQUEST_CODE);
                    } else {
                        Snackbar.make(getView(), "No auth systems available for SAML login", Snackbar.LENGTH_SHORT).show();
                        swipeToRefresh.setRefreshing(false);
                        swipeToRefresh.setEnabled(true);
                    }
                }
            }
        }
    };

    public DomainFragment() {
    }

    @SuppressWarnings("unused")
    public static DomainFragment newInstance(int columnCount) {
        DomainFragment fragment = new DomainFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }

        app = (AmeliaApplication) getActivity().getApplication();
        ameliaChat = app.getAmeliaChat();
        ameliaChat.addSessionListener(sessionListener);



        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        isSamlLogin = sharedPreferences.getBoolean(getString(R.string.key_saml_login_enabled), false);

        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_domain_grid, container, false);

        Context context = view.getContext();
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.list);
        if (mColumnCount <= 1) {
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
        } else {
            recyclerView.setLayoutManager(new GridLayoutManager(context, mColumnCount));
        }

        adapter = new DomainRecyclerViewAdapter(mListener);
        recyclerView.setAdapter(adapter);

        swipeToRefresh = (SwipeRefreshLayout) view.findViewById(R.id.swipe_to_refresh);
        swipeToRefresh.setOnRefreshListener(this);
        swipeToRefresh.setRefreshing(true);

        pendingNewConversation = true;
        ameliaChat.startNewConversation();

        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        ameliaChat.removeSessionListener(sessionListener);
    }


    @Override
    public void onRefresh() {
        pendingNewConversation = true;
        ameliaChat.startNewConversation();
    }

    public interface OnListFragmentInteractionListener {
        void onListFragmentInteraction(Domain item);
    }

    public AuthSystem findAuthSystem(List<AuthSystem> authSystems) {
        if (!isSamlLogin) {
            for (AuthSystem authSystem : authSystems) {
                if (!authSystem.getRedirect()) {//replace ipsoft_ldap with your auth system code
                    return authSystem;
                }
            }
        } else {
            for (AuthSystem authSystem : authSystems) {
                if (authSystem.getRedirect()) {//replace ipsoft_ldap with your auth system code
                    return authSystem;
                }
            }
        }
        return null;
    }

    private void unsetPendingState() {
        pendingNewConversation = false;
        getActivity().supportInvalidateOptionsMenu();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == LOGIN_INTERNAL_REQUEST_CODE) {
            switch (resultCode) {
                case Activity.RESULT_CANCELED:
                    getActivity().finish();
                    break;
            }
        } else if (requestCode == LOGIN_SAML_REQUEST_CODE) {
            switch (resultCode) {
                case Activity.RESULT_OK:
                    LoginOptions loginOptions = null;
                    if(data!=null&&data.getExtras()!=null) {
                        loginOptions = new LoginOptions(authSystem,  data.getExtras().getString(AmeliaAppConstants.SSO_COOKIE));
                    }else{
                        loginOptions = new LoginOptions(authSystem,  getActivity().getApplicationContext());
                    }                    ameliaChat.login(loginOptions);
                    authSystem = null;
                    break;
                case Activity.RESULT_CANCELED:
                    getActivity().finish();
                    break;
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        getActivity().supportInvalidateOptionsMenu();
    }



    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        if (ameliaChat.getUser() != null && !ameliaChat.getUser().isAnonymous()) {
            inflater.inflate(R.menu.menu_logout, menu);
        } else if (!pendingNewConversation && (ameliaChat.getUser() == null || ameliaChat.getUser().isAnonymous())) {
            inflater.inflate(R.menu.menu_login, menu);
        } else {
            super.onCreateOptionsMenu(menu, inflater);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_logout:
                ameliaChat.logout();
                Intent intent = new Intent(getContext(), MainActivity.class);
                startActivity(intent);
                return true;
            case R.id.action_login:
                pendingNewConversation = true;
                ameliaChat.stepupLogin();
                return true;
        }
        return false;
    }
}
