package com.ipsoft.amelia.sampleapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import net.ipsoft.amelia.sdk.BaseSessionListener;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.IAmeliaError;
import net.ipsoft.amelia.sdk.ISessionInfo;
import net.ipsoft.amelia.sdk.ISessionListener;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int SETTINGS_REEQUEST = 1001;
    private AmeliaApplication app;
    private IAmeliaChat ameliaChat;
    private TextView btnAnonymousChat;
    private View startButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        btnAnonymousChat = (TextView)findViewById(R.id.btn_anonymous);
        startButton = findViewById(R.id.start_button);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DomainActivity.class);
                intent.putExtra(Utils.LOGIN_TYPE, LoginType.LOGIN_TYPE_AUTH.ordinal());
                startActivity(intent);
            }
        });
        btnAnonymousChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DomainActivity.class);
                intent.putExtra(Utils.LOGIN_TYPE, LoginType.LOGIN_TYPE_ANONYMOUS.ordinal());
                startActivity(intent);
            }
        });
        createNewChat();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivityForResult(intent,SETTINGS_REEQUEST);
                return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check if we came back from settings screen,re-init ameliaChat with new server url
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == SETTINGS_REEQUEST) {
            createNewChat();
        }
    }

    private void createNewChat(){
        app = (AmeliaApplication) this.getApplication();
        app.newAmeliaChat();
        ameliaChat = app.getAmeliaChat();
        ameliaChat.addSessionListener(sessionListener);
        ameliaChat.initialize();
    }

    private ISessionListener sessionListener = new BaseSessionListener() {
        @Override
        public void sessionInitialized(final ISessionInfo sessionInfo) {
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (sessionInfo.isAnonymousAllowed()) {//anonymous allowed on the server
                        btnAnonymousChat.setVisibility(View.VISIBLE);
                    }else{
                        btnAnonymousChat.setVisibility(View.GONE);
                    }
                }
            });
        }

        @Override
        public void onSessionInitFail(IAmeliaError error) {
            Log.e(TAG,"Error:"+error.getMessage());
        }
    };
}
