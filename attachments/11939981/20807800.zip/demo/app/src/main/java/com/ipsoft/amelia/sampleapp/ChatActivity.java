package com.ipsoft.amelia.sampleapp;

import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.ipsoft.amelia.sampleapp.accordion.Section;

import net.ipsoft.amelia.sdk.BaseDomain;
import net.ipsoft.amelia.sdk.BaseSessionListener;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.BaseConversation;
import net.ipsoft.amelia.sdk.ISessionListener;

public class ChatActivity extends AppCompatActivity implements IntegrationFragment.ActionListener{

    public static final String DOMAIN = "domain";
    public static final String CONVERSATION = "conversation";

    private IAmeliaChat ameliaChat;

    private BaseConversation conversation;

    private BaseDomain domain;

    private ISessionListener listener = new BaseSessionListener(){
        public void onConversationStart(BaseConversation conversation) {
            ChatActivity.this.conversation = conversation;
            ChatFragment chatFragment = ChatFragment.newInstance(domain,conversation);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.chat_fragment, chatFragment)
                    .commit();
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_chat);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        AmeliaApplication app = (AmeliaApplication) getApplication();
        ameliaChat = app.getAmeliaChat();
        ameliaChat.addSessionListener(listener);
        domain = getIntent().getParcelableExtra("domain");
        if (savedInstanceState == null) {
            selectDomain(domain);
        }


        setVolumeControlStream(AudioManager.STREAM_MUSIC);
    }

    private void selectDomain(BaseDomain domain) {
        ameliaChat.selectDomain(domain);
    }

    @Override
    protected void onStart() {
        super.onStart();
        invalidateOptionsMenu();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (ameliaChat.getUser() != null && !ameliaChat.getUser().isAnonymous()) {
            getMenuInflater().inflate(R.menu.menu_logout, menu);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        if (hideIntegrationFragment()) return;
        super.onBackPressed();
        ameliaChat.endConversation(this.conversation);
    }

    private boolean hideIntegrationFragment() {
        final Fragment integrationFragment = getSupportFragmentManager().findFragmentByTag("TAG-INTEGRATION-FRAGMENT");
        if (integrationFragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.fade_out)
                    .remove(integrationFragment)
                    .commit();


            getSupportActionBar().setTitle(R.string.app_name);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            return true;
        }
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                ameliaChat.endConversation(this.conversation);
                return false;
            case R.id.action_logout:
                ameliaChat.logout();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                return true;
        }
        return false;
    }

    public void showIntegration(Section section) {
        final IntegrationFragment integrationFragment = new IntegrationFragment();
        integrationFragment.setSection(section);

        getSupportActionBar().setTitle(section.getTitle());
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);

        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.fade_out)
                .add(R.id.fragment_container, integrationFragment, "TAG-INTEGRATION-FRAGMENT")
                .commit();
        findViewById(R.id.fragment_container).setVisibility(View.VISIBLE);
    }

    @Override
    public void onAction(String processName, String processArgs, String utterance) {
        ameliaChat.runAction(this.conversation,processName, processArgs, utterance);
        hideIntegrationFragment();
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        this.ameliaChat.removeSessionListener(listener);
    }
}
