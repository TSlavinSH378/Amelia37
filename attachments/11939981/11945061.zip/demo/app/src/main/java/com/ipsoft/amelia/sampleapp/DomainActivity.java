package com.ipsoft.amelia.sampleapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import net.ipsoft.amelia.sdk.BaseDomain;

public class DomainActivity extends AppCompatActivity implements DomainFragment.OnListFragmentInteractionListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_domain);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public void onListFragmentInteraction(BaseDomain domain) {
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra(ChatActivity.DOMAIN, domain);
        startActivity(intent);
    }

}
