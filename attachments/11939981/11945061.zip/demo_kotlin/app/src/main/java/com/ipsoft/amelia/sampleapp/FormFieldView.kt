package com.ipsoft.amelia.sampleapp

import android.content.Context
import android.util.AttributeSet
import android.view.ContextThemeWrapper
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

import net.ipsoft.amelia.sdk.FormInputField
import net.ipsoft.amelia.sdk.FormInputFieldOptions

import java.util.ArrayList

import android.view.ViewGroup.LayoutParams.MATCH_PARENT


class FormFieldView : LinearLayout {

    private var submitListener: FieldSubmittedListener? = null

    constructor(context: Context) : super(context) {
        if (isInEditMode) {
            init(DUMMY_FIELD)
        }
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        if (isInEditMode) {
            init(DUMMY_FIELD)
        }
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        if (isInEditMode) {
            init(DUMMY_FIELD)
        }
    }

    fun setFormField(formField: FormInputField) {
        init(formField)
    }

    fun setFieldSubmittedListener(listener: FieldSubmittedListener?) {
        this.submitListener = listener
    }

    private fun init(formField: FormInputField) {
        orientation = LinearLayout.VERTICAL

        setBackgroundResource(R.drawable.chat_bubble_amelia)

        val isMultiSelect = FIELD_TYPE_MULTIPLE_SELECTION == formField.fieldType

        for (options in formField.options) {

            val opt = Button(ContextThemeWrapper(context, R.style.AppTheme_FormButton), null, 0)
            opt.text = options.name
            addView(opt)
            opt.layoutParams.width = MATCH_PARENT
            opt.setOnClickListener {
                options.selected = !options.selected
                opt.isSelected = options.selected

                if (submitListener != null && !isMultiSelect) {
                    submitListener!!.onFieldSubmitted(options.name)
                }
            }
        }

        // If it is multiple selection we need a submit button
        if (isMultiSelect) {
            val submitBtn = Button(ContextThemeWrapper(context, R.style.AppTheme_FormButton), null, 0)
            submitBtn.setText(R.string.action_submit)

            submitBtn.setOnClickListener {
                if (submitListener != null) {
                    submitListener!!.onFieldSubmitted(getMultipleSelectionString(formField))
                }
            }
            addView(submitBtn)
        }

        // No options so let's just use the field as a simple button
        if (formField.options.isEmpty()) {
            val name = Button(ContextThemeWrapper(context, R.style.AppTheme_FormButton), null, 0)
            name.text = formField.name
            addView(name)
            name.setOnClickListener {
                if (submitListener != null) {
                    submitListener!!.onFieldSubmitted(formField.name)
                }
            }
        }
    }

    private fun getMultipleSelectionString(formField: FormInputField): String {
        val selections = StringBuilder()
        var isFirst = true

        for (formInputFieldOptions in formField.options) {
            if (formInputFieldOptions.selected) {
                if (!isFirst) {
                    selections.append(", ")
                }
                isFirst = false
                selections.append(formInputFieldOptions.name)
            }
        }

        if (selections.length == 0) {
            selections.append(context.getString(R.string.none))
        }

        return selections.toString()
    }

     interface FieldSubmittedListener {
        fun onFieldSubmitted(value: String)
    }

    companion object {
        val FIELD_TYPE_MULTIPLE_SELECTION = "multipleSelection"
        val DUMMY_FIELD = FormInputField()

        init {
            DUMMY_FIELD.name = "Sample field"
            DUMMY_FIELD.fieldType = FIELD_TYPE_MULTIPLE_SELECTION
            val options = ArrayList<FormInputFieldOptions>(2)
            val opt1 = FormInputFieldOptions()
            opt1.name = "Choice 1"
            options.add(opt1)
            val opt2 = FormInputFieldOptions()
            opt2.name = "Choice 2"
            options.add(opt2)
            DUMMY_FIELD.options = options
        }
    }
}
