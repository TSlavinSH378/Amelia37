package com.ipsoft.amelia.sampleapp.accordion

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

import java.util.ArrayList

class Section {

    var name: String? = null
        protected set
    var sectionType: String? = null
    var title: String? = null
        protected set
    var imageBase64: String? = null
        protected set
    var actionLabel: String? = null
        protected set
    var actionProcessName: String? = null
        protected set
    var actionProcessArgs: String? = null
        protected set
    var selectionUtterance: String? = null
    var utteranceConjunction: String? = null
        protected set
    var children: List<Section>? = null
        protected set
    var sectionFields: List<SectionField>? = null
        protected set

    companion object {

        @Throws(JSONException::class)
        fun deserialize(jsonObject: JSONObject): Section {
            val section = Section()
            section.name = jsonObject.optString("name")
            section.sectionType = jsonObject.optString("sectionType")
            section.title = jsonObject.optString("title")
            section.imageBase64 = jsonObject.optString("imageBase64")
            section.actionLabel = jsonObject.optString("actionLabel")
            val selectionUtteranceMetadata = jsonObject.optJSONObject("selectionUtteranceMetadata")
            if (selectionUtteranceMetadata != null) {
                section.selectionUtterance = selectionUtteranceMetadata.optString("staticUtterance")
                section.utteranceConjunction = selectionUtteranceMetadata.optString("conjunction")
            }
            val actionProcess = jsonObject.optJSONObject("actionProcess")
            if (actionProcess != null) {
                section.actionProcessName = actionProcess.optString("processName")
                val processArgs = actionProcess.optJSONObject("processArgs")
                section.actionProcessArgs = processArgs?.toString()
            }

            var jsonArray = jsonObject.getJSONArray("children")
            val children = ArrayList<Section>(jsonArray.length())
            for (i in 0..jsonArray.length() - 1) {
                children.add(Section.deserialize(jsonArray.getJSONObject(i)))
            }
            section.children = children

            jsonArray = jsonObject.getJSONArray("sectionFields")
            val sectionFields = ArrayList<SectionField>(jsonArray.length())
            for (i in 0..jsonArray.length() - 1) {
                sectionFields.add(SectionField.deserialize(jsonArray.getJSONObject(i)))
            }
            section.sectionFields = sectionFields

            return section
        }
    }

}
