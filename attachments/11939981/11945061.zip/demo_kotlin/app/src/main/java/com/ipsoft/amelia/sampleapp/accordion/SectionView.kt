package com.ipsoft.amelia.sampleapp.accordion

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.text.TextUtils
import android.util.AttributeSet
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

import com.ipsoft.amelia.sampleapp.IntegrationFragment
import com.ipsoft.amelia.sampleapp.R


class SectionView : LinearLayout {

    private var actionListener: IntegrationFragment.ActionListener? = null

    constructor(context: Context) : super(context) {}

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {}

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {}

    fun setActionListener(listener: IntegrationFragment.ActionListener) {
        actionListener = listener
    }

    fun setSection(section: Section) {
        initWithSection(section)
    }

    private fun initWithSection(section: Section) {
        View.inflate(context, R.layout.integration_section, this)

        val title = findViewById(R.id.section_title) as TextView
        if ("AccordionSection" == section.sectionType) {
            title.visibility = View.GONE
        } else {
            title.visibility = View.VISIBLE
            title.text = section.title
        }

        val imageView = findViewById(R.id.section_image) as ImageView
        if (!TextUtils.isEmpty(section.imageBase64)) {
            imageView.visibility = View.VISIBLE
            val dataOffset = section.imageBase64!!.indexOf(',')
            if (dataOffset >= 0) {
                val actualData = section.imageBase64!!.substring(dataOffset)
                val imgData = Base64.decode(actualData, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(imgData, 0, imgData.size)
                imageView.setImageBitmap(bitmap)
            } else {
                imageView.visibility = View.GONE
            }
        } else {
            imageView.visibility = View.GONE
        }

        val fieldsContainer = findViewById(R.id.fields) as ViewGroup
        fieldsContainer.removeAllViews()
        for (sectionField in section.sectionFields!!) {
            val field = View.inflate(context, R.layout.integration_layout_field, null)
            (field.findViewById(R.id.label) as TextView).text = sectionField.label
            (field.findViewById(R.id.value) as TextView).text = sectionField.value
            fieldsContainer.addView(field)
        }

        val childContainer = findViewById(R.id.children) as ViewGroup
        childContainer.removeAllViews()
        for (childSection in section.children!!) {
            val childSectionView = SectionView(context)
            childSectionView.setActionListener(actionListener!!)
            childSectionView.setSection(childSection)
            childContainer.addView(childSectionView)
        }

        val actionBtn = findViewById(R.id.section_action_btn) as Button
        if (!TextUtils.isEmpty(section.actionLabel)) {
            actionBtn.visibility = View.VISIBLE
            actionBtn.text = section.actionLabel
            actionBtn.setOnClickListener { actionListener!!.onAction(section.actionProcessName, section.actionProcessArgs, section.selectionUtterance) }
        } else {
            actionBtn.visibility = View.GONE
        }
    }
}
