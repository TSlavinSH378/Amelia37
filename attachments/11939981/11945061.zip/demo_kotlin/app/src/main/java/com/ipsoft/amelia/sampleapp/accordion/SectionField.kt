package com.ipsoft.amelia.sampleapp.accordion

import android.util.JsonWriter

import org.json.JSONObject

import java.io.IOException

class SectionField {
    var name: String? = null
        protected set
    var label: String? = null
        protected set
    var valueForDisplay: String? = null
        protected set
    var value: String? = null
        protected set

    @Throws(IOException::class)
    fun serialize(jsonWriter: JsonWriter) {
        jsonWriter.beginObject()
        if (name != null) {
            jsonWriter.name("name")
            jsonWriter.value(name)
        }
        if (label != null) {
            jsonWriter.name("label")
            jsonWriter.value(label)
        }
        if (valueForDisplay != null) {
            jsonWriter.name("valueForDisplay")
            jsonWriter.value(valueForDisplay)
        }
        if (value != null) {
            jsonWriter.name("value")
            jsonWriter.value(value)
        }
        jsonWriter.endObject()
    }

    companion object {

        fun deserialize(jsonObject: JSONObject): SectionField {
            val sectionField = SectionField()
            sectionField.name = jsonObject.optString("name")
            sectionField.label = jsonObject.optString("label")
            sectionField.valueForDisplay = jsonObject.optString("valueForDisplay")
            sectionField.value = jsonObject.optString("value")
            return sectionField
        }
    }
}
