package com.ipsoft.amelia.sampleapp;

import android.content.Context;

import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.BaseConversationListener;
import net.ipsoft.amelia.sdk.IConversation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatHistory extends BaseConversationListener {


    private Map<IConversation,Boolean> agentIdentityMap = new HashMap<>();
    private String remoteUserName;
    private Map<IConversation,List<ChatRecord>> chatRecordMap = new HashMap<>();
    private Context context;
    public List<ChatRecord> getRecords(IConversation conversation) {
        List<ChatRecord> record = chatRecordMap.get(conversation);
        if(record == null){
            record = new ArrayList<>();
            chatRecordMap.put(conversation,record);
        }
        return record;
    }
    public ChatHistory(Context context){
        this.context = context;
    }


    @Override
    public void onChatHistoryClear(IConversation conversation) {
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation);
        if(chatRecords!=null) {
            chatRecords.clear();
        }
    }

    @Override
    public void outboundTextMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
       addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundProgressTextMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundIdleTalkMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void wolframAlphaFinalMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundEchoMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundFinalErrorMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundConversationClosedMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundSessionClosedMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundIntegrationMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundAgentSessionChangedMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void onUploadRequest(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundMmoDownloadMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundFormInputMessage(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage){
        addRecord(conversation,ameliaOutboundMessage);
    }

    private void addRecord(IConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage){
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation);
        if(chatRecords==null){
            chatRecords = new ArrayList<>();
            chatRecordMap.put(conversation,chatRecords);
        }
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }
}
