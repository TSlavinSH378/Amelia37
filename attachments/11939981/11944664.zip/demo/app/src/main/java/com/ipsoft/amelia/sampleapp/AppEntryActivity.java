package com.ipsoft.amelia.sampleapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by yyang on 9/28/17.
 */

public class AppEntryActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Uri ssoResult = getIntent().getData();
        if(ssoResult!=null){
            String []cookie = ssoResult.toString().split("=");
            Intent intent = new Intent(this,SsoLoginActivity.class);
            intent.putExtra(AmeliaAppConstants.SSO_COOKIE,cookie.length>=1?cookie[1]:"");
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        }
        finish();
    }
}
