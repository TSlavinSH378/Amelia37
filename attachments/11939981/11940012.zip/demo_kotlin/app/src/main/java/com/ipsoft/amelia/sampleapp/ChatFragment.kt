package com.ipsoft.amelia.sampleapp

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.InputType
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.TextView
import net.ipsoft.amelia.sdk.*
import net.ipsoft.amelia.sdk.internal.common.ALog

import java.util.concurrent.atomic.AtomicInteger

class ChatFragment : Fragment(), ChatRecyclerViewAdapter.PermissionRequestListener {
    private val TAG = "ChatFragment"
    private var ameliaChat: IAmeliaChat? = null
    private var chatHistory: ChatHistory? = null
    private var adapter: ChatRecyclerViewAdapter? = null
    private var inputField: EditText? = null
    private var sendButton: View? = null
    private var speechButton: View? = null
    private var recyclerView: RecyclerView? = null
    private var swipeToRefresh: SwipeRefreshLayout? = null
    private var recentlyLoadedChatIndex = -1
    private var speechRecognizer: SpeechRecognizer? = null
    private var domain: BaseDomain? = null
    private var extStorageWritePermissionListener: ChatRecyclerViewAdapter.PermissionRequestCompletionListener? = null

    private val sendButtonClickListener = View.OnClickListener { submit() }

    private val sendButtonLongClickListener = View.OnLongClickListener {
        AlertDialog.Builder(context)
                .setTitle("Run the workflow")
                .setItems(R.array.run_the_workflow) { dialog, which ->
                    val workflow = resources.getStringArray(R.array.run_the_workflow)[which]
                    submit("run the workflow " + workflow)
                }
                .create()
                .show()
        true
    }

    private val speechButtonClickListener = View.OnClickListener {
        if (ensureMicrophonePermission()) {
            startSpeechListener()
        }
    }

    private val conversationListener = object : BaseConversationListener() {

        override fun onSecureInputEnabledChanged(enabled: Boolean) {
            if (inputField != null) {
                if (enabled) {
                    inputField!!.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                } else {
                    inputField!!.inputType = InputType.TYPE_CLASS_TEXT
                }
            }
        }

        override fun onInputEnabledChanged(enabled: Boolean, messageType: String?, reason: IAmeliaChat.InputStateChangeReason?) {
            speechButton!!.isEnabled = enabled
            sendButton!!.isEnabled = enabled
        }

        override fun onMoodChange(newMood: String?, oldMood: String?) {
            if (isAdded) {
                (activity as AppCompatActivity).supportActionBar!!.setIcon(getMoodIcon(newMood))
            }
        }

        override fun outboundTextMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            notifyNewMessage()
        }

        override fun outboundProgressTextMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            notifyNewMessage()
        }

        override fun outboundIdleTalkMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            notifyNewMessage()
        }

        override fun outboundAgentSessionChangedMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            notifyNewMessage()
        }

        override fun wolframAlphaFinalMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            notifyNewMessage()
        }

        override fun outboundFormInputMessage(ameliaOutboundMessage: IAmeliaOutboundMessage) {
            notifyNewMessage()
        }


        override fun outboundFinalErrorMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            notifyNewMessage()
        }

        override fun outboundConversationClosedMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            if (isAdded) {
                activity.finish()
            }
        }

        override fun outboundIntegrationMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            notifyNewMessage()
        }

        override fun outboundSessionClosedMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            notifyNewMessage()
        }

        override fun outboundEchoMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            notifyNewMessage()
        }

        override fun outboundMmoDownloadMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            val downloadMessage = ameliaOutboundMessage!!.downloadMessage
            if (isAdded && downloadMessage.error == null) {
                downloadMessage.download(object : IDownloadListener {

                    override fun onDownloadFailed(error: IAmeliaError) {
                        notifyNewMessage()
                    }

                    override fun onDownloadSuccess(mmo: IDownloadedMmo) {
                        notifyNewMessage()
                    }
                }, context.externalCacheDir)
            }
        }

        override fun onUploadRequest(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            openFileChooser(ameliaOutboundMessage!!.fromUserDisplayName, ameliaOutboundMessage.uploadMessage.resourceToRequest.cmObjectType)
            notifyNewMessage()
        }

        override fun onUploadSuccess(fromUserDisplayName: String?, fileName: String?, url: String?) {
            val lastIndex = chatHistory!!.records.size - 1
            adapter!!.notifyItemChanged(lastIndex)
        }

        override fun onUploadFailed(fromUserDisplayName: String?, fileName: String?, fileType: String?) {

        }

        override fun outboundBpnExecutionEventMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
            val event = ameliaOutboundMessage!!.attributes.bpnExecutionEvent.bpnProcessEvent
            val eventId = ameliaOutboundMessage.attributes.bpnExecutionEvent.eventId
            if (event == BpnExecutionEvent.BpnProcessEvent.PROCESS_ABORTED_EVENT) {
                ALog.d("amelia", "BPN with process eventID $eventId crashed")
            }
        }
    }

    private fun startSpeechListener() {
        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, domain!!.localeLanguageTag)

        speechRecognizer!!.startListening(recognizerIntent)
    }

    private fun ensureMicrophonePermission(): Boolean {
        val hasPermission = ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) return true

        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),
                MIC_PERMISSON_REQUEST_CODE)
        return false
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        if (requestCode == MIC_PERMISSON_REQUEST_CODE) {
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startSpeechListener()
            } else {
                // We were not granted microphone permission.
            }
        } else if (requestCode == WRITE_EXTERNAL_STORAGE_PERMISSION) {
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (extStorageWritePermissionListener != null) {
                    extStorageWritePermissionListener!!.onPermissionGranted()
                }
            } else {
                if (extStorageWritePermissionListener != null) {
                    extStorageWritePermissionListener!!.onPermissionDenied()
                }
            }
            return
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = activity.application as AmeliaApplication
        ameliaChat = app.ameliaChat
        chatHistory = app.chatHistory
        domain = arguments.getParcelable(ChatActivity.DOMAIN)
        retainInstance = true
    }

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater!!.inflate(R.layout.fragment_chat, container, false)
        val context = view.context
        recyclerView = view.findViewById(R.id.list) as RecyclerView
        val linearLayoutManager = LinearLayoutManager(context)
        linearLayoutManager.stackFromEnd = true
        recyclerView!!.layoutManager = linearLayoutManager
        adapter = ChatRecyclerViewAdapter(chatHistory!!, object : ChatRecyclerViewAdapter.FormSubmitListener {
            override fun onFormSubmitted(form: FormInputData, message: String) {
                ameliaChat!!.submitForm(form, message)
            }
        }, this)
        recentlyLoadedChatIndex = chatHistory!!.records.size - 1
        recyclerView!!.adapter = adapter

        swipeToRefresh = view.findViewById(R.id.swipe_to_refresh) as SwipeRefreshLayout
        val isRefreshing = chatHistory!!.records.isEmpty()
        swipeToRefresh!!.isRefreshing = isRefreshing
        swipeToRefresh!!.isEnabled = isRefreshing

        inputField = view.findViewById(R.id.input_field) as EditText
        inputField!!.setOnEditorActionListener(TextView.OnEditorActionListener { textView, id, keyEvent ->
            if (id == EditorInfo.IME_ACTION_SEND && sendButton!!.isEnabled) {
                submit()
                return@OnEditorActionListener true
            }
            false
        })

        speechButton = view.findViewById(R.id.speech_button)
        if (SpeechRecognizer.isRecognitionAvailable(getContext())) {
            speechButton!!.isEnabled = ameliaChat!!.isInputEnabled
            speechButton!!.setOnClickListener(speechButtonClickListener)
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(getContext())
            speechRecognizer!!.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle) {
                    Log.d("amelia", "onReadyForSpeech")
                }

                override fun onBeginningOfSpeech() {
                    Log.d("amelia", "onBeginningOfSpeech")
                }

                override fun onRmsChanged(rmsdB: Float) {
                    Log.d("amelia", "onRmsChanged")
                }

                override fun onBufferReceived(buffer: ByteArray) {
                    Log.d("amelia", "onBufferReceived")
                }

                override fun onEndOfSpeech() {
                    Log.d("amelia", "onEndOfSpeech")
                }

                override fun onError(error: Int) {
                    Log.d("amelia", "onError")
                }

                override fun onResults(results: Bundle) {
                    Log.d("amelia", "onResults")

                    var str = ""
                    val data = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (data!!.size > 0) {
                        str = data[0]
                        inputField!!.setText(str)
                        if (sendButton!!.isEnabled) {
                            submit()
                        }
                    }
                    Log.d("amelia", "onResults: [" + data.size + "]" + str)

                }

                override fun onPartialResults(partialResults: Bundle) {
                    var str = ""
                    val data = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (data!!.size > 0) {
                        str = data[0]
                        inputField!!.setText(str)
                    }
                    Log.d("amelia", "onPartialResults: [" + data.size + "]" + str)

                }

                override fun onEvent(eventType: Int, params: Bundle) {
                    Log.d("amelia", "onEvent")
                }
            })
        } else {
            speechButton!!.visibility = View.GONE
        }

        sendButton = view.findViewById(R.id.send_button)
        sendButton!!.isEnabled = ameliaChat!!.isInputEnabled
        sendButton!!.setOnClickListener(sendButtonClickListener)
        sendButton!!.setOnLongClickListener(sendButtonLongClickListener)

        ameliaChat!!.addConversationListener(conversationListener)
        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        ameliaChat!!.removeConversationListener(conversationListener)
        adapter!!.removeFormSubmitListener()
    }

    private fun submit(message: String = inputField!!.text.toString()) {
        ameliaChat!!.say(message)
        inputField!!.setText("")
    }

    private fun notifyNewMessage() {
        swipeToRefresh!!.isRefreshing = false
        swipeToRefresh!!.isEnabled = false
        val lastIndex = chatHistory!!.records.size - 1
        val numItems = lastIndex - recentlyLoadedChatIndex
        adapter!!.notifyItemRangeInserted(recentlyLoadedChatIndex + 1, numItems)
        recentlyLoadedChatIndex = lastIndex
        recyclerView!!.scrollToPosition(lastIndex)
    }

    private fun getMoodIcon(mood: String?): Int {
        when (mood) {
            "NEUTRAL" -> return R.drawable.neutral_smile
            "HAPPY" -> return R.drawable.happy
            "SAD" -> return R.drawable.sad
            "DISGUSTED" -> return R.drawable.disgust
            "CONTEMPT" -> return R.drawable.smirk_left
            "AMUSED" -> return R.drawable.amused
            "ANGRY" -> return R.drawable.anger
            "BEMUSED" -> return R.drawable.bemused
            "CONFUSION" -> return R.drawable.confusion
            "EXCITED" -> return R.drawable.excited
            "FEAR" -> return R.drawable.anger
            "HAPPY_SINCERE" -> return R.drawable.happy_sincere
            "JOY" -> return R.drawable.joy
            "POUT" -> return R.drawable.pout
            "SIMPLE_SMILE" -> return R.drawable.simple_smile
            "SINCERE_SMILE" -> return R.drawable.sincere_smile
            "SMIRK_LEFT" -> return R.drawable.smirk_left
            "SMIRK_RIGHT" -> return R.drawable.smirk_right
            "SURPRISED" -> return R.drawable.joy
            else -> return R.drawable.neutral_smile
        }
    }


    private fun openFileChooser(fromUserDisplayName: String, fileType: String) {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.addCategory(Intent.CATEGORY_DEFAULT)
        intent.type = "*/*"
        val i = Intent.createChooser(intent, fromUserDisplayName + " requested " + fileType)
        startActivityForResult(i, FILE_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            1001 -> if (resultCode == Activity.RESULT_OK && data!=null) {
                ameliaChat!!.uploadFile(data!!.data)
            }else {
                ameliaChat!!.cancleFileUpload();
                Log.d("ChatFragment", "upload canceled");
            }
        }
    }

    override fun requestPermission(listener: ChatRecyclerViewAdapter.PermissionRequestCompletionListener) {
        this.extStorageWritePermissionListener = listener
        if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && ContextCompat.checkSelfPermission(this.activity,
                Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    WRITE_EXTERNAL_STORAGE_PERMISSION)
        } else {
            listener.onPermissionGranted()
        }
    }

    companion object {

        val FILE_REQUEST_CODE = 1001
        private val WRITE_EXTERNAL_STORAGE_PERMISSION = 2001
        private val MIC_PERMISSON_REQUEST_CODE = 2002

        fun newInstance(domain: BaseDomain): ChatFragment {
            val fragment = ChatFragment()
            val args = Bundle()
            args.putParcelable(ChatActivity.DOMAIN, domain)
            fragment.arguments = args
            return fragment
        }
    }
}
