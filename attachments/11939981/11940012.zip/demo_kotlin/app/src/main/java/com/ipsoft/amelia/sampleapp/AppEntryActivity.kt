package com.ipsoft.amelia.sampleapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.v7.app.AppCompatActivity

/**
 * Created by yyang on 9/28/17.
 */

class AppEntryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ssoResult = intent.data
        if (ssoResult != null) {
            val cookie = ssoResult.toString().split("=".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            val intent = Intent(this, SsoLoginActivity::class.java)
            intent.putExtra(AmeliaAppConstants.SSO_COOKIE, if (cookie.size >= 1) cookie[1] else "")
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
        }
        finish()
    }
}
