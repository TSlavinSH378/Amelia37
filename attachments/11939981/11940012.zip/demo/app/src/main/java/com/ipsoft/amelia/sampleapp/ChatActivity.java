package com.ipsoft.amelia.sampleapp;

import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.ipsoft.amelia.sampleapp.accordion.Section;

import net.ipsoft.amelia.sdk.BaseDomain;
import net.ipsoft.amelia.sdk.IAmeliaChat;

public class ChatActivity extends AppCompatActivity implements IntegrationFragment.ActionListener{

    public static final String DOMAIN = "domain";

    private IAmeliaChat ameliaChat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_chat);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        AmeliaApplication app = (AmeliaApplication) getApplication();
        ameliaChat = app.getAmeliaChat();

        BaseDomain domain = getIntent().getParcelableExtra("domain");
        if (savedInstanceState == null) {
            selectDomain(domain);
        }

        ChatFragment chatFragment = ChatFragment.newInstance(domain);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.chat_fragment, chatFragment)
                .commit();

        setVolumeControlStream(AudioManager.STREAM_MUSIC);
    }

    private void selectDomain(BaseDomain domain) {
        ameliaChat.selectDomain(domain);
    }

    @Override
    protected void onStart() {
        super.onStart();
        invalidateOptionsMenu();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (ameliaChat.getUser() != null && !ameliaChat.getUser().isAnonymous()) {
            getMenuInflater().inflate(R.menu.menu_logout, menu);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        if (hideIntegrationFragment()) return;
        super.onBackPressed();
        ameliaChat.endConversation();
    }

    private boolean hideIntegrationFragment() {
        final Fragment integrationFragment = getSupportFragmentManager().findFragmentByTag("TAG-INTEGRATION-FRAGMENT");
        if (integrationFragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.fade_out)
                    .remove(integrationFragment)
                    .commit();


            getSupportActionBar().setTitle(R.string.app_name);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            return true;
        }
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                ameliaChat.endConversation();
                return false;
            case R.id.action_logout:
                ameliaChat.logout();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                return true;
        }
        return false;
    }

    public void showIntegration(Section section) {
        final IntegrationFragment integrationFragment = new IntegrationFragment();
        integrationFragment.setSection(section);

        getSupportActionBar().setTitle(section.getTitle());
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);

        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.fade_out)
                .add(R.id.fragment_container, integrationFragment, "TAG-INTEGRATION-FRAGMENT")
                .commit();
        findViewById(R.id.fragment_container).setVisibility(View.VISIBLE);
    }

    @Override
    public void onAction(String processName, String processArgs, String utterance) {
        ameliaChat.runAction(processName, processArgs, utterance);
        hideIntegrationFragment();
    }
}
