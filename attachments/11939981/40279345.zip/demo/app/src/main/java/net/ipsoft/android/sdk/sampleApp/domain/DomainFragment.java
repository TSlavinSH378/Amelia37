package net.ipsoft.android.sdk.sampleApp.domain;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import net.ipsoft.android.sdk.sampleApp.AmeliaApplication;
import net.ipsoft.android.sdk.sampleApp.R;
import net.ipsoft.android.sdk.sampleApp.login.LoginActivity;
import net.ipsoft.android.sdk.sampleApp.Utils;
import net.ipsoft.android.sdk.sampleApp.chat.ChatActivity;

import net.ipsoft.amelia.sdk.BaseDomain;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.IAmeliaUser;

import java.util.ArrayList;
import java.util.List;

import static net.ipsoft.android.sdk.sampleApp.domain.DomainActivity.START_CHAT_REQUEST;

public class DomainFragment extends Fragment implements DomainRecyclerViewAdapter.OnListFragmentInteractionListener {

    private net.ipsoft.android.sdk.sampleApp.domain.DomainRecyclerViewAdapter userDomainAdapter;
    private net.ipsoft.android.sdk.sampleApp.domain.DomainRecyclerViewAdapter guestDomainAdapter;
    private IAmeliaChat ameliaChat;
    private AmeliaApplication app;
    private IAmeliaUser user;


    private void storeDomainCount(List<BaseDomain> domains) {
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(getContext());
        SharedPreferences.Editor editor = pref.edit();
        editor.putInt("key_domain_count", domains.size());
        editor.commit();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_domain, container, false);
        Context context = view.getContext();
        RecyclerView userDomainListView = (RecyclerView) view.findViewById(R.id.userList);
        RecyclerView guestDomainListView = (RecyclerView) view.findViewById(R.id.guestList);
        LinearLayout guestLayout = (LinearLayout) view.findViewById(R.id.guestLayout);
        LinearLayout userLayout = (LinearLayout) view.findViewById(R.id.userLayout);
        TextView tvWelcome = (TextView) view.findViewById(R.id.tvWelcome);
        TextView tvDomainCount = (TextView) view.findViewById(R.id.tvDomainCount);
        TextView tvLogout = (TextView) view.findViewById(R.id.tvLogout);
        userDomainListView.setLayoutManager(new LinearLayoutManager(context));
        guestDomainListView.setLayoutManager(new LinearLayoutManager(context));
        Intent intent = getActivity().getIntent();
        List<BaseDomain> domainList = intent.getParcelableArrayListExtra("domains");
        List<BaseDomain> userDomainList = new ArrayList<>();
        List<BaseDomain> anonymousDomainList = new ArrayList<>();
        for(BaseDomain domain:domainList){
            if(domain.getRequireLogin()){
                userDomainList.add(domain);
            }else{
                anonymousDomainList.add(domain);
            }
        }
        //user
        if(userDomainList.size()>0) {
            userLayout.setVisibility(View.VISIBLE);
            ViewGroup.LayoutParams params = userDomainListView.getLayoutParams();
            params.height = Utils.getPixelFromDp(AmeliaApplication.getAppContext(), (userDomainList.size()) * 88);
            userDomainListView.setLayoutParams(params);
            userDomainAdapter = new DomainRecyclerViewAdapter(userDomainList, this);
            userDomainListView.setAdapter(userDomainAdapter);
        }else{
            userLayout.setVisibility(View.GONE);
        }
        //guest
        if(anonymousDomainList.size()>0) {
            guestLayout.setVisibility(View.VISIBLE);
            ViewGroup.LayoutParams params = guestDomainListView.getLayoutParams();
            params.height = Utils.getPixelFromDp(AmeliaApplication.getAppContext(), (anonymousDomainList.size()) * 88);
            guestDomainListView.setLayoutParams(params);
            guestDomainAdapter = new DomainRecyclerViewAdapter(anonymousDomainList, this);
            guestDomainListView.setAdapter(guestDomainAdapter);
        }else{
            guestLayout.setVisibility(View.GONE);
        }
        AmeliaApplication app = (AmeliaApplication)this.getActivity().getApplication();
        ameliaChat = app.getAmeliaChat();
        user = ameliaChat.getUser();
        if(user!=null){
            tvWelcome.setText(getString(R.string.greeting_to_user,user.getName()));
        }
        if(domainList.size()>0){
            tvDomainCount.setText(Html.fromHtml("You have access to <b>"+domainList.size()+"</b> domains."));
        }
        tvLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ameliaChat.logout();
                DomainFragment.this.getActivity().onBackPressed();
                Intent intent = new Intent(DomainFragment.this.getActivity(), LoginActivity.class);
                startActivity(intent);
            }
        });
        return view;
    }

    @Override
    public void onListFragmentInteraction(BaseDomain domain) {
        Intent intent = new Intent(this.getActivity(), ChatActivity.class);
        intent.putExtra(ChatActivity.DOMAIN, domain);
        if(user!=null) {
            intent.putExtra(ChatActivity.USER, user.getName());
        }
        startActivityForResult(intent, START_CHAT_REQUEST);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    @Override
    public void onStart() {
        super.onStart();
        getActivity().supportInvalidateOptionsMenu();
    }

}