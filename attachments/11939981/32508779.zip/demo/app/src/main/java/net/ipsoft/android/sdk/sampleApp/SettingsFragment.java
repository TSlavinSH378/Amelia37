package net.ipsoft.android.sdk.sampleApp;

import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.preference.CheckBoxPreference;
import android.support.v7.preference.Preference;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.support.v7.preference.PreferenceScreen;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.webkit.URLUtil;
import android.widget.Toast;

import java.util.Set;

public class SettingsFragment extends PreferenceFragmentCompat {
    private static final String PREF_KEY_QA_MODE = "pref_key_qa_mode";
    SharedPreferences.OnSharedPreferenceChangeListener listener =
            new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override
                public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                    if(key.equals(getString(R.string.key_base_url))){//roll back to default server url if entered mal-formatted url
                        String baseUrl = sharedPreferences.getString(key,"");
                        if(!Patterns.WEB_URL.matcher(baseUrl).matches()) {
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString(key, getString(R.string.base_url));
                            editor.commit();
                        }
                    }
                    AmeliaApplication app = (AmeliaApplication) getActivity().getApplication();
                    if(app.getAmeliaChat()!=null) {
                        app.getAmeliaChat().logout();
                    }
                }
            };
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        addPreferencesFromResource(R.xml.preferences);
        Preference versionPreference = getPreferenceScreen().findPreference(getResources().getString(
                R.string.key_app_version));
        try {
            PackageInfo pInfo = getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0);
            String version = pInfo.versionName;
            versionPreference.setSummary(version);
        }catch (PackageManager.NameNotFoundException ignore){}
        boolean qaMode = Utils.getBooleanPref(PREF_KEY_QA_MODE);
        if(qaMode){
            addDisableSSOPreference();
        }else {
            versionPreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                int count = 0;

                @Override
                public boolean onPreferenceClick(Preference preference) {

                    count++;
                    if (count > 2) {
                        if (count < 7) {
                            Toast toast = Toast.makeText(SettingsFragment.this.getContext(), "You are " + (7 - count) + " steps from being a QA Engineer", Toast.LENGTH_SHORT);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        } else if (count == 7) {
                            Toast toast = Toast.makeText(SettingsFragment.this.getContext(), "You are now a QA Engineer", Toast.LENGTH_SHORT);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            addDisableSSOPreference();
                            Utils.saveBooleanPref(PREF_KEY_QA_MODE, true);
                        }
                    }
                    return true;
                }
            });
        }
    }
    private void addDisableSSOPreference(){
        PreferenceScreen preferenceScreen = SettingsFragment.this.getPreferenceScreen();
        TypedValue themeTypedValue = new TypedValue();
        SettingsFragment.this.getActivity().getTheme().resolveAttribute(R.attr.preferenceTheme, themeTypedValue, true);
        ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(SettingsFragment.this.getActivity(), themeTypedValue.resourceId);

        CheckBoxPreference disableSSO = new CheckBoxPreference(contextThemeWrapper);
        disableSSO.setSummary("Check to disable SSO");
        disableSSO.setTitle("Disable SSO");
        disableSSO.setKey(getString(R.string.key_disable_SSO));
        disableSSO.setPersistent(true);
        preferenceScreen.addPreference(disableSSO);
    }
    @Override
    public void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences()
                .registerOnSharedPreferenceChangeListener(listener);
    }

    @Override
    public void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences()
                .unregisterOnSharedPreferenceChangeListener(listener);
    }
}
