package net.ipsoft.android.sdk.sampleApp.chat;

import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import net.ipsoft.android.sdk.sampleApp.AmeliaApplication;
import net.ipsoft.android.sdk.sampleApp.IntegrationFragment;
import net.ipsoft.android.sdk.sampleApp.R;
import net.ipsoft.android.sdk.sampleApp.Utils;
import net.ipsoft.android.sdk.sampleApp.accordion.Section;
import net.ipsoft.android.sdk.sampleApp.chat.menu.MenuListAdapter;
import net.ipsoft.android.sdk.sampleApp.login.LoginActivity;

import net.ipsoft.amelia.sdk.BaseDomain;
import net.ipsoft.amelia.sdk.BaseSessionListener;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.BaseConversation;

import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity implements IntegrationFragment.ActionListener,MenuListAdapter.OnMenuListItemClickListener {

    public static final String DOMAIN = "domain";
    public static final String CONVERSATION = "conversation";
    public static final String USER = "user";
    private ChatFragment chatFragment;
    private IAmeliaChat ameliaChat;

    private DrawerLayout mDrawerLayout;
    private FrameLayout chatLayout;
    private LinearLayout navigationLayoutLeft;
    private LinearLayout navigationHeaderLayoutLeft;
    private LinearLayout navigationLayoutRight;
    private TextView tvUserName;
    private ListView menuList;
    private ListView chatNotesList;
    private MenuListAdapter menuListAdapter;
    private BaseConversation conversation;
    private BaseDomain domain;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        final Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.hamburger);
        getSupportActionBar().setDisplayUseLogoEnabled(false);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        chatLayout = (FrameLayout)findViewById(R.id.chat_fragment);
        AmeliaApplication app = (AmeliaApplication) getApplication();
        ameliaChat = app.getAmeliaChat();

        ameliaChat.addSessionListener(new BaseSessionListener(){
            public void onConversationStart(BaseConversation conversation) {
                ChatActivity.this.conversation = conversation;
                if(chatFragment!=null) {
                    getSupportFragmentManager().beginTransaction().remove(chatFragment).commit();
                }
                chatFragment = ChatFragment.newInstance(conversation,domain);
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.chat_fragment, chatFragment)
                        .commit();
            }
        });
        String userName = getIntent().getStringExtra(USER);
        final BaseConversation startedConversation = getIntent().getParcelableExtra(CONVERSATION);
        if(startedConversation==null){
            domain = getIntent().getParcelableExtra(DOMAIN);
            if (savedInstanceState == null) {
                selectDomain(domain);
            }
        }else{
            this.conversation = startedConversation;
            domain = conversation.getInitialDomain();
            chatFragment = ChatFragment.newInstance(startedConversation,domain);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.chat_fragment, chatFragment)
                    .commit();

        }

        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        setResult(RESULT_OK);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerLayout.setScrimColor(Color.TRANSPARENT);
        navigationLayoutLeft = (LinearLayout)findViewById(R.id.nav_view);
        navigationLayoutRight = (LinearLayout)findViewById(R.id.nav_view_right);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close) {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);
                float slideX = drawerView.getWidth() * slideOffset;
                float alpha = (float) (Math.max(1.0 - slideOffset, 0.2));
                boolean left = drawerView.equals(navigationLayoutLeft);
                chatLayout.setTranslationX(left?slideX:-slideX);
                chatLayout.setAlpha(alpha);
                toolbar.setTranslationX(left?slideX:-slideX);
                toolbar.setAlpha(alpha);
            }
        };
        mDrawerLayout.addDrawerListener(actionBarDrawerToggle);

        ViewGroup.LayoutParams params = navigationLayoutLeft.getLayoutParams();
        params.width = (int)(0.82 * Utils.getScreenWidth());
        params = navigationLayoutRight.getLayoutParams();
        params.width = (int) (0.82 * Utils.getScreenWidth());

        //menu header
        navigationHeaderLayoutLeft = (LinearLayout)findViewById(R.id.menuHeaderLayout);
        tvUserName = (TextView)findViewById(R.id.tvUserName);
        if(userName!=null){
            navigationHeaderLayoutLeft.setVisibility(View.VISIBLE);
            tvUserName.setText(userName);
        }else{
            navigationHeaderLayoutLeft.setVisibility(View.GONE);
        }
        //menu listview
        menuList = (ListView)findViewById(R.id.menuList);
        menuListAdapter = new MenuListAdapter(this,userName==null);
        menuList.setAdapter(menuListAdapter);
        menuList.bringToFront();
        mDrawerLayout.requestLayout();
        //chatnotes list
        chatNotesList = (ListView)findViewById(R.id.chatNoteList);
        chatNotesList.setEmptyView(findViewById(android.R.id.empty));
    }

    private void selectDomain(BaseDomain domain) {
        ameliaChat.selectDomain(domain);
    }

    @Override
    protected void onStart() {
        super.onStart();
        invalidateOptionsMenu();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (ameliaChat.getUser() != null && !ameliaChat.getUser().isAnonymous()) {
            getMenuInflater().inflate(R.menu.menu_logout, menu);
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        if (hideIntegrationFragment()) return;
        super.onBackPressed();
        ameliaChat.stopPlayAudio(conversation);
        ameliaChat.endConversation(conversation);
    }

    private boolean hideIntegrationFragment() {
        final Fragment integrationFragment = getSupportFragmentManager().findFragmentByTag("TAG-INTEGRATION-FRAGMENT");
        if (integrationFragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.fade_out)
                    .remove(integrationFragment)
                    .commit();


            getSupportActionBar().setTitle(R.string.app_name);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            return true;
        }
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_open_chat_notes:
                mDrawerLayout.openDrawer(Gravity.RIGHT,true);
                return true;
            case android.R.id.home:
                mDrawerLayout.openDrawer(Gravity.LEFT,true);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void showIntegration(Section section) {
        final IntegrationFragment integrationFragment = new IntegrationFragment();
        integrationFragment.setSection(section);

        getSupportActionBar().setTitle(section.getTitle());
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);

        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.fade_out)
                .add(R.id.fragment_container, integrationFragment, "TAG-INTEGRATION-FRAGMENT")
                .commit();
        findViewById(R.id.fragment_container).setVisibility(View.VISIBLE);
    }

    @Override
    public void onAction(String processName, String processArgs, String utterance) {
        ameliaChat.runAction(conversation,processName, processArgs, utterance);
        hideIntegrationFragment();
    }

    @Override
    public void onMenuItemClick(net.ipsoft.android.sdk.sampleApp.chat.menu.MenuItem.MenuItemType itemType) {
        switch (itemType) {
            case RESET_CONVERSATION:
                chatFragment.resetConversation();
                mDrawerLayout.closeDrawer(Gravity.LEFT,true);
                break;
            case LIVE_AGENT:
                chatFragment.escalate();
                mDrawerLayout.closeDrawer(Gravity.LEFT,true);
                break;
            case SELECT_DOMAIN:
                this.onBackPressed();
                break;
            case LOGOUT:
                ameliaChat.logout();
            case LOGIN:
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                this.onBackPressed();
                break;
        }
    }
}
