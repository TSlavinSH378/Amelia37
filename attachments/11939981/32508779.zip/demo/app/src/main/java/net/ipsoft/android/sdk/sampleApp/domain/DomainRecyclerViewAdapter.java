package net.ipsoft.android.sdk.sampleApp.domain;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import net.ipsoft.amelia.sdk.BaseDomain;
import net.ipsoft.android.sdk.sampleApp.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DomainRecyclerViewAdapter extends RecyclerView.Adapter<DomainRecyclerViewAdapter.ViewHolder> {

    private List<BaseDomain> mValues;
    private final OnListFragmentInteractionListener mListener;

    public interface OnListFragmentInteractionListener {
        void onListFragmentInteraction(BaseDomain item);
    }

    public DomainRecyclerViewAdapter(OnListFragmentInteractionListener listener) {
        this(new ArrayList<BaseDomain>(), listener);
    }

    public DomainRecyclerViewAdapter(List<BaseDomain> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;
    }

    public void setValues(List<BaseDomain> items) {
        mValues = items;
        notifyItemRangeChanged(0, getItemCount());
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.domain_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);
        holder.mDomainName.setText(holder.mItem.getName());
        holder.mLanguageTag.setText(holder.mItem.getLocaleDisplayName());
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        String date = dateFormat.format(Calendar.getInstance().getTime());
        holder.mDate.setText(date);

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    mListener.onListFragmentInteraction(holder.mItem);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView mDomainName;
        public final TextView mLanguageTag;
        public final TextView mDate;
        public BaseDomain mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mDomainName = (TextView) view.findViewById(R.id.tvDomainName);
            mLanguageTag = (TextView) view.findViewById(R.id.tvLanguageTag);
            mDate = (TextView) view.findViewById(R.id.tvDate);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mDomainName.getText() + "'";
        }
    }
}
