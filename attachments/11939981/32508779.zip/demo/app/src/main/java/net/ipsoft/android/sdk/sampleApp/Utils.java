package net.ipsoft.android.sdk.sampleApp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import com.shockwave.pdfium.PdfDocument;
import com.shockwave.pdfium.PdfiumCore;

import java.io.File;
import java.io.FileOutputStream;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by yyang on 9/7/17.
 */

public class Utils {
    private static final String SHARED_PREF_NAME = "AMELIA_APP_SHARED_PREFERENCE";
    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static boolean isEmpty(String str){
        return str==null||str.length()==0;
    }

    public static int getPixelFromDp(final Context context, final float dp) {
        return (int)(dp * context.getResources().getDisplayMetrics().density);
    }

    public static Uri getPdfThumbnail(Context context, Uri pdfUri) throws Exception{
        int pageNumber = 0;
        File folder = context.getCacheDir();
        if(!folder.exists())
            folder.mkdirs();
        File pdfFile = new File(pdfUri.getPath());
        File file = new File(folder, pdfFile.getName()+".png");

        PdfiumCore pdfiumCore = new PdfiumCore(context);
        ParcelFileDescriptor fd = context.getContentResolver().openFileDescriptor(pdfUri, "r");
        PdfDocument pdfDocument = pdfiumCore.newDocument(fd);
        pdfiumCore.openPage(pdfDocument, pageNumber);
        int width = pdfiumCore.getPageWidthPoint(pdfDocument, pageNumber);
        int height = pdfiumCore.getPageHeightPoint(pdfDocument, pageNumber);
        double heightWidthRatio = height/width;
        int maxWidth = (int)(getScreenWidth()*0.75);
        width = width>maxWidth?maxWidth:width;
        height = (int)(heightWidthRatio*height);
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_4444);
        pdfiumCore.renderPageBitmap(pdfDocument, bmp, pageNumber, 0, 0, width, height);

        FileOutputStream out = new FileOutputStream(file);
        boolean compressed = bmp.compress(Bitmap.CompressFormat.PNG, 100, out); // bmp is your Bitmap instance
        pdfiumCore.closeDocument(pdfDocument); // important!
        Uri uri = Uri.fromFile(file);
        return uri!=null?uri:null;
    }

    public static void saveBooleanPref(String key,Boolean value){
        SharedPreferences sharedPref = AmeliaApplication.getAppContext().getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(key,value);
        editor.commit();
    }

    public static Boolean getBooleanPref(String key){
        SharedPreferences prefs = AmeliaApplication.getAppContext().getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
        Boolean value = prefs.getBoolean(key, false);
        return value;
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
