package net.ipsoft.android.sdk.sampleApp;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;

import net.ipsoft.amelia.sdk.FormInputData;
import net.ipsoft.amelia.sdk.FormInputField;

import java.util.ArrayList;
import java.util.Collections;

public class FormView extends LinearLayout {

    private FormSubmittedListener mFormSubmitListener;

    public FormView(Context context) {
        super(context);
        if (isInEditMode()) {
            initWithDummyForm();
        }
    }

    public FormView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        if (isInEditMode()) {
            initWithDummyForm();
        }
    }

    public FormView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        if (isInEditMode()) {
            initWithDummyForm();
        }
    }

    public void setFormInputData(FormInputData form) {
        initWithForm(form);
    }

    public void setFormSubmitListener(FormSubmittedListener listener) {
        mFormSubmitListener = listener;
    }

    private void initWithDummyForm() {
        FormInputData form = new FormInputData();
        form.setName("Sample form");

        form.setFields(new ArrayList<>(Collections.singletonList(FormFieldView.DUMMY_FIELD)));
        initWithForm(form);
    }

    private void initWithForm(final FormInputData form) {

        removeAllViews();

        setOrientation(LinearLayout.VERTICAL);

        final Context containerContext = getContext();
        TextView title = new TextView(containerContext);
        title.setText(form.getNameForDisplay());
        addView(title);

        for (final FormInputField formInputField : form.getFields()) {

            FormFieldView fieldView = new FormFieldView(containerContext);
            fieldView.setFormField(formInputField);
            addView(fieldView);

            final int marginPx = containerContext.getResources().getDimensionPixelOffset(R.dimen.margin);
            final int marginSmallPx = containerContext.getResources().getDimensionPixelOffset(R.dimen.margin_small);
            ((LinearLayout.LayoutParams) fieldView.getLayoutParams()).setMargins(marginPx, marginSmallPx, 0, marginSmallPx);
            fieldView.getLayoutParams().width = LayoutParams.MATCH_PARENT;

            fieldView.setFieldSubmittedListener(new FormFieldView.FieldSubmittedListener() {
                @Override
                public void onFieldSubmitted(String value) {
                    if (mFormSubmitListener != null) {
                        mFormSubmitListener.onFormSubmitted(value);
                    }
                }
            });
        }
    }

    public interface FormSubmittedListener {
        void onFormSubmitted(String value);
    }
}
