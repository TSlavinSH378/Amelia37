package com.ipsoft.amelia.sampleapp

import android.content.SharedPreferences
import android.os.Bundle
import android.support.v7.preference.PreferenceFragmentCompat

class SettingsFragment : PreferenceFragmentCompat() {
    internal var listener: SharedPreferences.OnSharedPreferenceChangeListener = SharedPreferences.OnSharedPreferenceChangeListener { sharedPreferences, key ->
        if (key == getString(R.string.key_allow_anonymous)) {
            val anonymous = sharedPreferences.getBoolean(key, false)
            if (anonymous) {
                sharedPreferences.edit().putBoolean(getString(R.string.key_saml_login_enabled), false).commit()
                preferenceScreen = null
                addPreferencesFromResource(R.xml.preferences)
            }
        } else if (key == getString(R.string.key_saml_login_enabled)) {
            val saml = sharedPreferences.getBoolean(key, false)
            if (saml) {
                sharedPreferences.edit().putBoolean(getString(R.string.key_allow_anonymous), false).commit()
                preferenceScreen = null
                addPreferencesFromResource(R.xml.preferences)
            }
        }
    }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        addPreferencesFromResource(R.xml.preferences)
    }

    override fun onResume() {
        super.onResume()
        preferenceScreen.sharedPreferences
                .registerOnSharedPreferenceChangeListener(listener)
    }

    override fun onPause() {
        super.onPause()
        preferenceScreen.sharedPreferences
                .unregisterOnSharedPreferenceChangeListener(listener)
    }
}
