package com.ipsoft.amelia.sampleapp;
import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.support.customtabs.CustomTabsClient;
import android.support.customtabs.CustomTabsServiceConnection;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.net.Uri;
import android.support.customtabs.CustomTabsIntent;
import android.support.customtabs.CustomTabsSession;

/**
 * new SSO feature (with Chrome tab and mobile redirect mod) is tested against blackrock-amelia-dev
 */
public class SsoLoginActivity extends AppCompatActivity {
    public static final String EXTRA_LOGIN_URL = "login_url";
    protected WebView webView;
    final String CUSTOM_TAB_PACKAGE_NAME = "com.android.chrome";
    CustomTabsClient mCustomTabsClient;
    CustomTabsSession mCustomTabsSession;
    CustomTabsServiceConnection mCustomTabsServiceConnection;
    CustomTabsIntent mCustomTabsIntent;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sso_login);
        webView = (WebView) findViewById(R.id.web_view);
        String url = getIntent().getStringExtra(EXTRA_LOGIN_URL);
        mCustomTabsServiceConnection = new CustomTabsServiceConnection() {
            @Override
            public void onCustomTabsServiceConnected(ComponentName componentName, CustomTabsClient customTabsClient) {
                mCustomTabsClient= customTabsClient;
                mCustomTabsClient.warmup(0L);
                mCustomTabsSession = mCustomTabsClient.newSession(null);
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                mCustomTabsClient= null;
            }
        };

        CustomTabsClient.bindCustomTabsService(this, CUSTOM_TAB_PACKAGE_NAME, mCustomTabsServiceConnection);

        mCustomTabsIntent = new CustomTabsIntent.Builder(mCustomTabsSession)
                .setShowTitle(true)
                .build();
        mCustomTabsIntent.launchUrl(this, Uri.parse(url));
    }

    @Override
    protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        String ssoResult = intent.getStringExtra(AmeliaAppConstants.SSO_COOKIE);
        String url = getIntent().getStringExtra(EXTRA_LOGIN_URL);
        if(!Utils.isEmpty(ssoResult)){
            Intent resultIntent = new Intent();
            resultIntent.putExtra(AmeliaAppConstants.SSO_COOKIE,ssoResult);
            SsoLoginActivity.this.setResult(RESULT_OK,resultIntent);
            SsoLoginActivity.this.finish();
        }else if(!Utils.isEmpty(url)){
            mCustomTabsIntent.launchUrl(this, Uri.parse(url));
        }
        else{
            SsoLoginActivity.this.setResult(RESULT_CANCELED);
            SsoLoginActivity.this.finish();
        }
    }

    @Override
    protected void onDestroy(){
        unbindService(mCustomTabsServiceConnection);
        super.onDestroy();
    }

}
