package net.ipsoft.android.sdk.sampleApp.login;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import net.ipsoft.android.sdk.sampleApp.AmeliaAppConstants;

/**
 * Created by yyang on 9/28/17.
 */

public class AppEntryActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Uri ssoResult = getIntent().getData();
        if(ssoResult!=null){
            String ssoStr = ssoResult.toString();
            int index = ssoStr.indexOf('=');
            String cookie = ssoStr.substring(index+1,ssoStr.length());
            Intent intent = new Intent(this,SsoLoginActivity.class);
            intent.putExtra(AmeliaAppConstants.SSO_COOKIE,cookie.length()>=1?cookie:"");
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            if (android.os.Build.VERSION.SDK_INT <= Build.VERSION_CODES.M){
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            startActivity(intent);
        }
        finish();
    }

}
