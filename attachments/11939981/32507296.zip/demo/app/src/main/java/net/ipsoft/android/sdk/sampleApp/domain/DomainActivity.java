package net.ipsoft.android.sdk.sampleApp.domain;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;

import net.ipsoft.android.sdk.sampleApp.R;

import net.ipsoft.amelia.sdk.BaseDomain;

import java.util.List;

public class DomainActivity extends AppCompatActivity  {

    public static final int START_CHAT_REQUEST = 1;
    String callingFrom = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_domain);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == START_CHAT_REQUEST) {
            callingFrom = "chatView";

        }
    }
}
