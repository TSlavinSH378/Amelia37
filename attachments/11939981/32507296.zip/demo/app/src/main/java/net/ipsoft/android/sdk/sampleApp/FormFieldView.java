package net.ipsoft.android.sdk.sampleApp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import net.ipsoft.amelia.sdk.FormInputField;
import net.ipsoft.amelia.sdk.FormInputFieldOptions;

import java.util.ArrayList;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;


public class FormFieldView extends LinearLayout {
    public static final String FIELD_TYPE_MULTIPLE_SELECTION = "multipleSelection";

    private FieldSubmittedListener submitListener;
    public static final FormInputField DUMMY_FIELD = new FormInputField();

    static {
        DUMMY_FIELD.setName("Sample field");
        DUMMY_FIELD.setFieldType(FIELD_TYPE_MULTIPLE_SELECTION);
        ArrayList<FormInputFieldOptions> options = new ArrayList<>(2);
        final FormInputFieldOptions opt1 = new FormInputFieldOptions();
        opt1.setName("Choice 1");
        options.add(opt1);
        final FormInputFieldOptions opt2 = new FormInputFieldOptions();
        opt2.setName("Choice 2");
        options.add(opt2);
        DUMMY_FIELD.setOptions(options);
    }

    public FormFieldView(Context context) {
        super(context);
        if (isInEditMode()) {
            init(DUMMY_FIELD);
        }
    }

    public FormFieldView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        if (isInEditMode()) {
            init(DUMMY_FIELD);
        }
    }

    public FormFieldView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        if (isInEditMode()) {
            init(DUMMY_FIELD);
        }
    }

    public void setFormField(FormInputField formField) {
        init(formField);
    }
    public void setFieldSubmittedListener(@Nullable FieldSubmittedListener listener) {
        this.submitListener = listener;
    }

    private void init(final FormInputField formField) {
        setOrientation(LinearLayout.VERTICAL);

        setBackgroundResource(R.drawable.chat_bubble_amelia);

        final boolean isMultiSelect = FIELD_TYPE_MULTIPLE_SELECTION.equals(formField.getFieldType());

        for (final FormInputFieldOptions options : formField.getOptions()) {

            final TextView opt = new Button(new ContextThemeWrapper(getContext(), R.style.AppTheme_FormButton), null, 0);
            opt.setText(options.getName());
            addView(opt);
            opt.getLayoutParams().width = MATCH_PARENT;
            opt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    options.setSelected(!options.getSelected());
                    opt.setSelected(options.getSelected());

                    if (submitListener != null && !isMultiSelect) {
                        submitListener.onFieldSubmitted(options.getName());
                    }
                }
            });
        }

        // If it is multiple selection we need a submit button
        if (isMultiSelect) {
            final TextView submitBtn = new Button(new ContextThemeWrapper(getContext(), R.style.AppTheme_FormButton), null, 0);
            submitBtn.setText(R.string.action_submit);

            submitBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (submitListener != null) {
                        submitListener.onFieldSubmitted(getMultipleSelectionString(formField));
                    }
                }
            });
            addView(submitBtn);
        }

        // No options so let's just use the field as a simple button
        if (formField.getOptions().isEmpty()) {
            final TextView name = new Button(new ContextThemeWrapper(getContext(),  R.style.AppTheme_FormButton), null, 0);
            name.setText(formField.getName());
            addView(name);
            name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (submitListener != null) {
                        submitListener.onFieldSubmitted(formField.getName());
                    }
                }
            });
        }
    }

    @NonNull
    private String getMultipleSelectionString(final FormInputField formField) {
        StringBuilder selections = new StringBuilder();
        boolean isFirst = true;

        for (FormInputFieldOptions formInputFieldOptions : formField.getOptions()) {
            if (formInputFieldOptions.getSelected()) {
                if (!isFirst) {
                    selections.append(", ");
                }
                isFirst = false;
                selections.append(formInputFieldOptions.getName());
            }
        }

        if (selections.length() == 0) {
            selections.append(getContext().getString(R.string.none));
        }

        return selections.toString();
    }

    interface FieldSubmittedListener {
        void onFieldSubmitted(String value);
    }
}
