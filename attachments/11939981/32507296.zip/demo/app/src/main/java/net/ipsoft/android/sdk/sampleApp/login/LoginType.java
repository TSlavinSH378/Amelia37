package net.ipsoft.android.sdk.sampleApp.login;

/**
 * Created by yyang on 2/5/18.
 */

public enum LoginType {
    LOGIN_TYPE_AUTH,
    LOGIN_TYPE_ANONYMOUS
}
