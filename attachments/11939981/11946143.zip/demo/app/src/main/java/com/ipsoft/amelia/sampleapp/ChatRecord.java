package com.ipsoft.amelia.sampleapp;

import android.content.Context;

import net.ipsoft.amelia.sdk.FormInputData;
import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage;

/**
 * Immutable record of interaction between the app and Amelia
 */
public class ChatRecord {

    /**
     * <code>true</code> when the message comes from the app, <code>false</code> if it came from
     * Amelia
     */
    public final boolean isSelf;

    /**
     * A UI friendly display name
     */
    public String userDisplayName;

    /**
     * The spoken message
     */
    public final String messageText;

    /**
     * Amelia's mood
     */
    public final String mood;

    /**
     * Any form supplied in the message represented by this ChatRecord
     */
    public final FormInputData form;

    /**
     * Any BPN JSON formatted integration data supplied in the message represented by this ChatRecord
     */
    public final String integration;


    /**
     * indicates if the user input needs to be secured
     */
    public final boolean shouldSecureInput;

    public boolean isAgent;

    public final String messageType;

    public enum SpecialMessageType {
        MESSAGE_TYPE_THINKING_BUBBLE,
        MESSAGE_TYPE_AVATAR
    }

    /**
     * @param message
     */
    public ChatRecord(IAmeliaOutboundMessage message) {
        this.isSelf = message.isSelfEcho();
        this.userDisplayName = message.getFromUserDisplayName();
        this.messageText = message.getMessageText();
        this.mood = message.getMood();
        this.messageType = message.getMessageType();

        form = message.getFormInputData();
        integration = message.getIntegrationMessageData();
        shouldSecureInput = message.shouldSecureInput();

    }

    //thinking bubble
    public ChatRecord(Context context, SpecialMessageType type) {
        if (type == SpecialMessageType.MESSAGE_TYPE_THINKING_BUBBLE) {
            this.messageType = context.getString(R.string.message_type_thinking_bubble);
        } else if (type == SpecialMessageType.MESSAGE_TYPE_AVATAR) {
            this.messageType = context.getString(R.string.message_type_avatar);
        } else {
            this.messageType = context.getString(R.string.message_type_thinking_bubble);
        }
        isSelf = false;
        userDisplayName = null;
        messageText = null;
        mood = null;
        form = null;
        integration = null;
        shouldSecureInput = false;
    }

    public void setIsAgent(boolean isAgent) {
        this.isAgent = isAgent;
    }

    public void setUserDisplayName(String userName) {
        this.userDisplayName = userName;
    }

}
