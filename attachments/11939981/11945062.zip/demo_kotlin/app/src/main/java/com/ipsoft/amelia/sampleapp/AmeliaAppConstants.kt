package com.ipsoft.amelia.sampleapp

/**
 * Created by yyang on 9/28/17.
 */

object AmeliaAppConstants {
    val SSO_COOKIE = "sso_cookie"

}
