package net.ipsoft.android.sdk.sampleApp.accordion;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import net.ipsoft.android.sdk.sampleApp.IntegrationFragment;
import net.ipsoft.android.sdk.sampleApp.R;


public class SectionView extends LinearLayout {

    private IntegrationFragment.ActionListener actionListener;

    public SectionView(Context context) {
        super(context);
    }

    public SectionView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public SectionView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setActionListener(IntegrationFragment.ActionListener listener) {
        actionListener = listener;
    }

    public void setSection(Section section) {
        initWithSection(section);
    }

    private void initWithSection(final Section section) {
        inflate(getContext(), R.layout.integration_section, this);

        final TextView title = (TextView) findViewById(R.id.section_title);
        if ("AccordionSection".equals(section.sectionType)) {
            title.setVisibility(GONE);
        } else {
            title.setVisibility(VISIBLE);
            title.setText(section.getTitle());
        }

        final ImageView imageView = (ImageView) findViewById(R.id.section_image);
        if (!TextUtils.isEmpty(section.getImageBase64())) {
            imageView.setVisibility(VISIBLE);
            final int dataOffset = section.getImageBase64().indexOf(',');
            if (dataOffset >= 0) {
                final String actualData = section.getImageBase64().substring(dataOffset);
                final byte[] imgData = Base64.decode(actualData, Base64.DEFAULT);
                final Bitmap bitmap = BitmapFactory.decodeByteArray(imgData, 0, imgData.length);
                imageView.setImageBitmap(bitmap);
            } else {
                imageView.setVisibility(GONE);
            }
        } else {
            imageView.setVisibility(GONE);
        }

        final ViewGroup fieldsContainer = (ViewGroup) findViewById(R.id.fields);
        fieldsContainer.removeAllViews();
        for (SectionField sectionField : section.getSectionFields()) {
            final View field = inflate(getContext(), R.layout.integration_layout_field, null);
            ((TextView) field.findViewById(R.id.label)).setText(sectionField.getLabel());
            ((TextView) field.findViewById(R.id.value)).setText(sectionField.getValue());
            fieldsContainer.addView(field);
        }

        final ViewGroup childContainer = (ViewGroup) findViewById(R.id.children);
        childContainer.removeAllViews();
        for (Section childSection : section.getChildren()) {
            final SectionView childSectionView = new SectionView(getContext());
            childSectionView.setActionListener(actionListener);
            childSectionView.setSection(childSection);
            childContainer.addView(childSectionView);
        }

        final Button actionBtn = (Button) findViewById(R.id.section_action_btn);
        if (!TextUtils.isEmpty(section.getActionLabel())) {
            actionBtn.setVisibility(VISIBLE);
            actionBtn.setText(section.getActionLabel());
            actionBtn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    actionListener.onAction(section.getActionProcessName(), section.getActionProcessArgs(), section.selectionUtterance);
                }
            });
        } else {
            actionBtn.setVisibility(GONE);
        }
    }
}
