package net.ipsoft.android.sdk.sampleApp.chat.menu;

import lombok.AllArgsConstructor;

@lombok.Getter
@AllArgsConstructor
public class MenuItem {
    private int iconDrawableId;
    private String menuText;
    private MenuItemType type;

    public enum MenuItemType{
        RESET_CONVERSATION,SELECT_DOMAIN,LIVE_AGENT,LOGIN,LOGOUT
    }

}
