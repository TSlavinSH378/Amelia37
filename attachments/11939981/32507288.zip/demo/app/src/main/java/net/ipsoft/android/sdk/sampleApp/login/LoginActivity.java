package net.ipsoft.android.sdk.sampleApp.login;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import net.ipsoft.android.sdk.sampleApp.AmeliaAppConstants;
import net.ipsoft.android.sdk.sampleApp.AmeliaApplication;
import net.ipsoft.android.sdk.sampleApp.PolicyActivity;
import net.ipsoft.android.sdk.sampleApp.R;
import net.ipsoft.android.sdk.sampleApp.SettingsActivity;
import net.ipsoft.android.sdk.sampleApp.Utils;
import net.ipsoft.android.sdk.sampleApp.chat.ChatActivity;
import net.ipsoft.android.sdk.sampleApp.domain.DomainActivity;
import net.ipsoft.android.sdk.sampleApp.domain.DomainRecyclerViewAdapter;

import net.ipsoft.amelia.sdk.BaseAuthSystem;
import net.ipsoft.amelia.sdk.BaseDomain;
import net.ipsoft.amelia.sdk.BaseSessionListener;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.IAmeliaError;
import net.ipsoft.amelia.sdk.IAmeliaUser;
import net.ipsoft.amelia.sdk.ISessionInfo;
import net.ipsoft.amelia.sdk.ISessionListener;
import net.ipsoft.amelia.sdk.LoginOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;

import static net.ipsoft.android.sdk.sampleApp.domain.DomainActivity.START_CHAT_REQUEST;
import static java.util.concurrent.TimeUnit.SECONDS;

public class LoginActivity extends AppCompatActivity implements DomainRecyclerViewAdapter.OnListFragmentInteractionListener {
    public static final String EXTRA_AUTH_SYSTEM = "auth_system";
    private static final int SETTINGS_REEQUEST = 1001;
    private static final int LOGIN_SAML_REQUEST_CODE = 1003;
    private static final int INIT_RETRY_INTERVAL = 3000;

    private AutoCompleteTextView usernameView;
    private TextView emailHint;
    private TextView passwordHint;
    private TextView tvPolicy;
    private EditText passwordView;
    private View progressView;
    private IAmeliaChat ameliaChat;
    private Button loginButton;
    private BaseAuthSystem authSystem;
    private DomainRecyclerViewAdapter adapter;
    private AmeliaApplication app;
    private LinearLayout loginFormLayout;
    private LinearLayout guestDomainListLayout;
    private RelativeLayout progressLayout;
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private ScheduledFuture networkCheckerHandle;


    private ISessionListener ameliaSessionListener = new BaseSessionListener() {
        @Override
        public void onDomainSelectionRequired(List<BaseDomain> domains) {
            Intent intent = new Intent(LoginActivity.this,DomainActivity.class);
            intent.putParcelableArrayListExtra("domains",(ArrayList)domains);
            startActivity(intent);
            finish();
        }

        @Override
        public void onLoginFail(IAmeliaError error) {
            LoginActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    progressLayout.setVisibility(View.GONE);
                }
            });
            if(loginFormLayout.getVisibility() == View.VISIBLE && passwordView.getText().length()>0) {
                showProgress(false);
                passwordView.setError(getString(R.string.error_incorrect_password));
                passwordView.requestFocus();
            }
        }

        @Override
        public void onLoginSuccess() {
            showProgress(false);
        }

        @Override
        public void onLoginRequired(List<BaseAuthSystem> authSystems) {
            BaseAuthSystem theAuthSystem = null;
            for(BaseAuthSystem authSystem:authSystems){
                if(authSystem.getRedirect()){
                    theAuthSystem = authSystem;
                    break;
                }
            }
            if(theAuthSystem == null) {
                for (BaseAuthSystem authSystem : authSystems) {
                    if (!authSystem.getRedirect()) {
                        theAuthSystem = authSystem;
                        break;
                    }
                }
            }
            LoginActivity.this.authSystem = theAuthSystem;
            if(theAuthSystem!=null&& theAuthSystem.getRedirect()){
                loginFormLayout.setVisibility(View.GONE);
                loginButton.setEnabled(true);
            }else{
                loginFormLayout.setVisibility(View.VISIBLE);
                loginButton.setEnabled(false);
            }

            LoginOptions loginOptions = new LoginOptions(authSystem, AmeliaApplication.getAppContext());
            ameliaChat.login(loginOptions);
        }

        @Override
        public void sessionInitialized(final ISessionInfo sessionInfo) {
            LoginActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (sessionInfo.isAnonymousAllowed()) {//anonymous allowed on the server
                        guestDomainListLayout.setVisibility(View.VISIBLE);
                        IAmeliaUser user = sessionInfo.getUser();
                        List<BaseDomain> anonymousDomains = user.getDomains();
                        if(user.isAnonymous()&&anonymousDomains!=null&&anonymousDomains.size()>0) {
                            populateAnonymousDomainList(anonymousDomains);
                        }else{
                            guestDomainListLayout.setVisibility(View.GONE);
                        }
                    }else{
                        guestDomainListLayout.setVisibility(View.GONE);
                    }
                    ameliaChat.stepupLogin();
                }
            });
        }
        public void onSessionInitFail(IAmeliaError var1) {
            LoginActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    progressLayout.setVisibility(View.GONE);
                }
            });
            presentErrorDialog(getString(R.string.error_connecting_to_server),getString(R.string.server_connection_error_message));
        }

        @Override
        public void onSessionFail(IAmeliaError error) {
            LoginActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    progressLayout.setVisibility(View.GONE);
                }
            });
        }

        private void populateAnonymousDomainList(List<BaseDomain> anonymousDomains) {
            //guest domain listview
            RecyclerView recyclerView = (RecyclerView) findViewById(R.id.list);
            ViewGroup.LayoutParams params = recyclerView.getLayoutParams();
            params.height = Utils.getPixelFromDp(AmeliaApplication.getAppContext(), (anonymousDomains.size()+1) * 88);
            recyclerView.setLayoutParams(params);
            recyclerView.setLayoutManager(new LinearLayoutManager(LoginActivity.this.getBaseContext()));
            adapter = new DomainRecyclerViewAdapter(anonymousDomains, LoginActivity.this);
            recyclerView.setAdapter(adapter);

        }

    };

    private void presentErrorDialog(String title,String message) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(this);
        }
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setCancelable(false)
                .show();
    }

    @Override
    public void onListFragmentInteraction(BaseDomain domain) {
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra(ChatActivity.DOMAIN, domain);
        startActivityForResult(intent, START_CHAT_REQUEST);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        progressLayout = (RelativeLayout) findViewById(R.id.progressLayout);
        guestDomainListLayout = (LinearLayout)findViewById(R.id.tableLayout);
        emailHint = (TextView) findViewById(R.id.tvEmailHint);
        passwordHint = (TextView) findViewById(R.id.tvPasswordHint);
        loginButton = (Button) findViewById(R.id.email_sign_in_button);
        usernameView = (AutoCompleteTextView) findViewById(R.id.email);
        passwordView = (EditText) findViewById(R.id.password);
        loginFormLayout = (LinearLayout) findViewById(R.id.email_login_form);
        progressLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });
        tvPolicy = (TextView) findViewById(R.id.tvPolicy);
        tvPolicy.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, PolicyActivity.class);
                LoginActivity.this.startActivity(intent);
            }
        });
        usernameView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() <= 0) {
                    emailHint.setText("");
                    loginButton.setEnabled(false);
                } else {
                    emailHint.setText(getString(R.string.username_hint));
                    if (passwordView.length() > 0) {
                        loginButton.setEnabled(true);
                    }
                }
            }
        });
        passwordView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() <= 0) {
                    passwordHint.setText("");
                    loginButton.setEnabled(false);
                } else {
                    passwordHint.setText(getString(R.string.password_hint));
                    if (usernameView.length() > 0) {
                        loginButton.setEnabled(true);
                    }
                }
            }
        });
        passwordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.login || id == EditorInfo.IME_NULL) {//switch to loading state
                    attemptLoginWithCredential();
                    return true;
                }
                return false;
            }
        });

        loginButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {//switch to loading state

                if(LoginActivity.this.authSystem!=null && LoginActivity.this.authSystem.getRedirect()){
                    openSsoLoginActivity();
                }else {
                    attemptLoginWithCredential();

                }
            }
        });

        progressView = findViewById(R.id.login_progress);
        setResult(RESULT_CANCELED);
        createNewChat();
    }

    @Override
    protected void onStart(){
        super.onStart();
        if(Utils.isNetworkAvailable(this.getApplicationContext())) {
            ameliaChat.initialize();
        }else{
            presentErrorDialog(getString(R.string.error_network_connection),getString(R.string.network_connection_error_message));
            final Runnable networkStatusChecker = new Runnable() {
                public void run() {
                    if(Utils.isNetworkAvailable(getApplicationContext())){
                        if(networkCheckerHandle!=null){
                            networkCheckerHandle.cancel(true);
                        }
                        ameliaChat.initialize();
                    }
                }
            };
             networkCheckerHandle = scheduler.scheduleAtFixedRate(networkStatusChecker, 3, 3, SECONDS);

        }
        progressLayout.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onStop(){
        super.onStop();
        if(networkCheckerHandle!=null&&!networkCheckerHandle.isCancelled()){
            networkCheckerHandle.cancel(true);
            networkCheckerHandle = null;
        }
    }

    private void openSsoLoginActivity(){
            AmeliaApplication app = (AmeliaApplication) AmeliaApplication.getAppContext();
            Intent ssoLoginIntent = new Intent(this, SsoLoginActivity.class);
            ssoLoginIntent.putExtra(SsoLoginActivity.EXTRA_LOGIN_URL, app.getBaseUrl() + authSystem.getLoginPath() + "?loginMode=mobileios");
            startActivityForResult(ssoLoginIntent, LOGIN_SAML_REQUEST_CODE);
    }

    private void createNewChat() {
        app = (AmeliaApplication) this.getApplication();
        app.newAmeliaChat();
        ameliaChat = app.getAmeliaChat();
        ameliaChat.addSessionListener(ameliaSessionListener);
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        ameliaChat.removeSessionListener(ameliaSessionListener);
    }


    private void attemptLoginWithCredential() {

        usernameView.setError(null);
        passwordView.setError(null);

        String email = usernameView.getText().toString();
        String password = passwordView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        if (!TextUtils.isEmpty(password) && !isPasswordValid(password)) {
            passwordView.setError(getString(R.string.error_invalid_password));
            focusView = passwordView;
            cancel = true;
        }

        if (TextUtils.isEmpty(email)) {
            usernameView.setError(getString(R.string.error_field_required));
            focusView = usernameView;
            cancel = true;
        } else if (!isEmailValid(email)) {
            usernameView.setError(getString(R.string.error_invalid_email));
            focusView = usernameView;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {
            showProgress(true);
            LoginOptions options = new LoginOptions(authSystem, email, password);

            ameliaChat.login(options);
        }
    }

    private boolean isEmailValid(String email) {
        return true;
    }

    private boolean isPasswordValid(String password) {
        return true;
    }


    private void showProgress(final boolean show) {
        progressView.setVisibility(show ? View.VISIBLE : View.GONE);
        loginButton.setEnabled(!show);
        loginButton.setTextColor(show?Color.TRANSPARENT:Color.WHITE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Intent intent = new Intent(LoginActivity.this, SettingsActivity.class);
                startActivityForResult(intent, SETTINGS_REEQUEST);
                return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check if we came back from settings screen,re-init ameliaChat with new server url
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SETTINGS_REEQUEST) {
            createNewChat();
        }else if (requestCode == LOGIN_SAML_REQUEST_CODE) {
            switch (resultCode) {
                case Activity.RESULT_OK:
                    LoginOptions loginOptions = null;
                    if (data != null && data.getExtras() != null) {
                        loginOptions = new LoginOptions(authSystem, data.getExtras().getString(AmeliaAppConstants.SSO_COOKIE));
                    } else {
                        loginOptions = new LoginOptions(authSystem, AmeliaApplication.getAppContext());
                    }
                    ameliaChat.login(loginOptions);
                    break;
            }
        }
    }
}

