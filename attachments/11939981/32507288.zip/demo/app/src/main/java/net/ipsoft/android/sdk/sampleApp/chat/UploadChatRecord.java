package net.ipsoft.android.sdk.sampleApp.chat;

import net.ipsoft.android.sdk.sampleApp.chat.ChatRecord;

import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.UploadMessage;

/**
 * A specific chat record for MMO upload request
 */
public class UploadChatRecord extends ChatRecord {

    public final UploadMessage uploadMessage;

    public UploadChatRecord(IAmeliaOutboundMessage message) {
        super(message);
        this.uploadMessage = message.getUploadMessage();
    }

}
