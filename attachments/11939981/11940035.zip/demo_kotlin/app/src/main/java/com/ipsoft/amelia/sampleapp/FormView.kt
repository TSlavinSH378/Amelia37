package com.ipsoft.amelia.sampleapp

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

import net.ipsoft.amelia.sdk.FormInputData

import java.util.ArrayList

class FormView : LinearLayout {

    private var mFormSubmitListener: FormSubmittedListener? = null

    constructor(context: Context) : super(context) {
        if (isInEditMode) {
            initWithDummyForm()
        }
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        if (isInEditMode) {
            initWithDummyForm()
        }
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        if (isInEditMode) {
            initWithDummyForm()
        }
    }

    fun setFormInputData(form: FormInputData) {
        initWithForm(form)
    }

    fun setFormSubmitListener(listener: FormSubmittedListener) {
        mFormSubmitListener = listener
    }

    private fun initWithDummyForm() {
        val form = FormInputData()
        form.name = "Sample form"

        form.fields = ArrayList(listOf(FormFieldView.DUMMY_FIELD))
        initWithForm(form)
    }

    private fun initWithForm(form: FormInputData) {

        removeAllViews()

        orientation = LinearLayout.VERTICAL

        val containerContext = context
        val title = TextView(containerContext)
        title.text = form.nameForDisplay
        addView(title)

        for (formInputField in form.fields) {

            val fieldView = FormFieldView(containerContext)
            fieldView.setFormField(formInputField)
            addView(fieldView)

            val marginPx = containerContext.resources.getDimensionPixelOffset(R.dimen.margin)
            val marginSmallPx = containerContext.resources.getDimensionPixelOffset(R.dimen.margin_small)
            (fieldView.layoutParams as LinearLayout.LayoutParams).setMargins(marginPx, marginSmallPx, 0, marginSmallPx)
            fieldView.layoutParams.width = LinearLayout.LayoutParams.MATCH_PARENT

            fieldView.setFieldSubmittedListener(object: FormFieldView.FieldSubmittedListener{
                override fun onFieldSubmitted(value: String){
                    if (mFormSubmitListener != null) {
                        mFormSubmitListener!!.onFormSubmitted(value)
                    }
                }
            } )
        }
    }

     interface FormSubmittedListener {
        fun onFormSubmitted(value: String)
    }
}
