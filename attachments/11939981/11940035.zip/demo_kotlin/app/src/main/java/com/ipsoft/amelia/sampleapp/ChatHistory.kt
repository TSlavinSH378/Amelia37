package com.ipsoft.amelia.sampleapp

import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage
import net.ipsoft.amelia.sdk.BaseConversationListener

import java.util.ArrayList

class ChatHistory : BaseConversationListener() {

    private val chatRecords = ArrayList<ChatRecord>()

    val records: List<ChatRecord>
        get() = chatRecords

    override fun onChatHistoryClear() {
        chatRecords.clear()
    }

    override fun outboundFinalTextMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundProgressTextMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundIdleTalkMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun wolframAlphaFinalMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundEchoMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundFinalErrorMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundConversationClosedMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundSessionClosedMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundIntegrationMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun outboundAgentSessionChangedMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

    override fun onUploadRequest(message: IAmeliaOutboundMessage?) {
        chatRecords.add(UploadChatRecord(message!!))
    }

    override fun outboundMmoDownloadMessage(message: IAmeliaOutboundMessage) {
        chatRecords.add(DownloadChatRecord(message))
    }

    override fun outboundFormInputMessage(ameliaOutboundMessage: IAmeliaOutboundMessage?) {
        chatRecords.add(ChatRecord(ameliaOutboundMessage))
    }

}
