package com.ipsoft.amelia.sampleapp;

/**
 * Created by yyang on 9/28/17.
 */

public class AmeliaAppConstants {
    public static final String SSO_COOKIE = "sso_cookie";

}
