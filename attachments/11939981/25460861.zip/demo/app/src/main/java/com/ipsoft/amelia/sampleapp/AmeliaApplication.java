package com.ipsoft.amelia.sampleapp;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.util.Log;

import net.ipsoft.amelia.sdk.AmeliaChatBuilder;
import net.ipsoft.amelia.sdk.DomainSelectionMode;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.internal.common.ALog;

public class AmeliaApplication extends Application {

    private IAmeliaChat ameliaChat;
    private ChatHistory chatHistory;
    private static Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        ALog.enabled = true;
    }

    public IAmeliaChat getAmeliaChat() {
        return ameliaChat;
    }

    public static Context getAppContext(){
        return context;
    }

    public ChatHistory getChatHistory() {
        return chatHistory;
    }

    public IAmeliaChat newAmeliaChat() {
        chatHistory = new ChatHistory(this.getApplicationContext());

        ameliaChat = new AmeliaChatBuilder()
                .setContext(this)
                .setBaseUrl(getBaseUrl())
                .setDomainSelectionMode(DomainSelectionMode.manual)
                .addConversationListener(chatHistory)
                .setIgnoreCertificateErrors(true)
                .setConnectTimeoutMs(5000)//set connect time  out. Default is 40000 milliseconds
                .setReadTimeoutMs(30000)//set read time  out. Default is 40000 milliseconds
                .setWriteTimeoutMs(30000)//set write time  out. Default is 40000 milliseconds
                .build();
        return ameliaChat;
    }

    public String getBaseUrl() {
        String baseUrl = getString(R.string.base_url);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String userDefinedBaseUrl = sharedPreferences.getString(getString(R.string.key_base_url), "").trim();
        if (userDefinedBaseUrl != null && userDefinedBaseUrl.length() > 0) {
            Uri uri = Uri.parse(userDefinedBaseUrl);
            if (uri.getScheme() == null) {
                userDefinedBaseUrl = "https://" + userDefinedBaseUrl;
                sharedPreferences.edit().putString(getString(R.string.key_base_url), userDefinedBaseUrl).commit();
            }
            baseUrl = userDefinedBaseUrl;
        }
        return baseUrl;
    }
}
