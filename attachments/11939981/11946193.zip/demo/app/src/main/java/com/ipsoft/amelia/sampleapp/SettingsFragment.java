package com.ipsoft.amelia.sampleapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.preference.Preference;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.util.Log;
import android.view.View;

public class SettingsFragment extends PreferenceFragmentCompat {

    SharedPreferences.OnSharedPreferenceChangeListener listener =
            new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override
                public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                    if(key.equals(getString(R.string.key_allow_anonymous))){
                        boolean anonymous = sharedPreferences.getBoolean(key,false);
                        if(anonymous){
                            sharedPreferences.edit().putBoolean(getString(R.string.key_saml_login_enabled), false).commit();
                            setPreferenceScreen(null);
                            addPreferencesFromResource(R.xml.preferences);
                        }
                    }else if(key.equals(getString(R.string.key_saml_login_enabled))){
                        boolean saml = sharedPreferences.getBoolean(key,false);
                        if(saml){
                            sharedPreferences.edit().putBoolean(getString(R.string.key_allow_anonymous), false).commit();
                            setPreferenceScreen(null);
                            addPreferencesFromResource(R.xml.preferences);
                        }
                    }
                }
            };

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        addPreferencesFromResource(R.xml.preferences);
    }

    @Override
    public void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences()
                .registerOnSharedPreferenceChangeListener(listener);
    }


    @Override
    public void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences()
                .unregisterOnSharedPreferenceChangeListener(listener);
    }
}
