package com.ipsoft.amelia.sampleapp;

import android.content.Context;

import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.BaseConversationListener;
import net.ipsoft.amelia.sdk.BaseConversation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatHistory extends BaseConversationListener {


    private Map<BaseConversation,Boolean> agentIdentityMap = new HashMap<>();
    private String remoteUserName;
    private Map<BaseConversation,List<ChatRecord>> chatRecordMap = new HashMap<>();
    private Context context;
    public List<ChatRecord> getRecords(BaseConversation conversation) {
        List<ChatRecord> record = chatRecordMap.get(conversation);
        if(record == null){
            record = new ArrayList<>();
            chatRecordMap.put(conversation,record);
        }
        return record;
    }
    public ChatHistory(Context context){
        this.context = context;
    }


    @Override
    public void onChatHistoryClear(BaseConversation conversation) {
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation);
        if(chatRecords!=null) {
            chatRecords.clear();
        }
    }

    @Override
    public void outboundTextMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
       addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundProgressTextMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundIdleTalkMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void wolframAlphaFinalMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundEchoMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundFinalErrorMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundConversationClosedMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundSessionClosedMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundIntegrationMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundAgentSessionChangedMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void onUploadRequest(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundMmoDownloadMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        addRecord(conversation,ameliaOutboundMessage);
    }

    @Override
    public void outboundFormInputMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage){
        addRecord(conversation,ameliaOutboundMessage);
    }

    private void addRecord(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage){
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation);
        if(chatRecords==null){
            chatRecords = new ArrayList<>();
            chatRecordMap.put(conversation,chatRecords);
        }
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }
}
