package net.ipsoft.android.sdk.sampleApp.chat;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import net.ipsoft.android.sdk.sampleApp.AmeliaApplication;
import net.ipsoft.android.sdk.sampleApp.FormView;
import net.ipsoft.android.sdk.sampleApp.R;
import net.ipsoft.android.sdk.sampleApp.Utils;
import net.ipsoft.android.sdk.sampleApp.accordion.Section;

import net.ipsoft.amelia.sdk.ContentDisplayOption;
import net.ipsoft.amelia.sdk.IAmeliaError;
import net.ipsoft.amelia.sdk.IDownloadMessage;
import net.ipsoft.amelia.sdk.FormInputData;
import net.ipsoft.amelia.sdk.IResourceToDisplay;

import java.io.File;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import okio.BufferedSink;
import okio.Okio;

public class ChatRecyclerViewAdapter extends RecyclerView.Adapter<ChatRecyclerViewAdapter.ViewHolder> {

    private static final int VIEW_TYPE_ME = 0;
    private static final int VIEW_TYPE_AMELIA = 1;
    private static final int VIEW_TYPE_MMO_ME = 2;
    private static final int VIEW_TYPE_MMO_AMELIA = 3;
    private static final int VIEW_TYPE_FORM = 4;
    private static final int VIEW_TYPE_SYS = 5;
    private static final int VIEW_TYPE_THINKING_BUBLE = 6;
    private static final int VIEW_TYPE_AVATAR = 7;

    private final List<ChatRecord> mValues;
    private final Map<Integer, Boolean> mPopupRecords;

    private FormSubmitListener mFormSubmitListener;
    private PermissionRequestListener mPermissionRequestListener;
    private View.OnClickListener onPdfClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            popupPdf(v);
        }
    };
    private View.OnTouchListener onWebViewTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            long eventDuration = event.getEventTime() - event.getDownTime();
            if(event.getAction() == MotionEvent.ACTION_UP&&eventDuration<500) {
                    popupWebContentViewer(v.getContext(), (Uri) v.getTag(R.id.fileUri));
                    return true;
            }
            return false;
        }
    };

    private View.OnClickListener onImageClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            popupImage(v.getContext(), (Uri) v.getTag(R.id.fileUri));
        }
    };
    private View.OnLongClickListener onFileLongClickListener = new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            showExtendedOptions(v.getContext(), (Uri) v.getTag(R.id.fileUri), (String) v.getTag(R.id.mimeType));
            return true;
        }
    };

    public ChatRecyclerViewAdapter(List<ChatRecord> chatRecord, @Nullable FormSubmitListener formSubmitListener, @Nullable PermissionRequestListener permissionRequestListener) {
        mValues = chatRecord;
        mFormSubmitListener = formSubmitListener;
        mPermissionRequestListener = permissionRequestListener;
        mPopupRecords = new HashMap<>();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case VIEW_TYPE_THINKING_BUBLE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_thinking_buble, parent, false);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_ME:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_me, parent, false);
                return new ViewHolder(view);
            case VIEW_TYPE_SYS:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_system, parent, false);
                return new ViewHolder(view);
            case VIEW_TYPE_AMELIA:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_amelia, parent, false);
                LinearLayout rowLayout = (LinearLayout) view.findViewById(R.id.row_layout);
                ViewGroup.MarginLayoutParams marginParams = (ViewGroup.MarginLayoutParams) rowLayout.getLayoutParams();
                marginParams.setMargins(marginParams.leftMargin, marginParams.topMargin, (int) (Utils.getScreenWidth() * 0.25), marginParams.bottomMargin);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_AVATAR:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_avatar, parent, false);
                return new ViewHolder(view);
            case VIEW_TYPE_MMO_ME:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_mmo_me, parent, false);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_MMO_AMELIA:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_mmo_amelia, parent, false);
                return new AmeliaViewHolder(view);
            case VIEW_TYPE_FORM:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item_form, parent, false);
                return new FormViewHolder(view);

        }
        return null;
    }

    @Override
    public int getItemViewType(int position) {
        ChatRecord item = mValues.get(position);
        if (item instanceof DownloadChatRecord) {
            return mValues.get(position).isSelf ? VIEW_TYPE_MMO_ME : VIEW_TYPE_MMO_AMELIA;
        }

        // Display as form if there is a form and it is the last item
        if (item.form != null && position == (mValues.size() - 1)) {
            return VIEW_TYPE_FORM;
        }

        if ("OutboundSessionClosedMessage".equals(item.messageType) ||
                "OutboundConversationClosedMessage".equals(item.messageType)) {
            return VIEW_TYPE_SYS;
        }
        if(AmeliaApplication.getAppContext().getString(R.string.message_type_thinking_bubble).equals(item.messageType)){
            return VIEW_TYPE_THINKING_BUBLE;
        }else if(AmeliaApplication.getAppContext().getString(R.string.message_type_avatar).equals(item.messageType)){
            return VIEW_TYPE_AVATAR;
        }
        return item.isSelf ? VIEW_TYPE_ME : VIEW_TYPE_AMELIA;
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.mItem = mValues.get(position);
        holder.mContentView.setOnClickListener(null);
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_THINKING_BUBLE:
                ImageView dotImageView =(ImageView) holder.mContentView.findViewById(R.id.imageView);
                AnimationDrawable dotAnimation = (AnimationDrawable) dotImageView.getBackground();
                dotAnimation.start();
                break;
            case VIEW_TYPE_AVATAR:
                TextView tvTime = (TextView) holder.mContentView.findViewById(R.id.tvTime);
                TextView tvAgentName = (TextView)holder.mContentView.findViewById(R.id.tvAgent) ;
                ImageView avatarImageView = (ImageView)holder.mContentView.findViewById(R.id.ivAvatar);
                SimpleDateFormat sdf = new SimpleDateFormat("h:mm a");
                String currentDateandTime = sdf.format(new Date());
                tvTime.setText(currentDateandTime);
                tvAgentName.setText(holder.mItem.userDisplayName);
                if(holder.mItem.isAgent){
                    avatarImageView.setImageResource(R.drawable.agent);
                }else{
                    avatarImageView.setImageResource(R.drawable.amelia_happy);
                }
                break;
            case VIEW_TYPE_ME:
                //insert plain text only.
            case VIEW_TYPE_SYS:
                TextView messageTextView1 = (TextView) holder.mContentView;
                String textMessage1 = holder.mItem.messageText;
                messageTextView1.setText(textMessage1);
                break;
            case VIEW_TYPE_AMELIA:
                TextView messageTextView = (TextView) holder.mContentView;
                Context context = messageTextView.getContext();
                if (holder.mItem instanceof DownloadChatRecord) {
                    String text = ((DownloadChatRecord) holder.mItem).downloadMessage.getUri().toString();
                    text = "<a href=\"" + text + "\">" + text + "</a>";
                    messageTextView.setMovementMethod(LinkMovementMethod.getInstance());
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                        messageTextView.setText(Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY));
                    } else {
                        messageTextView.setText(Html.fromHtml(text));
                    }
                } else if (holder.mItem instanceof UploadChatRecord) {
                    UploadChatRecord uploadChatRecord = (UploadChatRecord) holder.mItem;
                    if (uploadChatRecord.uploadMessage.getRecentError() != null) {
                        messageTextView.setText(uploadChatRecord.uploadMessage.getRecentError().getMessage());
                    } else if (uploadChatRecord.uploadMessage.isUploaded()) {
                        messageTextView.setText(context.getString(R.string.uploaded, "File"));
                    } else {
                        messageTextView.setText(R.string.uploading);
                    }
                } else if (holder.mItem.integration != null && holder.mItem.integration.length() > 0) {
                    final Section section;
                    try {
                        section = Section.deserialize(new JSONObject(holder.mItem.integration));
                        messageTextView.setText(context.getString(R.string.tap_to_open_integration, section.getTitle()));
                        messageTextView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (holder.mView.getContext() instanceof ChatActivity) {
                                    ((ChatActivity) holder.mView.getContext()).showIntegration(section);
                                }
                            }
                        });
                    } catch (JSONException e) {
                        //Log.e("chat-fragment", "Failed to parse integration message");
                    }
                } else {
                    String textMessage = holder.mItem.messageText;
                    Pattern htmlPattern
                            = Pattern.compile("^(.*?)(<\\w){1}(.|\\s)*(>){1}(.*?)$");
                    if (textMessage!=null&&htmlPattern.matcher(textMessage).matches()) {
                        messageTextView.setMovementMethod(LinkMovementMethod.getInstance());
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            messageTextView.setText(Html.fromHtml(textMessage, Html.FROM_HTML_MODE_LEGACY));
                        } else {
                            messageTextView.setText(Html.fromHtml(textMessage));
                        }
                    } else {
                        messageTextView.setText(textMessage);
                    }
                    if(!"Amelia".equals(holder.mItem.userDisplayName)){
                        messageTextView.setBackgroundResource(R.drawable.chat_bubble_agent);
                    }else{
                        messageTextView.setBackgroundResource(R.drawable.chat_bubble_amelia);
                    }
                }
                break;
            case VIEW_TYPE_MMO_ME: {
                DownloadChatRecord mmoItem = (DownloadChatRecord) holder.mItem;
                ImageView imageView = ((ImageView) holder.mContentView);
                if (mmoItem.downloadMessage.getMimeType().contains("/pdf")) {
                    imageView.setImageDrawable(ContextCompat.getDrawable(imageView.getContext(), R.drawable.ic_pdf_black_40dp));
                } else {
                    imageView.setImageURI(mmoItem.downloadMessage.getUri());
                }
                break;
            }
            case VIEW_TYPE_MMO_AMELIA: {
                final DownloadChatRecord mmoItem = (DownloadChatRecord) holder.mItem;
                final ViewGroup container = (ViewGroup) holder.mContentView;
                final int marginSmall = container.getContext().getResources().getDimensionPixelOffset(R.dimen.margin_small);
                container.removeAllViews();
                final ImageView imageView = new ImageView(container.getContext());
                imageView.setBackgroundResource(R.drawable.chat_bubble_amelia);
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                imageView.setPadding(marginSmall, marginSmall, marginSmall, marginSmall);
                imageView.setAdjustViewBounds(true);
                container.addView(imageView);
                LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) imageView.getLayoutParams();
                lp.setMargins(0, marginSmall, Utils.getScreenWidth() / 4, marginSmall);
                final String mimeType = mmoItem.downloadMessage.getMimeType();
                final IAmeliaError recentError = mmoItem.downloadMessage.getError();
                if (recentError != null || mimeType == null) {
                    lp.width = Utils.getPixelFromDp(container.getContext(), 50);
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    imageView.setImageResource(R.drawable.broken_file);
                    imageView.setMinimumWidth(200);
                    imageView.setMinimumHeight(200);
                } else {
                    ContentDisplayOption contentDisplayOption = mmoItem.downloadMessage.getContentDisplayOption();
                    IResourceToDisplay fileInfo = mmoItem.downloadMessage.getFileInfo();
                    final Uri fileUri = mmoItem.downloadMessage.getUri();
                    lp.width = ViewGroup.LayoutParams.WRAP_CONTENT;
                    lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    imageView.setTag(R.id.fileUri, fileUri);
                    imageView.setTag(R.id.mimeType, mimeType);

                    if (mimeType.contains("/pdf")) {
                        handlePdfPresentation(imageView,container,mmoItem.downloadMessage,position);
                    } else if (mimeType.contains("image")) {
                      handleImagePresentation(imageView,container,mmoItem.downloadMessage,position);
                    } else if (mimeType.contains("text/html")||mimeType.contains("text/xhtml")) {
                       handleHtmlContentPresentation(imageView,container,mmoItem.downloadMessage,position);
                    } else {//other types of file downloaded.
                        imageView.setImageDrawable(ContextCompat.getDrawable(container.getContext(), R.drawable.file_icon));
                        imageView.setTag(null);
                        imageView.setOnClickListener(null);
                        if (fileInfo.getDownload()) {
                            imageView.setOnLongClickListener(onFileLongClickListener);
                        }
                    }
                    if ((fileInfo.shouldDisplayFileSize() || fileInfo.shouldDisplayFileName() )&& contentDisplayOption != ContentDisplayOption.POPUP_ONLY) {//adding file info
                        File file = new File(fileUri.getPath());
                        TextView tv = new TextView(container.getContext());
                        tv.setText(fileInfo.getFilename() + " (" + file.length() / 1024 + "KB)");
                        container.addView(tv);
                    }
                }

                break;
            }
            case VIEW_TYPE_FORM:
                final FormInputData form = holder.mItem.form;

                TextView msgTextView = (TextView) holder.mContentView;
                String textMessage = holder.mItem.messageText;
                Pattern htmlPattern
                        = Pattern.compile("^(.*?)(<\\w){1}(.|\\s)*(>){1}(.*?)$");
                if (textMessage!=null&&htmlPattern.matcher(textMessage).matches()) {
                    msgTextView.setMovementMethod(LinkMovementMethod.getInstance());
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                        msgTextView.setText(Html.fromHtml(textMessage, Html.FROM_HTML_MODE_LEGACY));
                    } else {
                        msgTextView.setText(Html.fromHtml(textMessage));
                    }
                } else {
                    msgTextView.setText(textMessage);
                }
                final ViewGroup placeHolderView = ((FormViewHolder) holder).getFormPlaceholder();

                FormView formView = new FormView(placeHolderView.getContext());
                formView.setFormInputData(form);
                formView.setFormSubmitListener(new FormView.FormSubmittedListener() {
                    @Override
                    public void onFormSubmitted(String value) {
                        if (mFormSubmitListener != null) {
                            mFormSubmitListener.onFormSubmitted(form, value);
                        }
                    }
                });

                // Replace the placeholder with the actual formView
                final ViewGroup parent = (ViewGroup) placeHolderView.getParent();
                final int placeholderIndex = parent.indexOfChild(placeHolderView);
                parent.removeView(placeHolderView);
                formView.setId(placeHolderView.getId());
                parent.addView(formView, placeholderIndex);

                break;
        }

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // retry
            }
        });
    }

    private void popupWebContentViewer(Context context, Uri contentUri){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW);
        browserIntent.setDataAndType(contentUri,"text/html");
        browserIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
       context.startActivity(browserIntent);
    }

    private WebView getWebView(Context context,int maxHeight){
        WebView webView = new AmeliaMultiMediaWebView(context,maxHeight);
        webView.setBackgroundResource(R.drawable.chat_bubble_amelia);
        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        return webView;
    }
    private boolean autoPopUpAllowed(int position) {
        if (mPopupRecords.containsKey(position)) {
            return false;
        }
        mPopupRecords.put(position, null);
        return true;
    }

    private void showExtendedOptions(final Context context, final Uri uri, final String mimeType) {
        CharSequence colors[] = new CharSequence[]{context.getString(R.string.save)};

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(context.getString(R.string.file_optons));
        builder.setItems(colors, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    if (mPermissionRequestListener != null) {
                        mPermissionRequestListener.requestPermission(new PermissionRequestCompletionListener() {
                            @Override
                            public void onPermissionGranted() {
                                File sourceFile = new File(uri.getPath());
                                File downloadFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                                File file = new File(downloadFolder, sourceFile.getName());
                                try {
                                    BufferedSink bufferedSink = Okio.buffer(Okio.sink(file));
                                    bufferedSink.writeAll(Okio.source(sourceFile));
                                    bufferedSink.close();
                                    DownloadManager manager = (DownloadManager) context.getSystemService(
                                            Context.DOWNLOAD_SERVICE);
                                    manager.addCompletedDownload(file.getName(), file.getName(), true, mimeType, file.getAbsolutePath(), file.length(), true);
                                    Toast.makeText(context, file.getName() + " " + context.getString(R.string.file_saved_successfully), Toast.LENGTH_LONG).show();
                                } catch (IOException ex) {
                                    Toast.makeText(context, context.getString(R.string.file_cannot_be_saved), Toast.LENGTH_LONG).show();
                                }
                            }

                            @Override
                            public void onPermissionDenied() {
                                Toast.makeText(context, context.getString(R.string.file_cannot_be_saved), Toast.LENGTH_LONG).show();
                            }
                        });
                    }

                }
            }
        });
        builder.show();
    }

    private void popupPdf(View v) {
        try {
            Uri uri = (Uri) v.getTag(R.id.fileUri);
            uri = FileProvider.getUriForFile(v.getContext(), v.getContext().getApplicationContext().getPackageName() + ".provider", new File(uri.getPath()));
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            v.getContext().startActivity(intent);
        } catch (ActivityNotFoundException ignore) {
            Toast.makeText(v.getContext(), v.getContext().getString(R.string.no_app_found_to_open_pdf), Toast.LENGTH_LONG).show();
        }
    }

    private void popupImage(Context context, Uri imageUri) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(imageUri, "image/*");
        context.startActivity(intent);
    }

    private void handlePdfPresentation(final ImageView imageView, final ViewGroup container, IDownloadMessage downloadMessage,int position){
        final ContentDisplayOption contentDisplayOption =downloadMessage.getContentDisplayOption();
        final IResourceToDisplay fileInfo = downloadMessage.getFileInfo();
        final Uri fileUri = downloadMessage.getUri();
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final Uri pdfImageUri = Utils.getPdfThumbnail(container.getContext(), fileUri);
                    imageView.post(new Runnable() {
                        @Override
                        public void run() {
                            imageView.setImageURI(pdfImageUri);
                        }
                    });
                } catch (Exception e) {
                    imageView.post(new Runnable() {
                        @Override
                        public void run() {
                            imageView.setImageDrawable(ContextCompat.getDrawable(container.getContext(), R.drawable.ic_pdf_black_40dp));
                        }
                    });
                }
            }
        });
        switch (contentDisplayOption){
            case INLINE_ONLY:
                t.start();
                break;
            case INLINE_AND_POPUP:
                t.start();
                imageView.setOnClickListener(onPdfClickListener);
                break;
            case POPUP_AND_INLINE:
                t.start();
                if (autoPopUpAllowed(position)) {
                    popupPdf(imageView);
                }
                imageView.setOnClickListener(onPdfClickListener);
                break;
            case POPUP_ONLY:
                imageView.setVisibility(View.GONE);
                if (autoPopUpAllowed(position)) {
                    popupPdf(imageView);
                }
                break;
            case NO_PREVIEW:
                LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) imageView.getLayoutParams();
                lp.width = Utils.getPixelFromDp(container.getContext(), 50);
                lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                imageView.setImageDrawable(ContextCompat.getDrawable(container.getContext(), R.drawable.download_button));
                break;
            default:
                imageView.setVisibility(View.GONE);
        }
        if (fileInfo.getDownload()) {
            imageView.setOnLongClickListener(onFileLongClickListener);
        }
    }

    private void handleHtmlContentPresentation(final ImageView imageView,final ViewGroup container,IDownloadMessage downloadMessage,int position){
        Uri fileUri = downloadMessage.getUri();
        String mimeType = downloadMessage.getMimeType();
        ContentDisplayOption contentDisplayOption = downloadMessage.getContentDisplayOption();
        IResourceToDisplay fileInfo = downloadMessage.getFileInfo();
        int marginSmall = container.getContext().getResources().getDimensionPixelOffset(R.dimen.margin_small);
        int sideLength = (int)(Utils.getScreenWidth()*0.75);
        WebView webView = getWebView(container.getContext(),sideLength);
        imageView.setVisibility(View.GONE);
        container.addView(webView);
        webView.setPadding(marginSmall, marginSmall, marginSmall, marginSmall);
        ViewGroup.LayoutParams webViewLayoutParams =  webView.getLayoutParams();
        webViewLayoutParams.width =  sideLength;
        webViewLayoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        webView.setTag(R.id.fileUri,fileUri);
        webView.setTag(R.id.mimeType, mimeType);
        webView.setLongClickable(true);
        switch (contentDisplayOption){
            case INLINE_ONLY:
                webView.loadUrl(fileUri.toString());
                if (fileInfo.getDownload()) {
                    webView.setOnLongClickListener(onFileLongClickListener);
                }
                break;
            case INLINE_AND_POPUP:
                webView.loadUrl(fileUri.toString());
                webView.setOnTouchListener(onWebViewTouchListener);
                if (fileInfo.getDownload()) {
                    webView.setOnLongClickListener(onFileLongClickListener);
                }
                break;
            case POPUP_AND_INLINE:
                if (autoPopUpAllowed(position)) {
                    popupWebContentViewer(container.getContext(), fileUri);
                }
                webView.loadUrl(fileUri.toString());

                webView.setOnTouchListener(onWebViewTouchListener);
                if (fileInfo.getDownload()) {
                    webView.setOnLongClickListener(onFileLongClickListener);
                }
                break;
            case POPUP_ONLY:
                webView.setVisibility(View.GONE);
                if (autoPopUpAllowed(position)) {
                    popupWebContentViewer(container.getContext(), fileUri);
                }
                break;
            case NO_PREVIEW:
                imageView.setVisibility(View.VISIBLE);
                webView.setVisibility(View.GONE);
                LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) imageView.getLayoutParams();
                lp.width = Utils.getPixelFromDp(container.getContext(), 50);
                lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                imageView.setImageResource(R.drawable.download_button);
                if (fileInfo.getDownload()) {
                    imageView.setOnLongClickListener(onFileLongClickListener);
                }
                break;
            default:
                webView.setVisibility(View.GONE);

        }
    }

    private void handleImagePresentation(final ImageView imageView, final ViewGroup container, final IDownloadMessage downloadMessage, int position){
        final ContentDisplayOption contentDisplayOption = downloadMessage.getContentDisplayOption();
        final Uri fileUri = downloadMessage.getUri();
        final IResourceToDisplay fileInfo = downloadMessage.getFileInfo();

        switch (contentDisplayOption){
            case INLINE_ONLY:
                imageView.setImageURI(fileUri);
                break;
            case INLINE_AND_POPUP:
                imageView.setImageURI(fileUri);
                imageView.setOnClickListener(onImageClickListener);
                break;
            case POPUP_AND_INLINE:
                if (autoPopUpAllowed(position)) {
                    popupImage(imageView.getContext(), fileUri);
                }
                imageView.setImageURI(fileUri);
                imageView.setOnClickListener(onImageClickListener);
                break;
            case POPUP_ONLY:
                imageView.setVisibility(View.GONE);
                if (autoPopUpAllowed(position)) {
                    popupImage(imageView.getContext(), fileUri);
                }
                break;
            case NO_PREVIEW:
                LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) imageView.getLayoutParams();
                lp.width = Utils.getPixelFromDp(container.getContext(), 50);
                lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                imageView.setImageResource(R.drawable.download_button);
                break;
            default:
                imageView.setVisibility(View.GONE);
        }
        if (fileInfo.getDownload()) {
            imageView.setOnLongClickListener(onFileLongClickListener);
        }
    }

    public void removeFormSubmitListener() {
        mFormSubmitListener = null;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final View mContentView;
        public ChatRecord mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mContentView = view.findViewById(R.id.message);
        }
    }

    public class AmeliaViewHolder extends ViewHolder {
        public AmeliaViewHolder(View view) {
            super(view);
        }
    }

    public class FormViewHolder extends AmeliaViewHolder {

        public FormViewHolder(View view) {
            super(view);
        }

        public ViewGroup getFormPlaceholder() {
            return (ViewGroup) itemView.findViewById(R.id.fields_container);
        }
    }

    interface FormSubmitListener {
        void onFormSubmitted(FormInputData form, String message);
    }

    interface PermissionRequestListener {
        void requestPermission(PermissionRequestCompletionListener listener);
    }

    interface PermissionRequestCompletionListener {
        void onPermissionGranted();

        void onPermissionDenied();
    }

    private static class AmeliaMultiMediaWebView extends WebView{
        private int maxHeight;
        public AmeliaMultiMediaWebView(Context context,int maxHeight) {
            super(context);
            this.maxHeight = maxHeight;
        }
        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            heightMeasureSpec = MeasureSpec.makeMeasureSpec(maxHeight, MeasureSpec.AT_MOST);
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        }
    }

}
