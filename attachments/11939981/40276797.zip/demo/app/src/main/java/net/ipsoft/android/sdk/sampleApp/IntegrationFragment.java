package net.ipsoft.android.sdk.sampleApp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import net.ipsoft.android.sdk.sampleApp.accordion.Section;
import net.ipsoft.android.sdk.sampleApp.accordion.SectionView;


public class IntegrationFragment extends Fragment {

    private Section section = null;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup view = (ViewGroup) inflater.inflate(R.layout.fragment_accordion, container, false);

        if (section == null) {
            Log.e("integration-fragment", "No section to show");
            return view;
        }

        final SectionView sectionView = new SectionView(getContext());
        if (getContext() instanceof ActionListener) {
            sectionView.setActionListener((ActionListener)getContext());
        } else {
            Log.e("integration-fragment", "No action listener");
        }
        sectionView.setSection(section);

        view.addView(sectionView);
        return view;
    }

    public void setSection(Section section) {
        this.section = section;
    }

    public interface ActionListener {
        void onAction(String processName, String processArgs, String utterance);
    }
}
