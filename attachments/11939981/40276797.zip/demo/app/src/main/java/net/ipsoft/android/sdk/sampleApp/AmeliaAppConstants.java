package net.ipsoft.android.sdk.sampleApp;

/**
 * Created by yyang on 9/28/17.
 */

public class AmeliaAppConstants {
    public static final String SSO_COOKIE = "sso_cookie";
    public static final String LOGIN_TYPE = "LOGIN_TYPE";

}
