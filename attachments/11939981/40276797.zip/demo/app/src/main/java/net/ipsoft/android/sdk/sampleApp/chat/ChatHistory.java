package net.ipsoft.android.sdk.sampleApp.chat;

import android.content.Context;

import net.ipsoft.android.sdk.sampleApp.R;
import net.ipsoft.android.sdk.sampleApp.chat.ChatRecord;

import net.ipsoft.amelia.sdk.BaseConversationListener;
import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.BaseConversation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class ChatHistory extends BaseConversationListener {

    private Map<String,Boolean> agentIdentityMap = new HashMap<>();
    private String remoteUserName;
    private Map<String,List<ChatRecord>> chatRecordMap = new HashMap<>();
    private Context context;
    public List<ChatRecord> getRecords(BaseConversation conversation) {
        List<ChatRecord> record = chatRecordMap.get(conversation.getConversationId());
        if(record == null){
            record = new ArrayList<>();
            chatRecordMap.put(conversation.getConversationId(),record);
        }
        return record;
    }

    public ChatHistory(Context context){
        this.context = context;
    }

    @Override
    public void onChatHistoryClear(BaseConversation conversation){
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation.getConversationId());
        if(chatRecords!=null) {
            chatRecords.clear();
        }
        agentIdentityMap.put(conversation.getConversationId(),false);
    }

    public void clearHistory(BaseConversation conversation){
        onChatHistoryClear(conversation);
    }
    @Override
    public void outboundTextMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new ChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
    }

    @Override
    public void wolframAlphaFinalMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new ChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
    }

    @Override
    public void outboundEchoMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new ChatRecord(ameliaOutboundMessage));
        if(ameliaOutboundMessage.isSelfEcho()) {
            addProgressBar(conversation);
        }else{
            addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
        }
    }

    @Override
    public void outboundConversationClosedMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new ChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
    }

    @Override
    public void outboundSessionClosedMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new ChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
    }

    @Override
    public void outboundIntegrationMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new ChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
    }

    @Override
    public void outboundAgentSessionChangedMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new ChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
        agentIdentityMap.put(conversation.getConversationId(),true);
    }

    @Override
    public void onUploadRequest(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new UploadChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
    }

    @Override
    public void outboundMmoDownloadMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new DownloadChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
    }

    @Override
    public void outboundFormInputMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage){
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new ChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
    }

    @Override
    public void outboundEscalationStartedMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
        removeAvatar(conversation);
        removeProgressBar(conversation);
        addRecord(conversation,new ChatRecord(ameliaOutboundMessage));
        addAvatar(conversation,ameliaOutboundMessage.getFromUserDisplayName());
    }

    private void addProgressBar(BaseConversation conversation){
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation.getConversationId());
        if(chatRecords==null){
            chatRecords = new ArrayList<>();
            chatRecordMap.put(conversation.getConversationId(),chatRecords);
        }
        chatRecords.add(new ChatRecord(context,ChatRecord.SpecialMessageType.MESSAGE_TYPE_THINKING_BUBBLE));
    }

    private void removeProgressBar(BaseConversation conversation){
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation.getConversationId());
        if(chatRecords==null){
            chatRecords = new ArrayList<>();
            chatRecordMap.put(conversation.getConversationId(),chatRecords);
        }
        if(chatRecords.size()>0){
            ChatRecord lastRecord = chatRecords.get(chatRecords.size()-1);
            if(context.getString(R.string.message_type_thinking_bubble).equals(lastRecord.messageType)){
                chatRecords.remove(lastRecord);
            }
        }
    }

    private void addAvatar(BaseConversation conversation,String userName){
        Boolean isAgent = agentIdentityMap.get(conversation.getConversationId());
        if(isAgent==null){
            isAgent = false;
        }
        ChatRecord chatRecord = new ChatRecord(context,ChatRecord.SpecialMessageType.MESSAGE_TYPE_AVATAR);
        chatRecord.setIsAgent(isAgent);
        chatRecord.setUserDisplayName(userName);
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation.getConversationId());
        if(chatRecords==null){
            chatRecords = new ArrayList<>();
            chatRecordMap.put(conversation.getConversationId(),chatRecords);
        }
        chatRecords.add(chatRecord);
    }

    private void removeAvatar(BaseConversation conversation){
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation.getConversationId());
        if(chatRecords==null){
            chatRecords = new ArrayList<>();
            chatRecordMap.put(conversation.getConversationId(),chatRecords);
        }
        if(chatRecords.size()>0){
            ChatRecord lastRecord = chatRecords.get(chatRecords.size()-1);
            if(context.getString(R.string.message_type_avatar).equals(lastRecord.messageType)){
                chatRecords.remove(lastRecord);
            }
        }
    }

    private void addRecord(BaseConversation conversation,ChatRecord chatRecord){
        List<ChatRecord> chatRecords = chatRecordMap.get(conversation.getConversationId());
        if(chatRecords==null){
            chatRecords = new ArrayList<>();
            chatRecordMap.put(conversation.getConversationId(),chatRecords);
        }
        chatRecords.add(chatRecord);
    }

}
