package net.ipsoft.android.sdk.sampleApp.chat;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import net.ipsoft.android.sdk.sampleApp.AmeliaApplication;
import net.ipsoft.android.sdk.sampleApp.login.LoginActivity;
import net.ipsoft.android.sdk.sampleApp.R;

import net.ipsoft.amelia.sdk.BaseConversation;
import net.ipsoft.amelia.sdk.BaseConversationListener;
import net.ipsoft.amelia.sdk.BaseDomain;
import net.ipsoft.amelia.sdk.BaseSessionListener;
import net.ipsoft.amelia.sdk.BpnExecutionEvent;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.IAmeliaError;
import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.BaseConversation;
import net.ipsoft.amelia.sdk.BaseConversationListener;
import net.ipsoft.amelia.sdk.IDownloadListener;
import net.ipsoft.amelia.sdk.IDownloadMessage;
import net.ipsoft.amelia.sdk.IDownloadedMmo;
import net.ipsoft.amelia.sdk.FormInputData;
import net.ipsoft.amelia.sdk.ISessionListener;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent;
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener;

import java.util.List;

public class ChatFragment extends Fragment implements ChatRecyclerViewAdapter.FormSubmitListener, net.ipsoft.android.sdk.sampleApp.chat.ChatRecyclerViewAdapter.PermissionRequestListener {

    private static final String TAG = "ChatFragment";
    public static final int FILE_REQUEST_CODE = 1001;
    private static final int WRITE_EXTERNAL_STORAGE_PERMISSION = 2001;
    private static final int MIC_PERMISSON_REQUEST_CODE = 2002;
    private static final String ESCALTE_TO_LIVE_AGENT_MESSAGE = "Escalate";
    private IAmeliaChat ameliaChat;
    private net.ipsoft.android.sdk.sampleApp.chat.ChatHistory chatHistory;
    private net.ipsoft.android.sdk.sampleApp.chat.ChatRecyclerViewAdapter adapter;
    private EditText inputField;
    private View speechButton;
    private View sendButton;
    private boolean inputEnabled;
    private RecyclerView recyclerView;
    private LinearLayout tooltip;
    private int recentlyLoadedChatIndex = -1;
    private SpeechRecognizer speechRecognizer;
    private BaseDomain domain;
    private BaseConversation conversation;
    private net.ipsoft.android.sdk.sampleApp.chat.ChatRecyclerViewAdapter.PermissionRequestCompletionListener extStorageWritePermissionListener;
    private ISessionListener sessionListener = new BaseSessionListener() {
        @Override
        public void onConversationFail(IAmeliaError var1) {
            askReconnectDialogue(getString(R.string.error_start_new_conversation_dialog_title), getString(R.string.failed_to_start_new_conversation_msg));
        }
    };


    private View.OnClickListener speechButtonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (ensureMicrophonePermission()) {
                startSpeechListener();
            }
        }
    };

    private void startSpeechListener() {
        Intent recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, domain.getLocaleLanguageTag());

        speechRecognizer.startListening(recognizerIntent);
    }

    private boolean ensureMicrophonePermission() {
        final boolean hasPermission = ContextCompat.checkSelfPermission(getContext(), android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        if (hasPermission) return true;

        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},
                MIC_PERMISSON_REQUEST_CODE);
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == MIC_PERMISSON_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startSpeechListener();
            } else {
                // We were not granted microphone permission.
            }
        } else if (requestCode == WRITE_EXTERNAL_STORAGE_PERMISSION) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (extStorageWritePermissionListener != null) {
                    extStorageWritePermissionListener.onPermissionGranted();
                    ;
                }
            } else {
                if (extStorageWritePermissionListener != null) {
                    extStorageWritePermissionListener.onPermissionDenied();
                    ;
                }
            }
            return;
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    public ChatFragment(){

    }


    @Override
    public void onPause() {
        super.onPause();
        ameliaChat.stopPlayAudio(conversation);
    }

    @SuppressWarnings("unused")
    public static ChatFragment newInstance(BaseConversation conversation, BaseDomain domain) {
        ChatFragment fragment = new ChatFragment();
        Bundle args = new Bundle();
        args.putParcelable(ChatActivity.CONVERSATION,conversation);
        args.putParcelable(ChatActivity.DOMAIN, domain);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AmeliaApplication app = (AmeliaApplication) getActivity().getApplication();
        ameliaChat = app.getAmeliaChat();
        chatHistory = app.getChatHistory();
        domain = getArguments().getParcelable(ChatActivity.DOMAIN);
        conversation = getArguments().getParcelable(ChatActivity.CONVERSATION);
        ameliaChat.addSessionListener(sessionListener);
        setRetainInstance(true);
    }

    private void showView(View view) {
        view.setVisibility(View.VISIBLE);
        view.setRotationX(-90);
        view.animate().rotationX(0).setDuration(700);
    }

    private void hideView(final View view) {
        view.animate().rotationX(-90).setDuration(700).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                view.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chat, container, false);
        Context context = view.getContext();
        recyclerView = (RecyclerView) view.findViewById(R.id.list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setStackFromEnd(false);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter = new ChatRecyclerViewAdapter(chatHistory.getRecords(conversation), this, this);
        recentlyLoadedChatIndex = chatHistory.getRecords(conversation).size() - 1;
        recyclerView.setAdapter(adapter);
        sendButton = view.findViewById(R.id.send_button);
        tooltip = (LinearLayout) view.findViewById(R.id.tooltip);
        showView(tooltip);
        View closeButton = tooltip.findViewById(R.id.closeButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideView(tooltip);
            }
        });

        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
                if (rv != null) {
                    hideSoftKeyboard(ChatFragment.this.getActivity());
                }
                return false;
            }

            @Override
            public void onTouchEvent(RecyclerView rv, MotionEvent e) {
            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {
            }
        });

        inputField = (EditText) view.findViewById(R.id.input_field);
        inputField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                speechButton.setVisibility(s.length() > 0 ? View.GONE : View.VISIBLE);
                sendButton.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
                if (s.length() > 0 && tooltip.getVisibility() == View.VISIBLE) {
                    hideView(tooltip);
                }
            }
        });

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submit();
            }
        });
        speechButton = view.findViewById(R.id.speech_button);
        if (SpeechRecognizer.isRecognitionAvailable(getContext())) {
            ((AppCompatImageButton) speechButton).setImageResource(R.drawable.ic_mic_off);
            speechButton.setEnabled(conversation.isInputEnabled());
            speechButton.setOnClickListener(speechButtonClickListener);
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    Log.d("amelia", "onReadyForSpeech");
                    ((AppCompatImageButton) speechButton).setImageResource(R.drawable.ic_mic_on);
                }

                @Override
                public void onBeginningOfSpeech() {
                    Log.d("amelia", "onBeginningOfSpeech");
                }

                @Override
                public void onRmsChanged(float rmsdB) {
                    Log.d("amelia", "onRmsChanged");
                }

                @Override
                public void onBufferReceived(byte[] buffer) {
                    Log.d("amelia", "onBufferReceived");
                }

                @Override
                public void onEndOfSpeech() {
                    Log.d("amelia", "onEndOfSpeech");
                    ((AppCompatImageButton) speechButton).setImageResource(R.drawable.ic_mic_off);
                }

                @Override
                public void onError(int error) {
                    Log.d("amelia", "onError");
                    ((AppCompatImageButton) speechButton).setImageResource(R.drawable.ic_mic_off);
                }

                @Override
                public void onResults(Bundle results) {
                    Log.d("amelia", "onResults");

                    String str = "";
                    List<String> data = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (data.size() > 0) {
                        str = data.get(0);
                        inputField.setText(str);
                    }
                    Log.d("amelia", "onResults: [" + data.size() + "]" + str);

                }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    String str = "";
                    List<String> data = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (data.size() > 0) {
                        str = data.get(0);
                        inputField.setText(str);
                    }
                    Log.d("amelia", "onPartialResults: [" + data.size() + "]" + str);

                }

                @Override
                public void onEvent(int eventType, Bundle params) {
                    Log.d("amelia", "onEvent");
                }
            });
        } else {
            speechButton.setVisibility(View.GONE);
        }

        ameliaChat.addConversationListener(conversationListener);
        final Handler handler = new Handler();
        KeyboardVisibilityEvent.setEventListener(
                getActivity(),
                new KeyboardVisibilityEventListener() {
                    @Override
                    public void onVisibilityChanged(boolean isOpen) {
                        recyclerView.smoothScrollToPosition(recyclerView.getAdapter().getItemCount());
                    }
                });
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedinstance) {
        super.onActivityCreated(savedinstance);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ameliaChat.removeConversationListener(conversationListener);
        ameliaChat.removeSessionListener(sessionListener);
        adapter.removeFormSubmitListener();
    }

    public void resetConversation() {
        ameliaChat.addSessionListener(new BaseSessionListener() {
            @Override
            public void onConversationEnd(BaseConversation conversation) {
                    ameliaChat.removeSessionListener(this);
                    chatHistory.clearHistory(conversation);
                    adapter.notifyDataSetChanged();
            }

            @Override
            public void onConversationFail(IAmeliaError error) {
                ameliaChat.removeSessionListener(this);
            }

            public void onSessionFail(IAmeliaError error) {
                ameliaChat.removeSessionListener(this);
            }
        });

        ameliaChat.resetConversation(conversation);
    }

    private void submit() {
        String text = inputField.getText().toString().trim();
        if (!text.isEmpty()) {
            submit(text);
            hideSoftKeyboard(this.getActivity());
        }
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }

    public void escalate() {
        submit(ESCALTE_TO_LIVE_AGENT_MESSAGE);
    }

    private void submit(String message) {
        ameliaChat.stopPlayAudio(conversation);
        ameliaChat.say(conversation, message);
        inputField.setText("");
    }

    private void notifyNewMessage() {
        adapter.notifyDataSetChanged();
        recyclerView.smoothScrollToPosition(recyclerView.getAdapter().getItemCount());
    }

    private int getMoodIcon(String mood) {
        switch (mood) {
            case "NEUTRAL":
                return R.drawable.neutral_smile;
            case "HAPPY":
                return R.drawable.happy;
            case "SAD":
                return R.drawable.sad;
            case "DISGUSTED":
                return R.drawable.disgust;
            case "CONTEMPT":
                return R.drawable.smirk_left;
            case "AMUSED":
                return R.drawable.amused;
            case "ANGRY":
                return R.drawable.anger;
            case "BEMUSED":
                return R.drawable.bemused;
            case "CONFUSION":
                return R.drawable.confusion;
            case "EXCITED":
                return R.drawable.excited;
            case "FEAR":
                return R.drawable.anger;
            case "HAPPY_SINCERE":
                return R.drawable.happy_sincere;
            case "JOY":
                return R.drawable.joy;
            case "POUT":
                return R.drawable.pout;
            case "SIMPLE_SMILE":
                return R.drawable.simple_smile;
            case "SINCERE_SMILE":
                return R.drawable.sincere_smile;
            case "SMIRK_LEFT":
                return R.drawable.smirk_left;
            case "SMIRK_RIGHT":
                return R.drawable.smirk_right;
            case "SURPRISED":
                return R.drawable.joy;
            default:
                return R.drawable.neutral_smile;
        }
    }


    private void openFileChooser(String fromUserDisplayName, String fileType) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        intent.setType("*/*");
        Intent i = Intent.createChooser(intent, fromUserDisplayName + " requested " + fileType);
        startActivityForResult(i, FILE_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 1001:
                if (resultCode == Activity.RESULT_OK && data != null) {
                    ameliaChat.uploadFile(conversation, data.getData());
                } else {
                    ameliaChat.cancleFileUpload(conversation);
                }
                break;
        }
    }

    private BaseConversationListener conversationListener = new BaseConversationListener() {

        @Override
        public void onSpeakStart() {
            ((AppCompatImageButton) speechButton).setImageResource(R.drawable.ic_mic_off);
            speechButton.setEnabled(false);
        }

        @Override
        public void onSpeakEnd() {
            ((AppCompatImageButton) speechButton).setImageResource(R.drawable.ic_mic_off);
            speechButton.setEnabled(true);
        }

        @Override
        public void onSecureInputEnabledChanged(BaseConversation conversation, boolean enabled) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId()) && inputField != null) {
                if (enabled) {
                    inputField.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                } else {
                    inputField.setInputType(InputType.TYPE_CLASS_TEXT);
                }
            }
        }

        @Override
        public void onInputEnabledChanged(BaseConversation conversation, boolean enabled, String messageType, IAmeliaChat.InputStateChangeReason reason) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                ((AppCompatImageButton) speechButton).setImageResource(R.drawable.ic_mic_off);

                speechButton.setEnabled(enabled);
                sendButton.setEnabled(enabled);
                inputEnabled = enabled;
            }
        }

        @Override
        public void onMoodChange(BaseConversation conversation, String newMood, String oldMood) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId()) && isAdded()){
                //TODO
            }
        }

        @Override
        public void outboundTextMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
                String hintText = ameliaOutboundMessage.getHintText();
                if (hintText != null) {
                    inputField.setHint(hintText);
                } else {
                    inputField.setHint(getContext().getResources().getString(R.string.chat_input_hint));
                }
            }
        }

        @Override
        public void outboundProgressTextMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void outboundIdleTalkMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void outboundAgentSessionChangedMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void wolframAlphaFinalMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void outboundFinalErrorMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void outboundConversationClosedMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void outboundIntegrationMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void outboundSessionClosedMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void outboundEchoMessage(BaseConversation conversation, IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void onUploadRequest(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
            if (ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                openFileChooser(ameliaOutboundMessage.getFromUserDisplayName(), ameliaOutboundMessage.getUploadMessage().getResourceToRequest().getSupportedFileExtensions().toString());
                notifyNewMessage();
            }
        }

        @Override
        public void onUploadSuccess(BaseConversation conversation,String fromUserDisplayName, String fileName, String url) {
            if(ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                int lastIndex = chatHistory.getRecords(conversation).size() - 1;
                adapter.notifyItemChanged(lastIndex);
            }
        }

        @Override
        public void onUploadFailed(BaseConversation conversation,String fromUserDisplayName, String fileName) {

        }

        @Override
        public void outboundFormInputMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
            if(ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                notifyNewMessage();
            }
        }

        @Override
        public void outboundMmoDownloadMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
            if(ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                IDownloadMessage downloadMessage = ameliaOutboundMessage.getDownloadMessage();
                if (isAdded() && downloadMessage.getError() == null) {
                    downloadMessage.download(new IDownloadListener() {

                        @Override
                        public void onDownloadFailed(IAmeliaError error) {
                            notifyNewMessage();
                        }

                        @Override
                        public void onDownloadSuccess(IDownloadedMmo mmo) {
                            notifyNewMessage();
                        }
                    }, getContext().getExternalCacheDir());
                }
            }
        }

        @Override
        public void outboundBpnExecutionEventMessage(BaseConversation conversation,IAmeliaOutboundMessage ameliaOutboundMessage) {
            if(ChatFragment.this.conversation.getConversationId().equals(conversation.getConversationId())) {
                BpnExecutionEvent.BpnProcessEvent event = ameliaOutboundMessage.getBpnExecutionEvent().getBpnProcessEvent();
                if (event == BpnExecutionEvent.BpnProcessEvent.PROCESS_ABORTED_EVENT) {
                    Log.w(TAG, "BPN crashed");
                }
            }
        }
    };


    private void askReconnectDialogue(String title, String message) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(getContext(), android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(getContext());
        }
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton(R.string.re_login, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        ameliaChat.logout();
                        dialog.dismiss();
                        getActivity().onBackPressed();
                        Intent intent = new Intent(getActivity(), LoginActivity.class);
                        startActivity(intent);
                    }
                })
                .setNegativeButton(getString(R.string.try_again_later), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        getActivity().onBackPressed();
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setCancelable(false)
                .show();
    }


    @Override
    public void onFormSubmitted(FormInputData form, String message) {
        ameliaChat.submitForm(conversation,form, message);
    }

    @Override
    public void requestPermission(ChatRecyclerViewAdapter.PermissionRequestCompletionListener listener) {
        this.extStorageWritePermissionListener = listener;
        if (Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M &&
                ContextCompat.checkSelfPermission(this.getActivity(),
                        Manifest.permission.READ_CONTACTS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    WRITE_EXTERNAL_STORAGE_PERMISSION);
        } else {
            listener.onPermissionGranted();
        }
    }

}
