package net.ipsoft.android.sdk.sampleApp;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.StrictMode;
import android.preference.PreferenceManager;

import net.ipsoft.android.sdk.sampleApp.chat.ChatHistory;

import net.ipsoft.amelia.sdk.AmeliaChatBuilder;
import net.ipsoft.amelia.sdk.DomainSelectionMode;
import net.ipsoft.amelia.sdk.IAmeliaChat;
import net.ipsoft.amelia.sdk.SpeechParams;
import net.ipsoft.amelia.sdk.internal.common.ALog;

import java.util.HashMap;
import java.util.Map;

public class AmeliaApplication extends Application {

    private IAmeliaChat ameliaChat;
    private ChatHistory chatHistory;
    private String domainCode;
    private static Context appContext;

    @Override
    public void onCreate() {

        super.onCreate();
        ALog.enabled = BuildConfig.DEBUG;
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        appContext = getApplicationContext();
    }

    public static Context getAppContext(){
        return appContext;
    }

    public IAmeliaChat getAmeliaChat() {
        return ameliaChat;
    }

    public ChatHistory getChatHistory() {
        return chatHistory;
    }
    //Manual domain selection by user
    public IAmeliaChat newAmeliaChat() {
        this.domainCode = null;
        chatHistory = new ChatHistory(this);

        ameliaChat = new AmeliaChatBuilder()
                .setContext(this)
                .setBaseUrl(getBaseUrl())
                .setDomainSelectionMode(DomainSelectionMode.manual)
                .addConversationListener(chatHistory)
                .addPinnedCertificate("ipsoft-v3-amelia-playgroundus.ipsoft.com","sha256/pvprdERQH4QA4sfdfj/vq2ta3xnM7MBV952HkYc2a+0=")
                .setSpeechParams(new SpeechParams(true))
                .build();
        return ameliaChat;
    }
    //Amelia chat with a pre-defined domain
    public IAmeliaChat newAmeliaChat(String domainCode){
        this.domainCode = domainCode;
        chatHistory = new ChatHistory(this);

        ameliaChat = new AmeliaChatBuilder()
                .setContext(this)
                .setBaseUrl(getBaseUrl())
                .setDomainSelectionMode(DomainSelectionMode.predefined)
                .setDomainCode("brian")
                .addConversationListener(chatHistory)
                .setIgnoreCertificateErrors(true)
                .setSpeechParams(new SpeechParams(true))
                .build();
        return ameliaChat;
    }

    public String getDomainCode(){
        return this.domainCode;
    }

    public String getBaseUrl() {
        String baseUrl = getString(R.string.base_url);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String userDefinedBaseUrl = sharedPreferences.getString(getString(R.string.key_base_url), "").trim();
        if (userDefinedBaseUrl != null && userDefinedBaseUrl.length() > 0) {
            Uri uri = Uri.parse(userDefinedBaseUrl);
            if (uri.getScheme() == null) {
                userDefinedBaseUrl = "https://" + userDefinedBaseUrl;
                sharedPreferences.edit().putString(getString(R.string.key_base_url), userDefinedBaseUrl).commit();
            }
            baseUrl = userDefinedBaseUrl;
        }
        return baseUrl;
    }
}
