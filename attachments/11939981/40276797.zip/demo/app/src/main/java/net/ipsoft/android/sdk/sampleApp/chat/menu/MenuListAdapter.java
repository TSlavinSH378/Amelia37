package net.ipsoft.android.sdk.sampleApp.chat.menu;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import net.ipsoft.android.sdk.sampleApp.AmeliaApplication;
import net.ipsoft.android.sdk.sampleApp.R;

import java.util.ArrayList;
import java.util.List;

public class MenuListAdapter extends BaseAdapter {
    private Context appContext;
    private List<MenuItem> items;
    private LayoutInflater inflater;
    private OnMenuListItemClickListener listener;

    public interface OnMenuListItemClickListener{
        void onMenuItemClick(MenuItem.MenuItemType itemType);
    }
    public MenuListAdapter(OnMenuListItemClickListener listener,boolean anonymousUser){
        appContext = AmeliaApplication.getAppContext();
        this.listener = listener;
        inflater = (LayoutInflater) appContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        populateMenuItems(anonymousUser);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).hashCode();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final MenuItem item = items.get(position);
        View view = convertView;
        ViewHolder holder = null;
        if(view == null){
            view = inflater.inflate(R.layout.menu_list_row,parent,false);
            holder = new ViewHolder((ViewGroup)view);
            view.setTag(holder);
        }else{
            holder = (ViewHolder)view.getTag();
        }
        holder.tvTitle.setText(item.getMenuText());
        holder.ivIcon.setImageResource(item.getIconDrawableId());
        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(listener!=null){
                    listener.onMenuItemClick(item.getType());
                }
            }
        });
        return view;
    }

    private void populateMenuItems(boolean anonymous){
        AmeliaApplication app = (AmeliaApplication)this.appContext;
        items = new ArrayList<>();
        MenuItem item = new MenuItem(R.drawable.reset_conversation,appContext.getString(R.string.reset_conversation), MenuItem.MenuItemType.RESET_CONVERSATION);
        items.add(item);
        if(app.getDomainCode()==null) {
            item = new MenuItem(R.drawable.select_domain, appContext.getString(R.string.select_domain), MenuItem.MenuItemType.SELECT_DOMAIN);
            items.add(item);
        }
        item = new MenuItem(R.drawable.live_agent,appContext.getString(R.string.live_agent), MenuItem.MenuItemType.LIVE_AGENT);
        items.add(item);
        item = new MenuItem(R.drawable.login_logout,appContext.getString(anonymous?R.string.login:R.string.logout),anonymous? MenuItem.MenuItemType.LOGIN: MenuItem.MenuItemType.LOGOUT);
        items.add(item);
    }

    static class ViewHolder {
        ImageView ivIcon;
        TextView tvTitle;
        View mView;
        public ViewHolder(ViewGroup vg){
            mView = vg;
            ivIcon = (ImageView)vg.findViewById(R.id.ivIcon);
            tvTitle = (TextView)vg.findViewById(R.id.tvTitle);
        }
    }
}
