package com.ipsoft.amelia.sampleapp

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import net.ipsoft.amelia.sdk.BaseSessionListener
import net.ipsoft.amelia.sdk.IAmeliaChat
import net.ipsoft.amelia.sdk.IAmeliaError
import net.ipsoft.amelia.sdk.ISessionInfo

class MainActivity : AppCompatActivity() {
    private val TAG = "MainActivity"
    private val SETTINGS_REEQUEST = 1001
    private var btnAnonymousChat: TextView? = null
    private var startButton: View? = null
    private var app: AmeliaApplication? = null
    private var ameliaChat: IAmeliaChat? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar = findViewById(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        btnAnonymousChat = findViewById(R.id.btn_anonymous) as TextView
        startButton = findViewById(R.id.start_button)
        startButton?.setOnClickListener {
            val app = application as AmeliaApplication
            app.newAmeliaChat()
            val intent = Intent(this@MainActivity, DomainActivity::class.java)
            intent.putExtra(Utils.LOGIN_TYPE, LoginType.LOGIN_TYPE_AUTH.ordinal)
            startActivity(intent)
        }
        btnAnonymousChat?.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@MainActivity, DomainActivity::class.java) as Intent?
            intent?.putExtra(Utils.LOGIN_TYPE, LoginType.LOGIN_TYPE_ANONYMOUS.ordinal)
            startActivity(intent)
        })
        createNewChat()
    }

    private fun createNewChat() {
        app = this.application as AmeliaApplication
        app?.newAmeliaChat()
        ameliaChat = app?.ameliaChat
        ameliaChat?.addSessionListener(sessionListener)
        ameliaChat?.initialize()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_settings -> {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivityForResult(intent,SETTINGS_REEQUEST)
                return true
            }
        }
        return false
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // Check if we came back from settings screen,re-init ameliaChat with new server url
        if (requestCode == SETTINGS_REEQUEST) {
            createNewChat()
        }
    }

    private val sessionListener = object : BaseSessionListener() {
        override fun sessionInitialized(sessionInfo: ISessionInfo?) {
            this@MainActivity.runOnUiThread {
                if (sessionInfo!!.isAnonymousAllowed) {//anonymous allowed on the server
                    btnAnonymousChat?.setVisibility(View.VISIBLE)
                } else {
                    btnAnonymousChat?.setVisibility(View.GONE)
                }
            }
        }

        override fun onSessionInitFail(error: IAmeliaError?) {
            Log.e(TAG, "Error:" + error!!.message)
        }
    }
}
