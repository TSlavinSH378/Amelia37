package com.ipsoft.amelia.sampleapp

import android.app.Application
import android.net.Uri
import android.preference.PreferenceManager

import net.ipsoft.amelia.sdk.AmeliaChatBuilder
import net.ipsoft.amelia.sdk.DomainSelectionMode
import net.ipsoft.amelia.sdk.IAmeliaChat
import net.ipsoft.amelia.sdk.internal.common.ALog
import android.os.StrictMode



class AmeliaApplication : Application() {

    var ameliaChat: IAmeliaChat? = null
        private set
    var chatHistory: ChatHistory? = null
        private set

    override fun onCreate() {
        super.onCreate()
        ALog.enabled = true
        val builder = StrictMode.VmPolicy.Builder()
        StrictMode.setVmPolicy(builder.build())
    }

    fun newAmeliaChat(): IAmeliaChat {
        chatHistory = ChatHistory()

        ameliaChat = AmeliaChatBuilder()
                .setContext(this)
                .setBaseUrl(baseUrl)
                .setDomainSelectionMode(DomainSelectionMode.manual)
                .addConversationListener(chatHistory)
                .setIgnoreCertificateErrors(true)
                .build()

        return ameliaChat!!
    }

    val baseUrl: String
        get() {
            var baseUrl = getString(R.string.base_url)
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
            var userDefinedBaseUrl: String? = sharedPreferences.getString(getString(R.string.key_base_url), "")!!.trim { it <= ' ' }
            if (userDefinedBaseUrl != null && userDefinedBaseUrl.length > 0) {
                val uri = Uri.parse(userDefinedBaseUrl)
                if (uri.scheme == null) {
                    userDefinedBaseUrl = "https://" + userDefinedBaseUrl
                    sharedPreferences.edit().putString(getString(R.string.key_base_url), userDefinedBaseUrl).commit()
                }
                baseUrl = userDefinedBaseUrl
            }
            return baseUrl
        }
}
