package com.ipsoft.amelia.sampleapp;

import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage;
import net.ipsoft.amelia.sdk.BaseConversationListener;

import java.util.ArrayList;
import java.util.List;

public class ChatHistory extends BaseConversationListener {

    private List<ChatRecord> chatRecords = new ArrayList<>();

    public List<ChatRecord> getRecords() {
        return chatRecords;
    }

    @Override
    public void onChatHistoryClear() {
        chatRecords.clear();
    }

    @Override
    public void outboundFinalTextMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundProgressTextMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundIdleTalkMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void wolframAlphaFinalMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundEchoMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundFinalErrorMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundConversationClosedMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundSessionClosedMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundIntegrationMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void outboundAgentSessionChangedMessage(IAmeliaOutboundMessage ameliaOutboundMessage) {
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }

    @Override
    public void onUploadRequest(IAmeliaOutboundMessage message) {
        chatRecords.add(new UploadChatRecord(message));
    }

    @Override
    public void outboundMmoDownloadMessage(IAmeliaOutboundMessage message) {
        chatRecords.add(new DownloadChatRecord(message));
    }

    @Override
    public void outboundFormInputMessage(IAmeliaOutboundMessage ameliaOutboundMessage){
        chatRecords.add(new ChatRecord(ameliaOutboundMessage));
    }
}
