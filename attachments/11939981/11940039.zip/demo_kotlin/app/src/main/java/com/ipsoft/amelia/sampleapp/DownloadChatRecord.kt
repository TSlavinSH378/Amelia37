package com.ipsoft.amelia.sampleapp

import net.ipsoft.amelia.sdk.IAmeliaOutboundMessage
import net.ipsoft.amelia.sdk.IDownloadMessage

/**
 * A specific chat record for MMO downloads
 */
class DownloadChatRecord(message: IAmeliaOutboundMessage) : ChatRecord(message) {

    val downloadMessage: IDownloadMessage

    init {
        downloadMessage = message.downloadMessage
    }

}
