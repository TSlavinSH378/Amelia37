package com.ipsoft.amelia.sampleapp.accordion;

import android.util.JsonWriter;

import org.json.JSONObject;

import java.io.IOException;

public class SectionField {
    protected String name = null;
    protected String label = null;
    protected String valueForDisplay = null;
    protected String value = null;

    public String getName() {
        return name;
    }

    public String getLabel() {
        return label;
    }

    public String getValueForDisplay() {
        return valueForDisplay;
    }

    public String getValue() {
        return value;
    }

    public void serialize(JsonWriter jsonWriter) throws IOException {
        jsonWriter.beginObject();
        if (name != null) {
            jsonWriter.name("name");
            jsonWriter.value(name);
        }
        if (label != null) {
            jsonWriter.name("label");
            jsonWriter.value(label);
        }
        if (valueForDisplay != null) {
            jsonWriter.name("valueForDisplay");
            jsonWriter.value(valueForDisplay);
        }
        if (value != null) {
            jsonWriter.name("value");
            jsonWriter.value(value);
        }
        jsonWriter.endObject();
    }

    public static SectionField deserialize(JSONObject jsonObject) {
        SectionField sectionField = new SectionField();
        sectionField.name = jsonObject.optString("name");
        sectionField.label = jsonObject.optString("label");
        sectionField.valueForDisplay = jsonObject.optString("valueForDisplay");
        sectionField.value = jsonObject.optString("value");
        return sectionField;
    }
}
