//
//  IPSAKAppConfig.h
//  AmeliaKit
//
//  Created by Yulong Yang on 1/29/18.
//  Copyright © 2018 IPsoft. All rights reserved.
//

#import <AmeliaKit/AmeliaKit.h>

@interface IPSAKAppConfig : IPSAKObject
/**
 user logged in or not
 */
@property (nonatomic, readonly) BOOL loggedIn;
/**
 whether anonymous user is allowed on this server
 */
@property (nonatomic,readonly) BOOL allowAnonymous;
/**
 csrf session token
 */
@property (copy, nonatomic,readonly) NSString *csrfToken;
/**
 anonymous user object. If anonymous user is not allowed, this field will be nil
 */
@property (copy, nonatomic,readonly) IPSAKUser *user;
/**
 */
@property (copy,nonatomic,readonly) NSArray<IPSAKDomain*>* allDomains;
@end
