//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol IPSConversationMessageData;

@interface IPSConversationBubbleCell : UICollectionViewCell

+ (void)registerInCollectionView:(UICollectionView *)collectionView;

+ (instancetype)dequeueCellInCollectionView:(UICollectionView *)collectionView forIndexPath:(NSIndexPath *)indexPath;

+ (instancetype)sizingCell;

- (void)configure:(id<IPSConversationMessageData>)message;

- (void)applyMaskWithSmallCorner:(UIRectCorner)smallCorner;

- (CGSize)preferredLayoutSizeFittingSize:(CGSize)size;

@property (nonatomic, readonly) BOOL shadowOutline;

@end
