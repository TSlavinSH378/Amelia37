//
//  IPSAKEscalationAlert.h
//  AmeliaKit
//
//  Created by Yulong Yang on 12/18/18.
//  Copyright © 2018 IPsoft. All rights reserved.
//

#import "IPSAKObject.h"
typedef NS_ENUM(NSInteger, IPSAKAvailabilityType) {
    AWAY,
    READY,
    BUSY,
    OFFLINE,
};

@interface IPSAKEscalationAlert : IPSAKObject
@property (nonatomic,strong) NSString* escalationRequestId;
@property (nonatomic,strong) NSString* details;
@property (nonatomic) int effectiveTimeout;
@property (nonatomic) BOOL updateAvailability;
@property (nonatomic) IPSAKAvailabilityType availability;
@property (nonatomic) BOOL webApiNotificationEnabled;
@end

