//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol IPSChatInputToolbarDelegate;

@interface IPSChatInputToolbar : UIView

@property (weak, nonatomic) IBOutlet id<IPSChatInputToolbarDelegate> delegate;

@property (weak, nonatomic, readonly) UITextField *textField;

@property (nonatomic) BOOL inputEnabled;

- (void)clearText;

@end

@protocol IPSChatInputToolbarDelegate <NSObject>
- (void)chatInputToolBar:(IPSChatInputToolbar *)toolbar sendText:(NSString *)text;
@optional
- (void)chatInputToolBarDidLongPress:(IPSChatInputToolbar *)toolbar;
@end

