//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSLoginViewController.h"
#import "NSUserDefaults+Amelia.h"
#import "Styling.h"

@interface IPSLoginViewController () <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *usernameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
@property (strong, nonatomic) UIBarButtonItem *loginButton;
@property (strong, nonatomic) UIBarButtonItem *backButton;
@end

@implementation IPSLoginViewController

+ (instancetype)loginViewController {
    return [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"loginViewController"];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    self.usernameTextField.text = userDefaults.ips_username;
    self.passwordTextField.text = userDefaults.ips_password;
    self.passwordTextField.delegate = self;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField == self.passwordTextField) {
        [textField resignFirstResponder];
        NSLog(@"return key after the password.");
        [self loginTap:self];
        return NO;
    }
    return YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.usernameTextField.enabled = YES;
    self.passwordTextField.enabled = YES;
    [self updateLoginButtonStatus];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.usernameTextField becomeFirstResponder];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.usernameTextField resignFirstResponder];
    [self.passwordTextField resignFirstResponder];
}


- (UIBarButtonItem *)loginButton {
    if (_loginButton == nil) {
        _loginButton = [[UIBarButtonItem alloc] initWithTitle:@"Log in" style:UIBarButtonItemStylePlain target:self action:@selector(loginTap:)];
    }
    return _loginButton;
}

- (UIBarButtonItem *)backButton {
    if (_backButton == nil) {
        _backButton = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(backTap:)];
    }
    return _backButton;
}

- (void)loginTap:(id)sender {
    [self.usernameTextField resignFirstResponder];
    [self.passwordTextField resignFirstResponder];
    self.loginButton.enabled = NO;
    self.usernameTextField.enabled = NO;
    self.passwordTextField.enabled = NO;
    [self.delegate loginViewController:self loginWithUsername:self.usernameTextField.text password:self.passwordTextField.text];
}


- (IBAction)textFieldChange:(id)sender {
    [self updateLoginButtonStatus];
}

- (void)updateLoginButtonStatus {
    self.loginButton.enabled = self.usernameTextField.text.length > 0 && self.passwordTextField.text.length > 0;
    
}

- (void)updateBackButtonStatus {
    self.backButton.enabled = true;
    
}

- (void)presentError:(NSError *)error {
    NSString *message = [NSString stringWithFormat:@"%@", error.localizedDescription];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.usernameTextField.enabled = YES;
            self.passwordTextField.enabled = YES;
            [self.usernameTextField becomeFirstResponder];
            [self updateLoginButtonStatus];
        });
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)loginFailWithError:(NSError *)error {
    [self presentError:error];
}

- (void)backTap:(id)sender {
    NSLog(@"close the login window.");
    [self.delegate backToMain: self];
}


@end
