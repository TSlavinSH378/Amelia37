//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAKMessage.h"
NS_ASSUME_NONNULL_BEGIN

/**
 The `IPSAKDownloadedMMO` class combines the downloaded file content with the MIMEType.
 */
@interface IPSAKDownloadedMMO : NSObject

/**
 The mime type of the fetched content.
 
 @note This is the MIMEType specified in the HTML response when downloading a file.
 */
@property (copy, nonatomic, readonly) NSString *MIMEType;
/**
 The fetched content.
 */
@property (strong, nonatomic, readonly) NSData *content;

@end

/**
 The `IPSAKDownloadMessage` class represents a multimedia message received from Amelia. An MMO-message is special since it requires that at least one additional request is made to complete the object. In constrast, An ordinary `IPSAKMessage` does not require additional requests.
 
 When the download message is received from Amelia, it contains information related to the multi-media resource, such as filename, bucket ID, and display style such as INLINE_ONLY or INLINE_AND_POPUP, etc. However, to get multi-media resource file content, it will require an addition request to download the resource and retrieve them from the IPSAKDownloadedMMO object.
 
*/
@interface IPSAKDownloadMessage : NSObject

/**
 If non-nil contains the latest error when trying to fetch meta-data or file content.
 */
@property (nullable, nonatomic, strong) NSError *error;
/**
 detailed information about how to present this resource
 */
@property (nonatomic,strong,readonly) IPSAKResourceMetaData *resourceInfo;
/**
 Initializes the object using the given message.
 
 @param message An message containing the resource meta data
 @param error If an error occurs, this pointer is set to an `NSError` containing information about the error.
 */
- (instancetype _Nullable)initWithMessage:(IPSAKMessage *)message error:(NSError **)error;

/**
 Downloads the file if `contentType == IPSAKDownloadMessageContentTypeFile`, otherwise the completionHandler will be called with (nil, nil) as parameters.
 */
- (void)download:(void (^)(IPSAKDownloadedMMO *content, NSError *error))completionHandler;

@end

NS_ASSUME_NONNULL_END
