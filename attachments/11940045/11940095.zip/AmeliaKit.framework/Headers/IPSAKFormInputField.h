//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAKFormInputFieldOptions.h"
#import "IPSAKObject.h"

/**
 The `IPSAKFormInputField` represents an input field.
 */
@interface IPSAKFormInputField : IPSAKObject

/**
 The name of this form field.
 */
@property(copy, nonatomic, readonly) NSString *name;
/**
 The type of this form field; note that this is an arbitrary string set in the BPN; the client code is responsible for handling all possible types.
 */
@property(copy, nonatomic, readonly) NSString *fieldType;
/**
 The options available, e.g. for widgets that demand it, such as banks of checkboxes or radio buttons.
 */
@property(copy, nonatomic, readonly) NSArray<IPSAKFormInputFieldOptions *> *options;

@end
