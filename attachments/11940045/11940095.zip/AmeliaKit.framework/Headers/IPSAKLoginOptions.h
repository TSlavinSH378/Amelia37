//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class IPSAKAuthSystem;

/**
 The `IPSAKLoginOptions` class provides the options needed when logging in to Amelia.
 */
@interface IPSAKLoginOptions : NSObject

/**
 Initializes and returns a login options object with the provided auth system, username, and password.
 */
- (instancetype)initWithUsername:(NSString *)username password:(NSString *)password;

/**
 Initializes and returns a login options object with the provided auth system, username, and password.
 */
- (instancetype)initWithAuthSystem:(IPSAKAuthSystem *)authSystem
                          username:(NSString *)username
                          password:(NSString *)password;
/**
 Initialized and returns a login options object with the provided auth system and session cookie.
 */
- (instancetype)initWithAuthSystem:(IPSAKAuthSystem *)authSystem sessionCookie:(NSHTTPCookie *)cookie;

/// The auth system used for the login
@property (nullable, strong, nonatomic, readonly) IPSAKAuthSystem *authSystem;
/// Username
@property (copy, nonatomic, readonly) NSString *username;
/// Password
@property (copy, nonatomic, readonly) NSString *password;
/// A session cookie obtained from a SAML login.
@property (strong, nonatomic, readonly) NSHTTPCookie *sessionCookie;

@end

NS_ASSUME_NONNULL_END
