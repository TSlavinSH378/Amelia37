//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class IPSAKMessage;

/**
 Constants indicating which type of file is expected.
 */
typedef NS_ENUM(NSInteger, IPSAKUploadFileType) {
    /**
     The file type could not be mapped to the enum. See `fileTypeString` to get the underlying file type.
     */
    IPSAKUploadFileTypeUnknown,
    /**
     Amelia expects an image to be uploaded.
     */
    IPSAKUploadFileTypeImage,
};

/**
 The `IPSAKUploadMessage` class contains information about what kind of file Amelia expects.
 */
@interface IPSAKUploadMessage : NSObject

/**
 Initializes the object using the given message.
 
 @param message An message containing the magic string indicating an upload request.
 @param error If an error occurs, this pointer is set to an `NSError` containing information about the error.
 */
- (instancetype _Nullable)initWithMessage:(IPSAKMessage *)message error:(NSError **)error;

/**
 The type of file that should be uploaded.
 
 @note If `fileType == IPSAKUploadFileTypeUnknown` the file type could not be mapped and the file type text can be obtained from `fileTypeString`.
 */
@property (nonatomic, readonly) IPSAKUploadFileType fileType;
/**
 The text representation of the file type.
 */
@property (copy, nonatomic, readonly) NSString *fileTypeString;

@end

NS_ASSUME_NONNULL_END
