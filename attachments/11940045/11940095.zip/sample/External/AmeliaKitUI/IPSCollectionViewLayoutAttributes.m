//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSCollectionViewLayoutAttributes.h"

@implementation IPSCollectionViewLayoutAttributes

- (id)copyWithZone:(nullable NSZone *)zone {
    IPSCollectionViewLayoutAttributes *copy = [super copyWithZone:zone];
    copy.origin = self.origin;
    copy.rowType = self.rowType;
    copy.maxBubbleWidth = self.maxBubbleWidth;
    return copy;
}

@end
