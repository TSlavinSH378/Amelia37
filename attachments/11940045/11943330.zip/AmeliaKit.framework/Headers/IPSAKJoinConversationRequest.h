//
//  IPSAKJoinConversationRequest.h
//  AmeliaKit
//
//  Created by Yulong Yang on 1/25/19.
//  Copyright © 2019 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IPSAKObject.h"

NS_ASSUME_NONNULL_BEGIN

@interface IPSAKJoinConversationRequest : IPSAKObject
@property (nonatomic,strong) NSString *conversationId;
@property (nonatomic,strong) NSString *fromUserDisplayName;
@property (nonatomic,strong) NSString *messageText;
@property (nonatomic,strong) NSString *sessionMode;
@property (nonatomic) BOOL autoSwitch;

@end

NS_ASSUME_NONNULL_END
