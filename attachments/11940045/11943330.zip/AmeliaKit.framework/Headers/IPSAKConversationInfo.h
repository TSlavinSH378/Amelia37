//
//  IPSAKConversationInfo.h
//  AmeliaKit
//
//  Created by Yulong Yang on 2/19/19.
//  Copyright © 2019 IPsoft. All rights reserved.
//

#import <AmeliaKit/AmeliaKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IPSAKConversationInfo : IPSAKObject
-(instancetype)initWithConversationId:(NSString*)conversationId domainId:(NSString*)domainId lastAccessed:(NSDate*)lastAccessed andSessionMode:(NSString*)sessionMode;
@property (nonatomic,readonly,copy) NSString *conversationId;
@property (nonatomic,readonly,copy) NSString *domainId;
@property (nonatomic,readonly,strong) NSDate *lastAccessed;
@property (nonatomic,readonly,copy) NSString *sessionMode;
@end

NS_ASSUME_NONNULL_END
