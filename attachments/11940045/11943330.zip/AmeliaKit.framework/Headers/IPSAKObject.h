//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Helper function to get a string value from a dictionary and set an error if the key is missing.
 
 @note The value returned is either an `NSString` instance or nil. The value is converted to a `NSString` if it is 
 something else.
 
 @param dictionary The dictionary to check.
 @param key The required key.
 @param error If the passed in dictionary doesn't contain the required key an `NSError` object with code
 `IPSAKErrorRequiredFieldMissing` that indicates the missing key.
 
 @return A `NSString` or nil if the key couldn't be found in the dictionary.
 */
extern NSString *_Nullable IPSAsString(NSDictionary *dictionary, NSString *key, NSError **error);

/**
 The `IPSAKObject` class is the base object for JSON-backed responses. Should not be used directly.
 */
@interface IPSAKObject : NSObject

/**
 Equivalent to calling `objectsFromJSON:error:` with nil as the error parameter.
 */
+ (NSArray *_Nullable)objectsFromJSON:(NSArray<NSDictionary *> *)array;
/**
 Create an array of objects by looping over the array and calling `initWithJSON:error:` with each item in the array. If any objects fails to be created, `nil` is returned the error is set to the error of the first failed creation.
 
 @param array An array of `NSDictionary` objects.
 @param error If an error occurs, this pointer is set to an `NSError` containing information about the error.
 */
+ (NSArray *_Nullable)objectsFromJSON:(NSArray<NSDictionary *> *)array error:(NSError **_Nullable)error;

/**
 Equivalent to calling `initWithJSON:error:` with nil as the error parameter.
 */
- (instancetype _Nullable)initWithJSON:(NSDictionary *)dictionary;
/**
 Initializes the object with the given `NSDictionary`.
 
 @param dictionary An `NSDictionary` instance.
 @param error If an error occurs, this pointer is set to an `NSError` containing information about the error.
 */
- (instancetype _Nullable)initWithJSON:(NSDictionary *)dictionary error:(NSError **_Nullable)error;

@end

NS_ASSUME_NONNULL_END
