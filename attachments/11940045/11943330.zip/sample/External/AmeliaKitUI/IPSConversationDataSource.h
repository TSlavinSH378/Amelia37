//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol IPSConversationMessageData;
@protocol IPSConversationDataSourceDelegate;

@interface IPSConversationDataSource : NSObject

@property (weak, nonatomic) id<IPSConversationDataSourceDelegate> delegate;

@property (readonly) NSInteger messageCount;

- (void)suppressUpdates:(void(^)(IPSConversationDataSource *dataSource))block;

- (void)addMessage:(id<IPSConversationMessageData>)message;

- (void)addSpinner;

- (void)removeSpinner;

- (void)removeMessage:(id<IPSConversationMessageData>)message;

- (void)removeAllMessages;

- (NSInteger)numberOfSections;

- (NSInteger)numberOfItemsInSection:(NSInteger)section;

- (id<IPSConversationMessageData>)messageAtIndexPath:(NSIndexPath *)indexPath;

- (id<IPSConversationMessageData>)lastMessage;

@end

@protocol IPSConversationDataSourceDelegate <NSObject>
- (void)conversationDataSourceDidReload:(IPSConversationDataSource *)dataSource;
- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didInsertSections:(NSIndexSet *)sections;
- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didInsertItemsAtIndexPath:(NSArray<NSIndexPath *> *)indexPaths;
- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didDeleteSections:(NSIndexSet *)sections;
- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didDeleteItemsAtIndexPath:(NSArray<NSIndexPath *> *)indexPaths;
- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didReloadItemsAtIndexPath:(NSArray<NSIndexPath *> *)indexPaths;
@end
