//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationForm.h"
#import "IPSConversationSimpleFormCell.h"

@interface IPSConversationFormAction ()
@property (nullable, nonatomic) NSString *title;
@property (nonatomic) IPSConversationFormActionStyle style;
@property (nullable, nonatomic) id content;
@property (copy) void(^handler)(IPSConversationFormAction *);
@end

@implementation IPSConversationFormAction

+ (instancetype)actionWithTitle:(nullable NSString *)title content:(nullable id)content style:(IPSConversationFormActionStyle)style handler:(void(^ __nullable)(IPSConversationFormAction *action))handler {
    IPSConversationFormAction *action = [[IPSConversationFormAction alloc] init];
    action.title = title;
    action.style = style;
    action.content = content;
    action.handler = handler;
    return action;
}

- (void)actionTap:(id)sender {
    void(^handler)(IPSConversationFormAction *) = self.handler;
    if (handler) {
        handler(self);
    }
}

@end

@interface IPSConversationForm()
@property (copy) NSString *text;
@property (strong) NSMutableArray *customActions;
@end

@implementation IPSConversationForm

- (instancetype)initWithText:(NSString *)text {
    self = [super init];
    if (self) {
        _text = text;
        _messageType = IPSConversationMessageTypeForm;
        _customActions = [NSMutableArray array];
    }
    return self;
}

- (NSArray<IPSConversationFormAction *> *)actions {
    return self.customActions;
}

- (void)addAction:(id)action {
    [self.customActions addObject:action];
}

- (void)addActionWithTitle:(nullable NSString *)title content:(nullable id)content style:(IPSConversationFormActionStyle)style handler:(void(^ __nullable)(IPSConversationFormAction *action))handler {
    __weak __typeof__(self) weakSelf = self;
    IPSConversationFormAction *action = [IPSConversationFormAction actionWithTitle:title content:content style:style handler:^(IPSConversationFormAction *action) {
        if (handler != nil) {
            handler(action);
        }
        
        if (weakSelf.multipleSelection) {
            action.button.selected = !action.button.selected;
        }
        
        if (!weakSelf.multipleSelection || action.submit) {
            [weakSelf.delegate conversationFormDidUpdate:weakSelf action:action];
        }
    }];
    [self addAction:action];
}

- (NSInteger)actionCount {
    return self.customActions.count;
}
- (id)mediaContent {
    return nil;
}

@end
