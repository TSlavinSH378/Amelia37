//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAccordionHeaderView.h"
#import "IPSAccordionViewController.h"

@interface IPSAccordionHeaderView ()
@property (weak, nonatomic) IBOutlet UIButton *editButton;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong) IPSAccordionSection *section;
@end

@implementation IPSAccordionHeaderView

- (void)configure:(IPSAccordionSection *)section {
    self.titleLabel.text = section.title;
    self.section = section;
}


- (IBAction)editTap:(id)sender {
    self.onEditTap(self.section);
}

@end
