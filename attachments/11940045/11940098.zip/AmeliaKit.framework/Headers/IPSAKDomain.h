//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAKObject.h"

/**
 The `IPSAKDomain` class represents a conversation domain.

 @note This encapsulates the response from `conversation/domains`.
 */

@interface IPSAKDomain : IPSAKObject

/**
 Code used to identify a domain when starting a new conversation.
 */
@property(copy, nonatomic, readonly) NSString *code;
/**
 Display name of domain.
 */
@property(copy, nonatomic, readonly) NSString *name;
/**
 The formal locale name.
 */
@property(copy, nonatomic, readonly) NSString *localeLanguageTag;
/**
 UI friendly locale display name.
 */
@property(copy, nonatomic, readonly) NSString *localeDisplayName;
/**
 Unique (within an organization) identifier of this domain.
 */
@property(nonatomic, readonly) NSInteger domainId;
/**
 A hidden domain should not be selectable.
 */
@property(nonatomic, readonly) BOOL hidden;
/**
 Whether the domain requires a login.
 */
@property(nonatomic, readonly) BOOL requireLogin;

@end
