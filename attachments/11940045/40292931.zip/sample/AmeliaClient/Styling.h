//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#ifndef Styling_h
#define Styling_h

#import "UIFont+IPSAdditions.h"
#import "UIColor+IPSAdditions.h"
#import "UINavigationBar+IPSAdditions.h"

#endif /* Styling_h */
