//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSSessionViewController.h"
#import "IPSChatViewController.h"
#import "IPSDomainListViewController.h"
#import "Styling.h"
#import <AmeliaKit/AmeliaKit.h>

@interface IPSSessionViewController () <IPSDomainListViewContollerDelegate,
                                        IPSChatViewControllerDelegate>
@property (strong, nonatomic) IPSDomainListViewController *domainListViewController;
@end

@implementation IPSSessionViewController

+ (instancetype)sessionViewController {
    return [[UIStoryboard storyboardWithName:@"Session" bundle:nil] instantiateViewControllerWithIdentifier:@"sessionViewController"];

}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Choose a domain";
    
    [self.navigationController.navigationBar ips_makeTransparent];
    self.view.backgroundColor = [UIColor colorWithWhite:250/255. alpha:1];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Log out" style:UIBarButtonItemStylePlain target:self action:@selector(logoutTap:)];
    [self updateStepUpButton];
    
    {
        self.domainListViewController = [IPSDomainListViewController domainListViewController];
        self.domainListViewController.delegate = self;
        self.domainListViewController.modalPresentationStyle = UIModalPresentationFullScreen;
        [self addChildViewController:self.domainListViewController];
        [self.view addSubview:self.domainListViewController.view];
        [self.domainListViewController didMoveToParentViewController:self];
    }
}

- (void)setUser:(IPSAKUser *)user {
    _user = user;
    [self updateStepUpButton];
}

- (void)updateStepUpButton {
    if (self.user != nil && self.user.anonymous) {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Login" style:UIBarButtonItemStylePlain target:self action:@selector(stepUpTap:)];
    } else {
        self.navigationItem.leftBarButtonItem = nil;
    }
    
}

- (void)logoutTap:(id)sender {
    [self.delegate sessionViewControllerDidTapLogoutButton:self];
}

- (void)stepUpTap:(id)sender {
    [self.delegate sessionViewControllerDidTapStepUpButton:self];
}

- (void)sessionFailWithError:(NSError *)error {
    // whoami failed – if network error show retry screen, otherwise present error and go back to root
    NSLog(@"%s", __PRETTY_FUNCTION__);
}

- (void)domainSelectionRequired:(NSArray<IPSAKDomain *> *)domains {
    NSLog(@"%s", __PRETTY_FUNCTION__);
    [self.domainListViewController showDomains:domains];
}

- (void)domainFailWithError:(NSError *)error {
    // Fetching domais failed - if network error show retry screen, otherwise present error and go back to root
    NSLog(@"%s", __PRETTY_FUNCTION__);
}

- (void)conversation:(IPSAKConversation*)conversation startWithChat:(IPSAKChat *)chat {
    // Present the chat. Transition depends on whether viewHasAppeared or if the domain selection list is showing.
    NSLog(@"%s", __PRETTY_FUNCTION__);
    
    IPSChatViewController *chatViewController = [IPSChatViewController chatViewController:chat conversation:conversation];
    chatViewController.delegate = self;
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:chatViewController];
    navigationController.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)conversationFailWithError:(NSError *)error {
    // Start conversation failed - if network error show retry screen, otherwise present error. if domain list visible we could stay here, otherwise go back to root
    NSLog(@"%s", __PRETTY_FUNCTION__);
}

#pragma mark -

- (void)domainListViewController:(IPSDomainListViewController *)controller didSelectDomain:(IPSAKDomain *)domain {
    [self.delegate sessionViewController:self didSelectDomain:domain];
}

#pragma mark - 

- (void)chatViewControllerDidClose:(IPSChatViewController *)controller {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
