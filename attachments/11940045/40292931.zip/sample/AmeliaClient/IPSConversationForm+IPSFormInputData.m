//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationForm+IPSFormInputData.h"
#import <AmeliaKit/AmeliaKit.h>

@implementation IPSConversationForm (IPSAKFormInputData)

+ (instancetype)conversationFormWithFormInputData:(IPSAKFormInputData *)formInputData {
    IPSConversationForm *form = [[IPSConversationForm alloc] initWithText:formInputData.nameForDisplay];
    form.content = formInputData;
    
    for (IPSAKFormInputField *field in formInputData.fields) {
        
        if (field.options.count > 0) {
            for (IPSAKFormInputFieldOptions *option in field.options) {
                [form addActionWithTitle:option.name content:option style:IPSConversationFormActionStyleDefault handler:^(IPSConversationFormAction *action) {
                    option.selected = !option.selected;
                }];
            }
            
            if ([field.fieldType isEqualToString:@"multipleSelection"]) {
                form.multipleSelection = YES;
                [form addActionWithTitle:@"Submit" content:field style:IPSConversationFormActionStyleSubmit handler:^(IPSConversationFormAction *action) {
                    action.submit = YES;
                }];
            }
        } else {
            IPSConversationFormActionStyle style = [field.fieldType isEqualToString:@"cancelButton"] ? IPSConversationFormActionStyleCancel : IPSConversationFormActionStyleDefault;
            [form addActionWithTitle:field.name content:field style:style handler:^(IPSConversationFormAction *action) {
                action.submit = YES;
            }];
        }
        
    }
    
    return form;
}

@end
