//
//  IPSAKBpnExecutionEvent.h
//  AmeliaKit
//
//  Created by Yulong Yang on 3/8/18.
//  Copyright © 2018 IPsoft. All rights reserved.
//

#import <AmeliaKit/AmeliaKit.h>
/**
 BPN Process events
 */
typedef NS_ENUM(NSInteger, IPSAKBpnProcessEvent) {
    PROCESS_STARTED_EVENT,
    TASK_STARTED_EVENT,
    TASK_COMPLETION_EVENT,
    PROCESS_SUSPENDED_EVENT,
    PROCESS_RESUMED_EVENT,
    PROCESS_ABORTED_EVENT,
    PROCESS_COMPLETED_EVENT
};
/**
 Bpn execution event detail
 */
@interface IPSAKBpnExecutionEvent : IPSAKObject
/**
 Bpn execution event  Id
 */
@property (nonatomic,copy,readonly) NSString *eventId;
/**
 Enum indicating the event type
 */
@property (nonatomic,assign, readonly) IPSAKBpnProcessEvent bpnProcessEvent;
@end
