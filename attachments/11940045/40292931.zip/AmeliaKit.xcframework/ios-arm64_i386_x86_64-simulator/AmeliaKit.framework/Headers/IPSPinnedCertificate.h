//
//  IPSPinnedCertificate.h
//  AmeliaKit
//
//  Created by Yulong Yang on 8/18/20.
//  Copyright © 2020 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/**
  A class that encapsulates information about a pinned certificate
 */
@interface IPSPinnedCertificate : NSObject
/**
   Domain name to match.
   Example: www.xyz.com to match host name or *.xyz.com to match any host with domain of xyz.com
 */
@property (nonatomic,copy) NSString* domainName;
/**
      base64 encoded public key hash.
 Suppoerted hash algorithm: SHA256 and SHA1
 Example:
  sha256/pvprdERQH3AL4sfdfj/vq2ta3xnM7MBV952HkYc2a+0=
  sha1/pvprdERQH3AL4sfdfj/vq2ta3xnM7
 */
@property (nonatomic,copy) NSString* publicKeyHash;
/**
  @param domain domain of the Amelia server
   @param hash hash of the public key. Either sha256 or sha1. Example: sha256/pvprdERQH3AL4sfdfj/vq2ta3xnM7MBV952HkYc2a+0=
 */
+(instancetype) initWithDomain:(NSString*)domain publicKeyHash:(NSString*)hash;

@end

NS_ASSUME_NONNULL_END
