//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IPSConversationMessageData.h"

@interface IPSConversationMessage : NSObject <IPSConversationMessageData>

- (instancetype)initWithText:(NSString *)text;

- (instancetype)initWithHtmlText:(NSAttributedString *)attributedText;

- (instancetype)initWithMedia:(id)media;

- (instancetype)initWithPdfData:(id)pdfData;

- (instancetype)initWithInformationText:(NSString *)informationText;

@property IPSConversationMessageOrigin origin;

@property IPSConversationMessageType messageType;

@property (copy, readonly) NSString *text;

@property (copy,readonly) NSAttributedString *attributedText;

@property (strong) id content;

@end
