//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationSpinnerCell.h"
#import "Styling.h"
@interface IPSConversationSpinnerCell ()
@property (weak, nonatomic) IBOutlet UIView *cellContentView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@end

@implementation IPSConversationSpinnerCell

+ (void)registerInCollectionView:(UICollectionView *)collectionView {
    [collectionView registerNib:[UINib nibWithNibName:@"IPSConversationSpinnerCell" bundle:nil] forCellWithReuseIdentifier:@"spinnerCell"];
}

+ (instancetype)dequeueCellInCollectionView:(UICollectionView *)collectionView forIndexPath:(NSIndexPath *)indexPath {
    return [collectionView dequeueReusableCellWithReuseIdentifier:@"spinnerCell" forIndexPath:indexPath];
}

+ (instancetype)sizingCell {
    return [[UINib nibWithNibName:@"IPSConversationSpinnerCell" bundle:nil] instantiateWithOwner:nil options:nil].firstObject;
}

- (CGSize)preferredLayoutSizeFittingSize:(CGSize)size {
    return CGSizeMake(42, 22);
}

- (void)configure:(id<IPSConversationMessageData>)message {
    self.cellContentView.backgroundColor = [UIColor ips_paleGreyColor];
}

@end
