//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AmeliaKit/AmeliaKit.h>

@interface UIImage (AvatarImage)

+ (UIImage *)ips_smallAvatarImageForMood:(IPSAKMoodType)mood;

@end
