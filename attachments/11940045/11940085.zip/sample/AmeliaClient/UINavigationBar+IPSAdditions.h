//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (IPSAdditions)

- (void)ips_makeTransparent;

@end
