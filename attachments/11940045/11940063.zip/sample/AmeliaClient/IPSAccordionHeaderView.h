//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IPSAccordionSection;

@interface IPSAccordionHeaderView : UITableViewHeaderFooterView

- (void)configure:(IPSAccordionSection *)section;

@property (copy) void(^onEditTap)(IPSAccordionSection *section);

@end
