//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IPSSettingsViewController : UITableViewController

+ (instancetype)settingsViewController;

@end
