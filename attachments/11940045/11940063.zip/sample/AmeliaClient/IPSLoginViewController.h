//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol IPSLoginViewControllerDelegate;

@interface IPSLoginViewController : UITableViewController

+ (instancetype)loginViewController;

@property (weak, nonatomic) id<IPSLoginViewControllerDelegate> delegate;

@property (strong, nonatomic, readonly) UIBarButtonItem *loginButton;
@property (strong, nonatomic, readonly) UIBarButtonItem *backButton;


- (void)presentError:(NSError *)error;

- (void)loginFailWithError:(NSError *)error;

@end

@protocol IPSLoginViewControllerDelegate <NSObject>
- (void)loginViewController:(IPSLoginViewController *)controller loginWithUsername:(NSString *)username password:(NSString *)password;
- (void)backToMain:(IPSLoginViewController *)controller;
@end
