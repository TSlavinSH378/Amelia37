//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationViewController.h"
#import "IPSConversationBubbleCell.h"
#import "IPSConversationCollectionViewLayout.h"
#import "IPSConversationDataSource.h"
#import "IPSConversationMediaCell.h"
#import "IPSConversationMessageData.h"
#import "IPSConversationSimpleFormCell.h"
#import "IPSConversationSpinnerCell.h"
#import "IPSConversationTextCell.h"
#import "IPSConversationHtmlContentCell.h"

@interface IPSConversationViewController () <IPSConversationCollectionViewLayoutDelegate, IPSConversationDataSourceDelegate>
@property (strong) IPSConversationTextCell *sizingTextCell;
@property (strong) IPSConversationSimpleFormCell *sizingFormCell;
@property (strong) IPSConversationSpinnerCell *sizingSpinnerCell;
@property (strong) IPSConversationHtmlContentCell *sizingWebContentCell;
@end

@implementation IPSConversationViewController

- (instancetype)init {
    self = [super initWithCollectionViewLayout:[[IPSConversationCollectionViewLayout alloc] init]];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    IPSConversationCollectionViewLayout *layout = [[IPSConversationCollectionViewLayout alloc] init];
//    layout.estimatedItemSize = CGSizeMake(300, 44);
    layout.sectionInset = UIEdgeInsetsMake(10, 12, 10, 12);
    layout.minimumLineSpacing = 4;
//    layout.minimumInteritemSpacing = 375;
    
    self.collectionView.collectionViewLayout = layout;
    self.collectionView.alwaysBounceVertical = YES;
    
    // registerCells
    [IPSConversationTextCell registerInCollectionView:self.collectionView];
    [IPSConversationSimpleFormCell registerInCollectionView:self.collectionView];
    [IPSConversationSpinnerCell registerInCollectionView:self.collectionView];
    [IPSConversationMediaCell registerInCollectionView:self.collectionView];
    [IPSConversationHtmlContentCell registerInCollectionView:self.collectionView];
    
    // setupSizingCells
    self.sizingTextCell = [IPSConversationTextCell sizingCell];
    self.sizingFormCell = [IPSConversationSimpleFormCell sizingCell];
    self.sizingSpinnerCell = [IPSConversationSpinnerCell sizingCell];
    self.sizingWebContentCell = [IPSConversationHtmlContentCell sizingCell];
}

- (void)setChatDataSource:(IPSConversationDataSource *)chatDataSource {
    _chatDataSource.delegate = nil;
    _chatDataSource = chatDataSource;
    _chatDataSource.delegate = self;
}

#pragma mark - <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    NSInteger sections = [self.chatDataSource numberOfSections];
//    NSLog(@"%s: %ld", __PRETTY_FUNCTION__, sections);
    return sections;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    NSInteger items = [self.chatDataSource numberOfItemsInSection:section];
//    NSLog(@"%s: %ld %ld", __PRETTY_FUNCTION__, section, items);
    return items;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    id<IPSConversationMessageData> message = [self.chatDataSource messageAtIndexPath:indexPath];
    UICollectionViewCell *cell = [self collectionView:collectionView cellForItemAtIndexPath:indexPath message:message];
    return cell;
}

- (IPSConversationBubbleCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath message:(id<IPSConversationMessageData>)message {
    
    NSDictionary *cellMap =
    @{
      @(IPSConversationMessageTypeHtmlContent): [IPSConversationHtmlContentCell class],
      @(IPSConversationMessageTypeText): [IPSConversationTextCell class],
      @(IPSConversationMessageTypeForm): [IPSConversationSimpleFormCell class],
      @(IPSConversationMessageTypeSpinner): [IPSConversationSpinnerCell class],
      @(IPSConversationMessageTypeImage): [IPSConversationMediaCell class],
      @(IPSConversationMessageTypePdf): [IPSConversationMediaCell class],
      @(IPSConversationMessageTypeInformation): [IPSConversationTextCell class],
      };
    
    Class cellClass = cellMap[@(message.messageType)];
    if (cellClass != nil) {
        IPSConversationBubbleCell *cell = [cellClass dequeueCellInCollectionView:collectionView forIndexPath:indexPath];
        if([cell isKindOfClass:[IPSConversationMediaCell class]]){
            [((IPSConversationMediaCell*)cell) setUserActionDelegate:_userActionDelegate];
        }
        [cell configure:message];
        return cell;
    }
    
    return nil;
}

- (void)scrollToBottom {
    if (self.collectionView.numberOfSections == 0) {
        return;
    }
    
    CGFloat contentHeight = self.collectionView.contentSize.height;
    if (contentHeight < CGRectGetHeight(self.collectionView.bounds)) {
        CGRect endRect = CGRectMake(0, self.collectionView.contentSize.height - 1, 1, 1);
        [self.collectionView scrollRectToVisible:endRect animated:YES];
        return;
    }
    
    NSInteger lastSection = self.collectionView.numberOfSections - 1;
    NSInteger lastItem = [self.collectionView numberOfItemsInSection:lastSection] - 1;
    NSIndexPath *lastIndexPath = [NSIndexPath indexPathForItem:lastItem inSection:lastSection];
    [self.collectionView scrollToItemAtIndexPath:lastIndexPath atScrollPosition:UICollectionViewScrollPositionTop animated:YES];
}

#pragma mark - <UICollectionViewDelegate>

- (id<IPSConversationMessageData>)messageForcollectionView:(UICollectionView *)collectionView layout:(IPSConversationCollectionViewLayout *)layout atIndexPath:(NSIndexPath *)indexPath {
    return [self.chatDataSource messageAtIndexPath:indexPath];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    id<IPSConversationMessageData> message = [self.chatDataSource messageAtIndexPath:indexPath];
    CGFloat maxWidth = collectionView.bounds.size.width - 60;
    
    if (message.messageType == IPSConversationMessageTypeText || message.messageType == IPSConversationMessageTypeInformation) {
        [self.sizingTextCell configure:message];
        CGSize targetSize = CGSizeMake(maxWidth, 44);
        CGSize cellSize = [self.sizingTextCell preferredLayoutSizeFittingSize:targetSize];
        return cellSize;
    } else if (message.messageType == IPSConversationMessageTypeForm) {
        [self.sizingFormCell configure:message];
        CGSize targetSize = CGSizeMake(maxWidth, 48 + 48 * [message actionCount]);
        CGSize cellSize = [self.sizingFormCell preferredLayoutSizeFittingSize:targetSize];
        return cellSize;
    } else if (message.messageType == IPSConversationMessageTypeSpinner) {
        return CGSizeMake(44, 22);
    } else if (message.messageType == IPSConversationMessageTypeImage) {
        return CGSizeMake(maxWidth, maxWidth);
    } else if(message.messageType == IPSConversationMessageTypePdf){
        return CGSizeMake(80, 60);
    } else if(message.messageType == IPSConversationMessageTypeHtmlContent){
        [self.sizingWebContentCell configure:message];
        CGSize targetSize = CGSizeMake(maxWidth, 44);
        CGSize cellSize = [self.sizingWebContentCell preferredLayoutSizeFittingSize:targetSize];
        return cellSize;
    }
    
    return CGSizeZero;
}

#pragma mark - <IPSConversationDataSourceDelegate>

- (void)conversationDataSourceDidReload:(IPSConversationDataSource *)dataSource {
    [self.collectionView reloadData];
}

- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didInsertSections:(NSIndexSet *)sections {
    [self.collectionView reloadData];

    dispatch_async(dispatch_get_main_queue(), ^{
        [self scrollToBottom];
    });
}

- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didInsertItemsAtIndexPath:(NSArray<NSIndexPath *> *)indexPaths {
    [self.collectionView reloadData];

    dispatch_async(dispatch_get_main_queue(), ^{
        [self scrollToBottom];
    });
}

- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didDeleteSections:(NSIndexSet *)sections {
    [self.collectionView reloadData];
}

- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didDeleteItemsAtIndexPath:(NSArray<NSIndexPath *> *)indexPaths {
    [self.collectionView reloadData];
}

- (void)conversationDataSource:(IPSConversationDataSource *)dataSource didReloadItemsAtIndexPath:(NSArray<NSIndexPath *> *)indexPaths {
    [self.collectionView reloadItemsAtIndexPaths:indexPaths];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self scrollToBottom];
    });
}

@end
