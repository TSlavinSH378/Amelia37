//
//  IPSAKSupportedType.h
//  AmeliaKit
//
//  Created by Yulong Yang on 3/8/18.
//  Copyright © 2018 IPsoft. All rights reserved.
//

#import <AmeliaKit/AmeliaKit.h>
/**
 An class that specifies the all the supported mimtypes and file extensions
 */
@interface IPSAKSupportedType : IPSAKObject
@property (nonatomic,copy,readonly) NSString *mimeType;
@property (nonatomic,copy,readonly) NSArray<NSString*> *fileExtensions;
@end
