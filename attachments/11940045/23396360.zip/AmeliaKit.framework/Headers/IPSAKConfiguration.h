//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IPSAKSpeechParams.h"

NS_ASSUME_NONNULL_BEGIN

/**
 Constants indicating which domain selection mode to use.
 */
typedef NS_ENUM(NSInteger, IPSAKDomainSelectionMode) {
    /**
     The delegate method `chat:domainSelectionRequired:` is always called.
     */
    IPSAKDomainSelectionModeManual,
    /**
     A domain will be automatically selected if possible, otherwise the delegate method `chat:domainSelectionRequired:` is called.
     */
    IPSAKDomainSelectionModeAutomatic,
    /** 
     The domain that should be selected is specified by the `domainCode` property of the `IPSAKConfiguration` instance. If the specified domain is not available in the fetched domains the delegate method `chat:domainFailWithError:` is called.
     */
    IPSAKDomainSelectionModePredefined,
};

/**
 The `IPSAKConfiguration` class describes the different options used when creating an instance of `IPSAKChat`.
 */
@interface IPSAKConfiguration : NSObject

/**
 Creates an configuration instance with the given url.
 
 @param URL The base URL to the Amelia server.
 */
+ (instancetype)configurationWithURL:(NSURL *)URL;

/**
 The base URL to the Amelia server.
 */
@property (strong, nonatomic, readonly) NSURL *baseURL;

/**
 The type of domain selection. Default: `IPSAKDomainSelectionModeAutomatic`.
 */
@property (nonatomic) IPSAKDomainSelectionMode domainSelectionMode;

/**
 The domain code used to select a domain if `domainSelectionMode = IPSAKDomainSelectionModePredefined`.
 */
@property (copy, nonatomic, nullable) NSString *domainCode;

/**
 The minimum time (in milliseconds) between messages before the user is considered idle. Default: 0
 
 If <= 0 the conversation will use default values.
 */
@property (nonatomic) NSInteger minIdleTime;

/**
 Adds a variable time component (in milliseconds) to the min idle time. Default: 0
 
 If <= 0 the conversation will use default values.
 */
@property (nonatomic) NSInteger varIdleTime;

/**
 Set httpClient's connection timeout in milliseconds
 */
@property (nonatomic) int connectTimeoutMillis;
/**
 Controls whether the SDK speaks the messages Amelia sends. Default: .enabled = YES, .muted = NO
 */
@property (strong, nonatomic) IPSAKSpeechParams *speechParams;

/**
 Initial conversation attributes passed to new conversation
 This is useful for auto-login with saved session cookie, when there is no further chance to pass in the attributes to new conversation
 */
@property (strong,nonatomic) NSDictionary *initialAttributes;
/**
 Initial BPN variables passed to new conversation
 This is useful for auto-login with saved session cookie, when there is no further chance to pass in the attributes to new conversation
 */
@property (strong,nonatomic) NSDictionary *initialBpnAttributes;

@end

NS_ASSUME_NONNULL_END
