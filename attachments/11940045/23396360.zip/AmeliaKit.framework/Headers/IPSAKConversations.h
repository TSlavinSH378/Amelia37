//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAKDownloadMessage.h"
#import "IPSAKMessage.h"
#import "IPSAKObject.h"

NS_ASSUME_NONNULL_BEGIN

@class IPSAKUploadMessage;
@class IPSStompClient;
@class IPSAKFormInputData;
@class IPSAKBpnExecutionEvent;
@class IPSAKJoinConversationRequest;
@class IPSAKEscalationRequest;
@class IPSAKEscalationAlert;
@class IPSAKConversation;
@class IPSAKEscalationResponse;
@protocol IPSAKConversationsDelegate;

typedef NS_ENUM(NSInteger, IPSAKConversationState) {
    IPSAKConversationConnecting,
    IPSAKConversationConnected,
    IPSAKConversationRecoverable
};

/**
 An `IPSAKConversation` instance is created when a new conversation starts.
 */
@interface IPSAKConversations : NSObject

/**
 This should be a single instance that contains all conversations.Initialized when user is logged in.
 */
- (instancetype)initWithStompClient:(IPSStompClient*)stompClient andUserId:(NSString*)userId;


/**
  Start sending/receiving messages to/from a conversation by by subscribing to the conversation. When the subscription receipt is received, the
  `delegate` is sent the `conversationDidStart:` message.
*/
- (void)startConversation:(IPSAKConversation*)conversation;

/// The `IPSStompClient` that should be used to send and receive the Stomp frames.

/// The object that acts as the conversation delegate.
@property (nonatomic, weak) id<IPSAKConversationsDelegate> delegate;

/**
 Current state of the conversation. Default: `IPSAKConversationConnecting`.
 */
@property (readonly) IPSAKConversationState conversationState;

/**
 Delegate calls are dispatched on this queue. If `nil`, the main queue is used for delegate calls.
 */
@property (strong, nonatomic, nullable) dispatch_queue_t delegateDispatchQueue;
/**
 web socket client that gets/sends all the chat messages
 */
@property (strong,readonly) IPSStompClient *stompClient;

/**
 Reconnect a disconnected session.
 */
- (void)reconnect;
/**
 Get the list of ongoing conversations
 */
-(NSArray<IPSAKConversation*>*)getConversations;

/// Sends a text message to Amelia. Secure messages which should be secured.
- (void)ask:(NSString *)message inConversation:(IPSAKConversation*)conversation;
/// Alias for `ask:`
- (void)say:(NSString *)message inConversation:(IPSAKConversation*)conversation;
/**
 Send custom conversation attributes to a particular conversation.
 The conversation must be ongoing/active in order for this to be sent.
 @param attributes the key/value pairs of the attribute map
 @param conversation the conversation the custom attributes should be sent to
 */
-(void)sendCustomConversationAttributes:(NSDictionary*) attributes inConversation:(IPSAKConversation*)conversation;

/**
 Submit a form to Amelia.
 
 @note This method should be uses to respond to a message that includes `formInputData`

 @param form The form included in the message.¯
 @param message The text to speak in the submission
 @param conversation the conversation to send the form to
 */
- (void)submitForm:(IPSAKFormInputData *)form message:(NSString *_Nullable)message inConversation:(IPSAKConversation*)conversation;
/**
 Run the named BPN process on Amelia.
 
 @param processName The name of the BPN process to run.
 @param processArgs The arguments to pass to the process.
 @param message A custom message to send.
 @param conversation the conversation to run the bpn at
 */
- (void)runAction:(NSString *)processName arguments:(NSDictionary *)processArgs message:(NSString *)message inConversation:(IPSAKConversation*)conversation;
/**
 send file upload confirmation message after upload finished
 
 @param submited true if the upload was successful
 @param conversation the conversation to send the confirmation message to
 */
-(void)sendFileUploadConfirmationMessage:(BOOL)submited toConversation:(IPSAKConversation*)conversation;

/**
 Ends the current conversation.
 @param conversation the conversation to end
 */
- (void)endConversation:(IPSAKConversation*)conversation;

/**
 ACCEPT or REJECT escalation received previously
 */
-(void)sendEscalationResponse:(IPSAKEscalationResponse*)escalationResponse;
@end

/**
 The `IPSAKConversationDelegate` protocol defines the optional methods you implement to make a chat session functional.
 */
@protocol IPSAKConversationsDelegate<NSObject>

@optional
/**
 Tells the delegate that a conversation has been started. This is response to a Stomp session being established to Amelia.
 */
- (void)conversationDidStart:(IPSAKConversation *)conversation;
/**
 Tells the delegate the conversation has ended.
 @param conversation The conversation object informing the delegate of this event.
 */
- (void)conversationDidEnd:(IPSAKConversation *)conversation;
/**
 Tells the delegate that then conversation is connected.
 */
- (void)conversationDidConnect:(IPSAKConversation *)conversation;
/**
 Tells the delegate that then conversation is disconnected unexpectedly.
 */
- (void)conversationDidDisconnect:(IPSAKConversation *)conversation;
/**
 Tells the delegate that the conversation is reconnected after a previous disconnect.
 */
- (void)conversationDidReconnect:(IPSAKConversation *)conversation;
/**
 Tells the delegate that a message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation *)conversation didReceiveMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that an multimedia message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation *)conversation didReceiveDownloadMessage:(IPSAKDownloadMessage *)message;
/**
 Tells the delegate that an upload is requested.
 */
- (void)conversation:(IPSAKConversation *)conversation uploadRequested:(IPSAKUploadMessage *)uploadRequest;
/**
 tells the delegate the conversation received another converastion join request
 */
- (void)didReceiveConversationJoinRequest:(IPSAKJoinConversationRequest *)request;
/**
 Received Amelia escalation request
 */
-(void)didReceiveEscalationRequest:(IPSAKEscalationRequest*)escalationRequest;
/**
 Received escalation alert from Amelia to update availability
 */
-(void)didReceiveEscalationAlert:(IPSAKEscalationAlert*)escalationAlert;
/**
 */
-(void)escalationListenerDidConnect;
/**
 Tells the delegate that an upload has successfully completed.
 */
- (void)conversationUploadSuccess:(IPSAKConversation *)conversation;
/**
 Tells the delegate that an upload failed.
 */
- (void)conversation:(IPSAKConversation *)conversation uploadFailWithError:(NSError *)error;
/**
 Tells the delegate whether Amelia is ready to receive input or not.
 */
- (void)conversation:(IPSAKConversation *)conversation inputEnabled:(BOOL)enabled;
/**
 Tells the delegate whether the user's input needs to be secured.
 */
- (void)conversation:(IPSAKConversation *)conversation inputSecured:(BOOL)enabled;
/**
 Tells the delegate that input is currently blocked.
 */
- (void)conversationErrorInputBlocked:(IPSAKConversation *)conversation;
/**
 Tells the delegate that the conversation is now idle.
 */
- (void)conversationIdle:(IPSAKConversation *)conversation;
/**
 Tells the delegate that Amelia's mood has changed.
 */
- (void)conversation:(IPSAKConversation *)conversation moodChangeFrom:(IPSAKMoodType)fromMood to:(IPSAKMoodType)toMood;
/**
 Tells the delegate that an error occurred while chatting.
 */
- (void)conversation:(IPSAKConversation *)conversation error:(NSError *)error;
/**
 Tells the delegate that the conversation has been disconnected.
 */
- (void)conversation:(IPSAKConversation *)conversation didDisconnectWithError:(NSError *)error;
@end

NS_ASSUME_NONNULL_END
