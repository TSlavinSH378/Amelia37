//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAKObject.h"

/**
 The `IPSAKAuthSystem` class represents an authentication system.
 */
@interface IPSAKAuthSystem : IPSAKObject
/**
 A GUID that identifies this authentication system.
 */
@property(copy, nonatomic, readonly) NSString *identifier;
/**
 Custom provider class name
 */
@property(copy, nonatomic, readonly) NSString *customProviderClass;

/**
 This is the path that, when appended to the base URL, can be used to start the login process.
 */
@property(copy, nonatomic, readonly) NSString *loginPath;
/**
 UI friendly name of this authentication system.
 */
@property(copy, nonatomic, readonly) NSString *name;
/**
 Whether this authentication system redirects to an other, external, login system.
 If redirect == true, this means the auth system uses a third party server to authenticate the user
 */
@property(nonatomic, readonly) BOOL redirect;
/**
 immediate
 **/
@property(nonatomic, readonly) BOOL immediate;

/**
 Provides a default Auth system if none is defined on the server.
 */
+ (instancetype) defaultAuthSystem;

@end
