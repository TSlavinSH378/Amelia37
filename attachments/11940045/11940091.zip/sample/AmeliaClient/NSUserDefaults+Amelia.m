//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "NSUserDefaults+Amelia.h"

NSNotificationName const IPSChatSettingsUpdateNotification = @"IPSChatSettingsUpdateNotification";

@implementation NSUserDefaults (Amelia)

- (NSString *)ips_host {
    return [self objectForKey:@"amelia-host"] ?: @"https://ameliav3-dev.ipsoft.com/Amelia/api/";
}

- (void)ips_setHost:(NSString *)host {
    BOOL postNotification = ![host isEqualToString:[self ips_host]];
    [self setObject:host forKey:@"amelia-host"];
    if (postNotification) {
        [self postChatSettingsUpdateNotification];
    }
}

- (BOOL)ips_anonymousAllowed {
    /*
    if ([self objectForKey:@"amelia-anonymous-allowed"] == nil) {
        return YES;
    } else {
        return [self boolForKey:@"amelia-anonymous-allowed"];
    }*/
    return false;
}

- (void)ips_setAnonymousAllowed:(BOOL)value {
    BOOL postNotification = value != [self ips_anonymousAllowed];
    [self setBool:value forKey:@"amelia-anonymous-allowed"];
    if (postNotification) {
        [self postChatSettingsUpdateNotification];
    }
}

- (BOOL)ips_autoConnect {
    return [self boolForKey:@"amelia-auto-connect"];
}

- (void)ips_setAutoConnect:(BOOL)value {
    [self setBool:value forKey:@"amelia-auto-connect"];
}

- (BOOL)ips_autoDomain {
    return [self boolForKey:@"amelia-auto-domain"];
}

- (void)ips_setAutoDomain:(BOOL)value {
    [self setBool:value forKey:@"amelia-auto-domain"];
}

- (NSString *)ips_username {
    return [self objectForKey:@"amelia-username"];
}

- (void)ips_setUserName:(NSString *)value {
    [self setObject:value forKey:@"amelia-username"];
}

- (NSString *)ips_password {
    return [self objectForKey:@"amelia-password"];
}

- (void)ips_setPassword:(NSString *)value {
    [self setObject:value forKey:@"amelia-password"];
}

- (void)postChatSettingsUpdateNotification {
    [[NSNotificationCenter defaultCenter] postNotificationName:IPSChatSettingsUpdateNotification object:nil];
}

@end
