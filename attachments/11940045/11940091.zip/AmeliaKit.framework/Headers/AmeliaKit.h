//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#ifndef AmeliaKit_h
#define AmeliaKit_h

#import "IPSAKPresentingResource.h"
#import "AmeliaKitError.h"
#import "IPSAKAuthSystem.h"
#import "IPSAKChat.h"
#import "IPSAKConfiguration.h"
#import "IPSAKConversation.h"
#import "IPSAKDomain.h"
#import "IPSAKFormInputData.h"
#import "IPSAKLoginOptions.h"
#import "IPSAKDownloadMessage.h"
#import "IPSAKMessage.h"
#import "IPSAKTrafficMonitor.h"
#import "IPSAKUploadMessage.h"
#import "IPSAKUser.h"
#import "IPSAKAppConfig.h"
#import "IPSStompClient.h"
#import "IPSAKBpnExecutionEvent.h"
#import "IPSAKSupportedType.h"

#endif /* AmeliaKit_h */

#define IPSAK_VERSION_STRING @"3.1.3"
#define IPSAK_TARGET_PLATFORM_VERSION @"v3.3.1"
