//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSDomainPickerViewController.h"
#import "IPSDomainListViewController.h"
#import "Styling.h"

@interface IPSDomainPickerViewController () <IPSDomainListViewContollerDelegate>
@property (nonatomic, strong) IPSDomainListViewController *domainListViewController;
@end

@implementation IPSDomainPickerViewController

+ (instancetype)domainPickerViewController {
    return [[UIStoryboard storyboardWithName:@"Session" bundle:nil] instantiateViewControllerWithIdentifier:@"domainPickerViewController"];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Choose a domain";
    
    [self.navigationController.navigationBar ips_makeTransparent];
    self.view.backgroundColor = [UIColor colorWithWhite:250/255. alpha:1];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Log out" style:UIBarButtonItemStylePlain target:self action:@selector(logoutTap:)];
    
    self.domainListViewController = [IPSDomainListViewController domainListViewController];
    self.domainListViewController.delegate = self;
    [self addChildViewController:self.domainListViewController];
    [self.view addSubview:self.domainListViewController.view];
    [self.domainListViewController didMoveToParentViewController:self];
}

- (void)logoutTap:(id)sender {
    [self.delegate domainPickerViewControllerLogoutButtonTapped:self];
}

- (void)showDomains:(NSArray<IPSAKDomain *> *)domains {
   [self.domainListViewController showDomains:domains];
}

- (void)reload {
    [self.domainListViewController reload];
}

- (void)domainListViewController:(IPSDomainListViewController *)controller didSelectDomain:(IPSAKDomain *)domain {
    [self.delegate domainPickerViewController:self didSelectDomain:domain];
}

@end
