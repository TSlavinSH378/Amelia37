//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSChatViewController.h"
#import "IPSAccordionViewController.h"
#import "IPSChatInputToolbar.h"
#import "IPSConversationDataSource.h"
#import "IPSConversationForm+IPSFormInputData.h"
#import "IPSConversationMessage.h"
#import "IPSConversationViewController.h"
#import "UIImage+AvatarImage.h"
#import "IPSIntegrationView.h"
#import <CommonCrypto/CommonDigest.h>
#import <AmeliaKit/AmeliaKit.h>
#import <AVFoundation/AVFoundation.h>
#import <Speech/Speech.h>
#import <AmeliaKit/AmeliaKit.h>
#define imageTypeArray  [NSArray arrayWithObjects: @"jpeg",@"jpg",@"png",@"gif",@"tiff",@"tif",@"svg",@"emf",@"bmp",@"wmf",nil]


@interface IPSChatViewController () <IPSChatInputToolbarDelegate, IPSAKChatConversationDelegate, IPSConversationFormDelegate, IPSIntegrationViewDelegate, IPSAccordionViewControllerDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate,SFSpeechRecognizerDelegate, UIDocumentInteractionControllerDelegate,IPSConversationUserActionDelegate>
@property (weak, nonatomic) IBOutlet IPSChatInputToolbar *inputToolbar;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *toolbarBottomConstraint;
@property (weak, nonatomic) IBOutlet IPSIntegrationView *integrationView;

@property (strong, nonatomic) IPSConversationViewController *conversationViewController;
@property (strong, nonatomic) IPSConversationDataSource *dataSource;
@property (strong, nonatomic) IPSAKChat *chat;
@property (strong, nonatomic) UIImageView *avatarImageView;
//speech to text
@property (strong, nonatomic) IBOutlet UIButton *micButton;
@property (nonatomic ,strong) SFSpeechRecognitionTask *recognitionTask;
@property (nonatomic ,strong) SFSpeechRecognizer      *speechRecognizer;
@property (nonatomic ,strong) AVAudioEngine *audioEngine;
@property (nonatomic ,strong) SFSpeechAudioBufferRecognitionRequest *recognitionRequest;
@property (nonatomic ,strong) NSTimer *oneSecondTimer;
@property (nonatomic,strong) UIDocumentInteractionController *docController;
@end

@implementation IPSChatViewController

+ (instancetype)chatViewController:(IPSAKChat *)chat {
    IPSChatViewController *chatViewController = [[UIStoryboard storyboardWithName:@"Chat" bundle:nil] instantiateInitialViewController];
    chatViewController.chat = chat;
    return chatViewController;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.chat.conversationDelegate = self;

    self.dataSource = [[IPSConversationDataSource alloc] init];
    
    // setupAvatarImage
    {
        UIImage *avatar = [UIImage ips_smallAvatarImageForMood:IPSAKMoodNeutral];
        UIImageView *avatarImageView = [[UIImageView alloc] initWithImage:avatar];
        CALayer *maskLayer = [CALayer layer];
        maskLayer.contents = (__bridge id _Nullable)([UIImage imageNamed:@"48GraphicsAvatarFoldedMask"].CGImage);
        maskLayer.frame = CGRectMake(0, 0, 48, 48);
        avatarImageView.layer.mask = maskLayer;
        avatarImageView.layer.masksToBounds = YES;
        avatarImageView.contentMode = UIViewContentModeScaleAspectFit;
        self.avatarImageView = avatarImageView;
        self.navigationItem.titleView = avatarImageView;
    }
    
    // addCloseButton
    {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Close" style:UIBarButtonItemStyleDone target:self action:@selector(closeTap:)];
    }
    
    // setupIntegrationView
    {
        self.integrationView.hidden = YES;
        self.integrationView.delegate = self;
    }
    
    // addConversationViewController
    {
        IPSConversationViewController *conversationViewController = [[IPSConversationViewController alloc] init];
        conversationViewController.chatDataSource = self.dataSource;
        conversationViewController.userActionDelegate = self;
        
        [self addChildViewController:conversationViewController];
        [self.view insertSubview:conversationViewController.view belowSubview:self.inputToolbar];
        [conversationViewController didMoveToParentViewController:self];
        
        UICollectionView *collectionView = conversationViewController.collectionView;
        collectionView.backgroundColor = [UIColor whiteColor];
        [self updateInset];
        
        conversationViewController.automaticallyAdjustsScrollViewInsets = NO;
        
        self.conversationViewController = conversationViewController;
    }
    
    // subscribeToKeyboardNotifications
    {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ips_keyboardWillShowHide:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ips_keyboardWillShowHide:) name:UIKeyboardWillHideNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ips_keyboardDidShowHide:) name:UIKeyboardDidShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ips_keyboardDidShowHide:) name:UIKeyboardDidHideNotification object:nil];
    }
    //initialize for speech to text
    _audioEngine = [[AVAudioEngine alloc] init];
    self.speechRecognizer = [[SFSpeechRecognizer alloc] initWithLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"]];
}

- (void)speechRecognizer:(SFSpeechRecognizer *)speechRecognizer availabilityDidChange:(BOOL)available{
    if (available){
        [_micButton setEnabled:true];
    }else{
        [_micButton setEnabled:false];
    }
}

#pragma mark - 

- (void)closeTap:(id)sender {
    [self.inputToolbar.textField resignFirstResponder];
    [self.chat endConversation];
    [self.delegate chatViewControllerDidClose:self];
}

#pragma mark - <IPSAKChatConversationDelegate>
- (void)chat:(IPSAKChat *)chat didReceiveAmeliaReadyMessage: (IPSAKMessage *)message{
    NSLog(@"Amelia is ready for user input");
    [chat sendCustomConversationAttributes:@{@"attr1":@"value1"}];
}

- (void)chat:(IPSAKChat *)chat didReceiveMessage:(IPSAKMessage *)message {
    if (![self shouldDisplayMessage:message]) {
        return;
    }
    
    IPSConversationForm *lastMessage = [self.dataSource lastMessage];
    if ([lastMessage isKindOfClass:[IPSConversationForm class]]) {
        [self.dataSource removeMessage:lastMessage];
    }
    
    BOOL localMessage = message.messageType == IPSAKMessageTypeOutboundEcho && message.selfEcho;
    if (localMessage) {
        // TODO: Perform batch updates on the collection view
        [self addLocalMessage:message.messageText];
        [self.dataSource addSpinner];
    } else {
        [self addRemoteMessage:message.messageText];
        
        if (message.messageType == IPSAKMessageTypeOutboundProgressText) {
            [self.dataSource addSpinner];
        }
    }
}
-(void)chat:(IPSAKChat *)chat didReceiveBpnExecutionEventMessage:(IPSAKMessage *)message{
    NSLog(@"bpn event received: %@",message.bpnExecutionEvent.eventId);
    IPSAKBpnProcessEvent event = message.bpnExecutionEvent.bpnProcessEvent;
    if(event == PROCESS_ABORTED_EVENT){
        NSLog(@"bpn crashed");
    }
}

- (void)chat:(IPSAKChat *)chat didReceiveFormInputMessage:(IPSAKMessage *)message {
    
    if (message.formInputData != nil) {
        IPSConversationForm *form = [IPSConversationForm conversationFormWithFormInputData:message.formInputData];
        form.origin = IPSConversationMessageOriginRemote;
        form.delegate = self;
        [self.dataSource addMessage:form];
    }
}

- (void)chat:(IPSAKChat *)chat didReceiveDownloadMessage:(IPSAKDownloadMessage *)message {
    [message download:^(IPSAKDownloadedMMO *downloadedMMO, NSError *error) {
        
        if (error != nil) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self addErrorMessage:error.localizedDescription];
            });
        } else if (downloadedMMO != nil) {
            [self addMediaMessage:downloadedMMO];
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self addErrorMessage:@"Can't download unknown content."];
            });
        }
    }];
}

- (void)chat:(IPSAKChat *)chat didReceiveIntegrationMessage:(IPSAKMessage *)message {
    if (message.messageType == IPSAKMessageTypeOutboundIntegration) {
        NSString *sectionType = message.integrationMessageData[@"sectionType"];
        if ([sectionType isKindOfClass:[NSString class]] && [sectionType isEqualToString:@"AccordionSection"]) {
            [self showIntegrationView:message.integrationMessageData];
        } else {
            [self addInfoMessage:@"Integration message not supported."];
        }
    }
}

- (void)chat:(IPSAKChat *)chat didReceiveConversationClosedMessage:(IPSAKMessage *)message {
    [self addInfoMessage:@"Conversation closed"];
    [self.inputToolbar.textField resignFirstResponder];
    self.inputToolbar.textField.enabled = NO;
}

- (void)chat:(IPSAKChat *)chat didReceiveAgentSessionChangedMessage:(IPSAKMessage *)message {
    [self addInfoMessage:message.messageText];
}

- (void)chat:(IPSAKChat *)chat uploadRequested:(IPSAKUploadMessage *)uploadRequest {
    [self.dataSource removeSpinner];
    FileType fileType = BINARY;
    for(NSString *type in uploadRequest.supportedFileExtensions){
        if([imageTypeArray containsObject:type]){
            fileType = IMAGE;
            break;
        }
    }
    if(fileType==IMAGE) {
        [self presentImagePicker];
    }else{
       [self addInfoMessage:[NSString stringWithFormat:@"Client doesn't know how to handle uploads of %@.", uploadRequest.supportedFileExtensions.description]];
        [chat cancleFileUpload];
    }
}

- (void)chatUploadSuccess:(IPSAKChat *)chat {
    //
}

- (void)chat:(IPSAKChat *)chat uploadFailWithError:(NSError *)error {
    [self addErrorMessage:error.localizedDescription];
}

- (void)chat:(IPSAKChat *)chat inputEnabled:(BOOL)enabled {
    self.inputToolbar.inputEnabled = enabled;
}

- (void)chat: (IPSAKChat *)chat inputSecured:(BOOL)enabled{
    self.inputToolbar.textField.secureTextEntry = enabled;
}

- (void)chatErrorInputBlocked:(IPSAKChat *)chat {
    NSLog(@"Input is blocked.");
}

- (void)chatWillStartSpeaking:(IPSAKChat *)chat {
    dispatch_async(dispatch_get_main_queue(), ^{
        [_micButton setEnabled:false];
    });
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setMode:AVAudioSessionModeDefault error:nil];
    NSError *activeError;
    if (![session setActive:YES error:&activeError]) {
        // Handle error
        NSLog(@"error: session setActive");
        return;
    }
    NSError *categoryError;
    if (![session setCategory:AVAudioSessionCategoryPlayback error:&categoryError]) {
        // Handle error
       NSLog(@"error: session setCategory %@", [categoryError localizedDescription]);
        return;
    }else{
        [session overrideOutputAudioPort:AVAudioSessionPortOverrideSpeaker error:nil];
    }
}
- (void)chatDidStopSpeaking:(IPSAKChat *)chat {
    [_micButton setEnabled:true];
    [[AVAudioSession sharedInstance] setActive:NO error:nil];
}

- (void)chat:(IPSAKChat *)chat moodChangeFrom:(IPSAKMoodType)fromMood to:(IPSAKMoodType)toMood{
    self.avatarImageView.image = [UIImage ips_smallAvatarImageForMood:toMood];
}

- (void)chatDidEnd:(IPSAKChat *)chat {
}

- (void)chatDidDisconnect:(IPSAKChat *)chat {
    [self addInfoMessage:@"Chat is disconnected"];
    self.inputToolbar.textField.enabled = NO;
}

- (void)chatDidRecconnect:(IPSAKChat *)chat {
    [self addInfoMessage:@"Chat is connected"];
    self.inputToolbar.textField.enabled = YES;
}

#pragma mark -

- (BOOL)shouldDisplayMessage:(IPSAKMessage *)message {
    switch (message.messageType) {
        case IPSAKMessageTypeOutboundEcho:
        case IPSAKMessageTypeOutboundText:
        case IPSAKMessageTypeOutboundFinalError:
        case IPSAKMessageTypeOutboundWolframAlphaFinal:
        case IPSAKMessageTypeOutboundProgressText:
        case IPSAKMessageTypeOutboundIdleTalk:
            return YES;
        default:
            return NO;
    }
}

- (void)addLocalMessage:(NSString *)message {
    IPSConversationMessage *conversationMessage = [[IPSConversationMessage alloc] initWithText:message];
    conversationMessage.origin = IPSConversationMessageOriginLocal;
    [self.dataSource addMessage:conversationMessage];
}

- (void)addRemoteMessage:(NSString *)message {
    IPSConversationMessage *conversationMessage = nil;
    conversationMessage.origin = IPSConversationMessageOriginRemote;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"(<\\w){1}(.|\\s)*(>){1}" options:NSRegularExpressionCaseInsensitive error:nil];
    NSUInteger regExMatches = [regex numberOfMatchesInString:message options:0 range:NSMakeRange(0, [message length])];
    if(regExMatches>0){
        NSString *formatedMessage = [NSString stringWithFormat:@"<HTML><head><style>body {color:#000000; font: normal 15px Verdana, Arial, sans-serif;background-color:#EEEFF0;}</style></head><body>%@</body></HTML>",message];
        NSAttributedString * attributedString = [[NSAttributedString alloc]
                            initWithData: [formatedMessage dataUsingEncoding:NSUnicodeStringEncoding]
                            options: @{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType }
                            documentAttributes: nil
                            error: nil
                            ];
        conversationMessage.messageType = IPSConversationMessageTypeHtmlContent;
        conversationMessage = [[IPSConversationMessage alloc] initWithHtmlText:attributedString];
    }else{
        conversationMessage = [[IPSConversationMessage alloc] initWithText:message];
    }
    [self.dataSource addMessage:conversationMessage];
}

- (void)addRemoteLinkMessage:(NSString *)message {
    NSString* formatedMessage = [NSString stringWithFormat:@"<HTML><head><style>body {color:#ffffff; font: normal 15px Verdana, Arial, sans-serif;background-color:#26B7EF;}</style></head><body><a href=\"%@\">%@</a href></body></HTML>",message,message];
    NSAttributedString * attributedString = [[NSAttributedString alloc]
                                             initWithData: [formatedMessage dataUsingEncoding:NSUnicodeStringEncoding]
                                             options: @{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType }
                                             documentAttributes: nil
                                             error: nil
                                             ];
    IPSConversationMessage *conversationMessage = [[IPSConversationMessage alloc] initWithHtmlText:attributedString];
    conversationMessage.origin = IPSConversationMessageOriginRemote;
    conversationMessage.messageType = IPSConversationMessageTypeHtmlContent;
    [self.dataSource addMessage:conversationMessage];
}

- (void)addErrorMessage:(NSString *)message {
    IPSConversationMessage *conversationMessage = [[IPSConversationMessage alloc] initWithText:message];
    conversationMessage.origin = IPSConversationMessageOriginRemote;
    [self.dataSource addMessage:conversationMessage];
}

- (void)addInfoMessage:(NSString *)message {
    IPSConversationMessage *conversationMessage = [[IPSConversationMessage alloc] initWithInformationText:message];
    conversationMessage.origin = IPSConversationMessageOriginRemote;
    [self.dataSource addMessage:conversationMessage];
}

- (void)addMediaMessage:(IPSAKDownloadedMMO *)downloadedMMO {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0), ^{
        
        IPSConversationMessage *message;
        
        if ([@[@"image/png", @"image/jpg", @"image/jpeg"] containsObject:downloadedMMO.MIMEType]) {
            UIImage *image = [UIImage imageWithData:downloadedMMO.content];
            if (image) {
                message = [[IPSConversationMessage alloc] initWithMedia:image];
                message.origin = IPSConversationMessageOriginRemote;
            }
        }else if([@[@"application/pdf"] containsObject:downloadedMMO.MIMEType]) {
            UIImage *image = [UIImage imageNamed:@"pdf_icon"];
            if (image) {
                message = [[IPSConversationMessage alloc] initWithPdfData:downloadedMMO.content];
                message.origin = IPSConversationMessageOriginRemote;

            }
        }
        
        if (message == nil) {
            NSString *messageText = [NSString stringWithFormat:@"Could not create content from MIMEType = %@", downloadedMMO.MIMEType];
            message = [[IPSConversationMessage alloc] initWithInformationText:messageText];
            message.origin = IPSConversationMessageOriginRemote;
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.dataSource addMessage:message];
        });
    });
}

- (void)addUploadedImage:(UIImage *)image {
    IPSConversationMessage *message = [[IPSConversationMessage alloc] initWithMedia:image];
    message.origin = IPSConversationMessageOriginLocal;
    [self.dataSource addMessage:message];
}

#pragma mark - Integration View


- (void)showIntegrationView:(NSDictionary *)integration {
    self.integrationView.hidden = NO;
    [self.view bringSubviewToFront:self.integrationView];
    [self.integrationView configure:integration];
    [self updateInset];
}
- (void)integrationViewTap:(IPSIntegrationView *)integrationView {
    IPSAccordionViewController *accordionController = [IPSAccordionViewController accordionViewControllerWithIntegrationMessage:integrationView.integration];
    accordionController.delegate = self;
    [self.navigationController pushViewController:accordionController animated:YES];
}

- (void)accordionViewController:(IPSAccordionViewController *)controller runAction:(NSString *)action arguments:(NSDictionary *)arguments message:(NSString *)message {
    [self.navigationController popViewControllerAnimated:YES];
    [self.chat runAction:action arguments:arguments message:message];
}

#pragma mark - File uploads

- (void)presentImagePicker {
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    [self presentViewController:imagePicker animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    if (image) {
        [self addUploadedImage:image];
        NSData *imageData = UIImageJPEGRepresentation(image, 1);
        NSString *filename = [NSString stringWithFormat:@"File-upload-%@.jpg", [[NSUUID UUID] UUIDString]];
        [self.chat uploadFileData:imageData filename:filename];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark -

- (void)conversationFormDidUpdate:(IPSConversationForm *)form action:(IPSConversationFormAction *)action {
    IPSAKFormInputData *formInputData = form.content;
    [self.chat submitForm:formInputData message:nil];
}

#pragma mark - <IPSChatInputToolbarDelegate>

- (void)chatInputToolBar:(IPSChatInputToolbar *)toolbar sendText:(NSString *)text {
    NSAssert([NSThread isMainThread], @"");
    [toolbar clearText];
    [self.chat ask:text];
}

- (void)chatInputToolBarDidLongPress:(IPSChatInputToolbar *)toolbar {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Workflows" message:@"Select a workflow" preferredStyle:UIAlertControllerStyleActionSheet];
    
    {
        NSArray *workflows =
        @[@[@"buttons", @"run the workflow buttons"],
          @[@"temperature", @"what about the temperature in stockholm"],
          @[@"link", @"run the workflow present_url"],
          @[@"image", @"run the workflow present_image"],
          @[@"pdf", @"run the workflow present_pdf"],
          @[@"accordion", @"run the workflow accordion"],
          @[@"upload", @"run the workflow request_image"],
          ];
        
        for (NSArray *workflow in workflows) {
            [alertController addAction:[UIAlertAction actionWithTitle:workflow.firstObject style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [self chatInputToolBar:toolbar sendText:workflow.lastObject];
            }]];
        }
    }
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

#pragma mark -

- (void)ips_keyboardWillShowHide:(NSNotification *)notification {
    
    CGFloat duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    NSInteger curve = [notification.userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];
    CGRect frame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    self.toolbarBottomConstraint.constant = CGRectGetHeight(self.view.frame) - frame.origin.y;
    
    [UIView animateWithDuration:duration delay:0.f options:curve << 16 animations:^{
        [self.view layoutIfNeeded];
    } completion:nil];
}

- (void)ips_keyboardDidShowHide:(NSNotification *)notification {
    // I can't seem to stop the collection view (or collection view controller) to automatically adjust the content inset
    // when the keyboard appears/disappears. This is to get the correct inset taking into account the keyboard.
    [self updateInset];
}

- (void)updateInset {
    UICollectionView *collectionView = self.conversationViewController.collectionView;
    CGFloat bottomInset =  CGRectGetHeight(self.inputToolbar.frame) + self.toolbarBottomConstraint.constant;
    CGFloat topInset = 66;
    if (!self.integrationView.hidden) {
        topInset += CGRectGetHeight(self.integrationView.frame);
    }
    collectionView.contentInset = collectionView.scrollIndicatorInsets = UIEdgeInsetsMake(topInset, 0, bottomInset, 0);
    [collectionView.collectionViewLayout invalidateLayout];
}

//Speech recognition stuff
- (void)dealloc {
    [self.recognitionTask cancel];
    self.recognitionTask = nil;
}

- (IBAction)onMicButtonClick:(id)sender {
    if (_audioEngine.running){
        NSLog(@"audio engine is running");
        [_audioEngine stop];
        if(_recognitionRequest){
            [_recognitionRequest endAudio];
        }
        [_micButton setImage:[UIImage imageNamed:@"mic_inactive"] forState:UIControlStateNormal];
        
    }else{
        
        [SFSpeechRecognizer requestAuthorization:^(SFSpeechRecognizerAuthorizationStatus status) {
            bool authorized = false;
            switch (status) {
                case SFSpeechRecognizerAuthorizationStatusNotDetermined:
                    authorized = false;
                    NSLog(@"NotDetermined");
                    break;
                case SFSpeechRecognizerAuthorizationStatusDenied:
                    authorized = false;
                    NSLog(@"Denied");
                    break;
                case SFSpeechRecognizerAuthorizationStatusRestricted:
                    authorized = false;
                    NSLog(@"Restricted");
                    break;
                case SFSpeechRecognizerAuthorizationStatusAuthorized:
                    authorized = true;
                    NSLog(@"Authorized");
                    break;
                default:
                    break;
            }
            [NSOperationQueue.mainQueue addOperationWithBlock:^{
                if(authorized){
                    [self startRecording];
                    [_micButton setImage:[UIImage imageNamed:@"mic_active"] forState:UIControlStateNormal];
                }
            }];
        }];

    }
}

-(void)startRecording{
    
    if(_recognitionTask){
        [_recognitionTask cancel];
        _recognitionTask = nil;
    }
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    @try{
        [audioSession setActive:false error:nil];
        [audioSession setCategory:AVAudioSessionCategoryRecord error:nil];
        [audioSession setMode:AVAudioSessionModeMeasurement error:nil];
        [audioSession setActive:true withOptions:AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation error:nil];
    }@catch(NSException *ex){
        NSLog(@"audioSessio properties weren't set because of an error.");
    }
    _recognitionRequest = [[SFSpeechAudioBufferRecognitionRequest alloc] init];
    AVAudioInputNode *inputnode = [_audioEngine inputNode];
    if(!inputnode){
        [NSException raise:@"NoInputNode" format:@"Audio engine has no input node"];
    }
    if(!_recognitionRequest){
        [NSException raise:@"FailedToInitRecognitionRequest" format:@"Unable to create an SFSpeechAudioBufferRecognitionRequest object"];
    }
    
    [_recognitionRequest setShouldReportPartialResults:true];
    
    _recognitionTask = [_speechRecognizer recognitionTaskWithRequest:_recognitionRequest resultHandler:^(SFSpeechRecognitionResult *result, NSError *error){
        bool isFinal = false;
        if(result){
            self.inputToolbar.textField.text = [[result bestTranscription] formattedString];
            isFinal = [result isFinal];
            NSLog(@"STT intermediate result: %@",[[result bestTranscription] formattedString]);
            if(_oneSecondTimer){
                [_oneSecondTimer invalidate];
            }
            _oneSecondTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                               target:self
                                                             selector:@selector(endRecording)
                                                             userInfo:nil
                                                              repeats:NO];
        }
        
        if(error!=nil||isFinal){
            [_audioEngine stop];
            [inputnode removeTapOnBus:0];
            
            _recognitionRequest = nil;
            _recognitionTask = nil;
            [audioSession setActive:false error:nil];
            [self chatInputToolBar:_inputToolbar sendText:_inputToolbar.textField.text];
            [_micButton setImage:[UIImage imageNamed:@"mic_inactive"] forState:UIControlStateNormal];
        }
    }];
    AVAudioFormat *recordingFormat = [inputnode outputFormatForBus:0];
    [inputnode installTapOnBus:0 bufferSize:1024 format:recordingFormat block:^(AVAudioPCMBuffer * _Nonnull buffer, AVAudioTime * _Nonnull when) {
        [_recognitionRequest appendAudioPCMBuffer:buffer];
    }];
    [_audioEngine prepare];
    @try{
        [_audioEngine startAndReturnError:nil];
    }@catch(NSException *ex){
        NSLog(@"audioEngine couldn't start because of an error");
    }
}

-(void)endRecording{
    NSLog(@"Ending Recording");
    if(_oneSecondTimer){
        [_oneSecondTimer invalidate];
    }
    if (_audioEngine.running){
        [_audioEngine stop];
        [NSOperationQueue.mainQueue addOperationWithBlock:^{
            if(_recognitionRequest){
                [_recognitionRequest endAudio];
            }
            [_micButton setImage:[UIImage imageNamed:@"mic_inactive"] forState:UIControlStateNormal];
        }];
    }
}

#pragma mark - <IPSConversationUserActionDelegate>
-(void)viewPdf: (NSData*) pdfData{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"PDF.pdf"]];
    [pdfData writeToFile:filePath atomically:YES];
    self.docController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:filePath]];
    self.docController.delegate = self;
    [self.docController presentPreviewAnimated:YES];
}

#pragma mark - <UIDocumentInteractionControllerDelegate>
- (UIViewController *) documentInteractionControllerViewControllerForPreview: (UIDocumentInteractionController *) controller {
    return self;
}

@end
