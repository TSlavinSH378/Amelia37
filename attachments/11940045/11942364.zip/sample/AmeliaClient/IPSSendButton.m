//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSSendButton.h"
#import "Styling.h"

@interface IPSSendButton()
@property BOOL enabledStatus;
@end

@implementation IPSSendButton

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.cornerRadius = 13;
        self.layer.shadowColor = [UIColor ips_azure40Color].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 2);
        self.layer.shadowRadius = 6;
        [self setImage:[UIImage imageNamed:@"27IconArrowUp"] forState:UIControlStateNormal];
        
        _enabledStatus = self.enabled;
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.layer.cornerRadius = 13;
    self.layer.shadowColor = [UIColor ips_azure40Color].CGColor;
    self.layer.shadowOffset = CGSizeMake(0, 2);
    self.layer.shadowRadius = 6;
    [self setImage:[UIImage imageNamed:@"27IconArrowUp"] forState:UIControlStateNormal];
    
    _enabledStatus = self.enabled;
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    self.tintColor = [UIColor whiteColor];
}

- (void)setInputEnabled:(BOOL)inputEnabled {
    _inputEnabled = inputEnabled;
    [self setEnabled:self.enabledStatus];
}

- (void)setEnabled:(BOOL)enabled {
    self.enabledStatus = enabled;
    [super setEnabled:enabled && self.inputEnabled];
    [self updateEnableStatus];
}

- (void)updateEnableStatus {
    if (self.enabled) {
        self.tintColor = [UIColor whiteColor];
        self.backgroundColor = [UIColor ips_azureColor];
        self.layer.shadowOpacity = 1;
    } else {
        self.tintColor = [UIColor blackColor];
        self.backgroundColor = [UIColor ips_silverColor];
        self.layer.shadowOpacity = 0;
    }
}

@end
