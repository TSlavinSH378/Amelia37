//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAccordionImageCell.h"

@interface IPSAccordionImageCell ()
@property (weak, nonatomic) IBOutlet UIImageView *contentImageView;
@end

@implementation IPSAccordionImageCell

@end
