//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSDomainListViewController.h"
#import "IPSConversationDataSource.h"
#import "IPSConversationForm.h"
#import "IPSConversationMessage.h"
#import "IPSConversationSimpleFormCell.h"
#import "IPSDomainForm.h"
#import "Styling.h"
#import <AmeliaKit/AmeliaKit.h>

@interface IPSDomainListViewController ()
@property (nonatomic, strong) NSArray<IPSAKDomain *> *domains;
@end

@implementation IPSDomainListViewController

+ (instancetype)domainListViewController {
    return [[IPSDomainListViewController alloc] init];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.collectionView.backgroundColor = [UIColor colorWithWhite:250./255. alpha:1];
    
    IPSConversationDataSource *dataSource = [[IPSConversationDataSource alloc] init];
    self.chatDataSource = dataSource;
}

- (void)showDomains:(NSArray<IPSAKDomain *> *)domains {
    self.domains = domains;
    __weak __typeof__(self) weakSelf = self;
    [self.chatDataSource suppressUpdates:^(IPSConversationDataSource *dataSource) {
        
        [dataSource removeAllMessages];
        
        
        IPSConversationMessage *message = [[IPSConversationMessage alloc] initWithText:@"Here are your available domains"];
        message.origin = IPSConversationMessageOriginRemote;
        [dataSource addMessage:message];
        
        for (IPSAKDomain *domain in domains) {
            IPSConversationForm *domainForm = [[IPSConversationForm alloc] initWithText:domain.name];
            domainForm.origin = IPSConversationMessageOriginRemote;
            domainForm.content = domain;
            [domainForm addActionWithTitle:@"Open conversation" content:domain style:IPSConversationFormActionStyleDefault handler:^(IPSConversationFormAction *action) {
                IPSAKDomain *domain = action.content;
                [weakSelf.delegate domainListViewController:weakSelf didSelectDomain:domain];
            }];
            [dataSource addMessage:domainForm];
        }
    }];

    [self.collectionView reloadData];
}

- (void)clearDomains {
    [self.chatDataSource removeAllMessages];
}

- (void)reload {
    [self.collectionView reloadData];
}

@end
