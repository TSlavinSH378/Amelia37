//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationMessage.h"

@interface IPSConversationMessage()
@property (copy) NSString *text;
@property (copy) NSAttributedString *attributedText;
@property (strong) id mediaContent;
@end

@implementation IPSConversationMessage

- (instancetype)initWithText:(NSString *)text {
    self = [super init];
    if (self) {
        _text = text;
        _messageType = IPSConversationMessageTypeText;
    }
    return self;
}

- (instancetype)initWithHtmlText:(NSAttributedString *)attributedText {
    self = [super init];
    if (self) {
        _attributedText = attributedText;
        _messageType = IPSConversationMessageTypeHtmlContent;
    }
    return self;
}

- (instancetype)initWithMedia:(id)media {
    self = [super init];
    if (self) {
        _mediaContent = media;
        _messageType = IPSConversationMessageTypeImage;
    }
    return self;
}

- (instancetype)initWithPdfData:(id)pdfData {
    self = [super init];
    if (self) {
        _mediaContent = pdfData;
        _messageType = IPSConversationMessageTypePdf;
    }
    return self;
}

- (instancetype)initWithInformationText:(NSString *)informationText {
    self = [super init];
    if (self) {
        _text = informationText;
        _messageType = IPSConversationMessageTypeInformation;
    }
    return self;
}

- (NSInteger)actionCount {
    return 0;
}

@end
