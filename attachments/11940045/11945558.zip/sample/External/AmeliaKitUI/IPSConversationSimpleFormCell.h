//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationBubbleCell.h"

NS_ASSUME_NONNULL_BEGIN

@class IPSConversationFormAction;

@interface IPSConversationSimpleFormCell : IPSConversationBubbleCell
- (void)addAction:(IPSConversationFormAction *)action;
@end

NS_ASSUME_NONNULL_END
