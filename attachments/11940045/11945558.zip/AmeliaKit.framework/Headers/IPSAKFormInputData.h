//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAKFormInputField.h"
#import "IPSAKObject.h"

/**
 The `IPSAKFormInputData` class represents an input form.
 */
@interface IPSAKFormInputData : IPSAKObject

/**
 A name for the form, useful as id.
 */
@property (copy, nonatomic, readonly) NSString *name;
/**
 A display name for the form section.
 */
@property (copy, nonatomic, readonly) NSString *nameForDisplay;
/**
 What manner of input Amelia will accept, must be: 
 - FORM_ONLY,
 - CHAT_ONLY
 - BOTH
 */
@property (copy, nonatomic, readonly) NSString *allowedUserInputs;
/**
 For suggested response
 */
@property (copy, nonatomic, readonly) NSString *instructions;
/**
 The type of the form, can be used to make decisions on placement or layout.
 */
@property (copy, nonatomic, readonly) NSString *formType;
/**
 The fields in this form.
 */
@property (copy, nonatomic, readonly) NSArray<IPSAKFormInputField *> *fields;

/**
 The response that is sent back to Amelia.
 */
- (NSDictionary *)formResponse;
/**
 The text representation of the response, will be echoed in the UI.
 */
- (NSString *)textResponse;

@end
