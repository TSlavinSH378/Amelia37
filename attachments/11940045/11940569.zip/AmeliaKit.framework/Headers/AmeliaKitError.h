//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 The value of an `NSError`'s domain property.
 */
extern NSString *const IPSAKErrorDomain;

/**
 The key name used to extract the required field from an `NSError`'s `userInfo`
 property.
 */
extern NSString *const IPSAKErrorRequiredFieldMissingKey;

/**
 The key name used to extract the login failed cause from an `NSError`'s
 `userInfo` property.
 */
extern NSString *const IPSAKErrorCauseKey;

/**
 The key name used to extract an internal `NSError` object from an `NSError`'s
 `userInfo` property.
 */
extern NSString *const IPSAKErrorInternalErrorKey;

/**
 The key name used to extract an HTTP status code `NSError`'s `userInfo`
 property.
 */
extern NSString *const IPSAKErrorHttpStatusCodeKey;

/**
 Values that are returned as the error code property of an NSError object.
 */
typedef NS_ENUM(NSInteger, IPSAKErrorCode) {
    /**
     The response was not in the expected UTF-8 encoding.
     */
    IPSAKErrorUnexpectedEncoding,
    /**
     The response didn't contain any content.
     */
    IPSAKErrorContentIsEmpty,
    /**
     The response content is missing a required field. The missing field name is
     included in the `NSError`'s `userInfo` property with
     `IPSAKErrorRequiredFieldMissingKey` as the dictionary key.
     */
    IPSAKErrorRequiredFieldMissing,
    /**
     The supplied credentials to the login request are invalid.
     */
    IPSAKErrorInvalidCredentials,
    /**
     The login failed and the reason is included in the `NSError`'s `userInfo`
     property with `IPSAKErrorCauseKey` as the dictionary key.
     */
    IPSAKErrorGenericLoginFail,
    /**
     The request was redirected which should be an indication that the user is
     no longer logged in or that the methods of the SDK was called in the wrong
     order.
     */
    IPSAKErrorInvalidSession,
    /**
     The conversation was closed unexpectedly from the server. `userInfo`
     contains the underlying error accessible via `IPSAKErrorInternalErrorKey`.
     */
    IPSAKErrorUnexpectedConnectionClose,
    /**
     Trying to send a message to Amelia when the connection is broken and not
     recoverable.
     */
    IPSAKErrorNotConnected,
    /**
     Missing content or content could not be read.
     */
    IPSAKErrorInvalidContent,
    /**
     The specified domain code is not present in the list of received domains.
     */
    IPSAKErrorSpecifiedDomainCodeMissing,
    /**
     The http response did not return a status code in the 200–299 range.
     `userInfo` contains the received status accessible via
     `IPSAKErrorHttpStatusCodeKey`.
     */
    IPSAKErrorHTTPStatusCode,
    /**
     User does not have permission to start this sepecific task
     */
    IPSAKErrorPermissionDenied,
};

/**
 User does not have the required permission to do this task
 */
extern NSError *IPSAKPermissionError();

/**
 Helper method to create a not connected error with a localizable description.
 */
extern NSError *IPSAKNotConnectedError();

/**
 Helper method to create a required field missing error with a localizable
 description.

 @param fieldName The name of required field that is missing.
 */
extern NSError *IPSAKRequiredFieldMissingError(NSString *fieldName);

/**
 Helper method to create an invalid login credentials error with a localizable
 description.
 */
extern NSError *IPSAKInvalidLoginCredentialsError();

/**
 Helper method to create an invalid content error with a localizable
 description.
 */
extern NSError *IPSAKInvalidContentError();

/**
 Helper method to create a specified domain code missing error with a
 localizable description.
 */
extern NSError *IPSAKSpecifiedDomainCodeMissingError();

/**
 Helper method to create an invalid session error. An invalid session is a response to a redirect that will typically occur when trying to do a session related request with an invalid CSRF-token.
 */
extern NSError *IPSAKInvalidSessionError();

/**
 Helper method to create a HTTP status code error.

 @param statusCode the HTTP status code.
 */
extern NSError *IPSAKHTTPStatusCodeError(NSInteger statusCode);

NS_ASSUME_NONNULL_END
