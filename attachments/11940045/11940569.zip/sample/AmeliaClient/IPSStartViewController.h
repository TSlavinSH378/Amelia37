//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol IPSStartViewControllerDelegate;

@interface IPSStartViewController : UIViewController
@property (weak, nonatomic) id<IPSStartViewControllerDelegate> delegate;
@end

@protocol IPSStartViewControllerDelegate <NSObject>
- (void)startViewControllerStartButtonTapped:(IPSStartViewController *)controller;
@end
