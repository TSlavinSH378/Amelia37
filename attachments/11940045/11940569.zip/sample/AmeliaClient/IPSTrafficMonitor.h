//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AmeliaKit/AmeliaKit.h>

@interface IPSTrafficMonitor : NSObject <IPSAKTrafficMonitor>

@end
