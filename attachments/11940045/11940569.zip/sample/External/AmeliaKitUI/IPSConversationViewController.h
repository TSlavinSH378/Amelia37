//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IPSConversationDataSource;
@class IPSConversationBubbleCell;
@protocol IPSConversationMessageData;
@protocol IPSConversationUserActionDelegate;

@interface IPSConversationViewController : UICollectionViewController

@property (strong, nonatomic) IPSConversationDataSource *chatDataSource;
@property (weak, nonatomic) id<IPSConversationUserActionDelegate> userActionDelegate;

/**
 Override to return a custom cell. 
 */
- (IPSConversationBubbleCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath message:(id<IPSConversationMessageData>)message;

@end
@protocol IPSConversationUserActionDelegate<NSObject>
-(void)viewPdf:(NSData*)pdfData;
@end
