//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationMediaCell.h"
#import "IPSConversationMessageData.h"
#import "IPSConversationViewController.h"
#import "Styling.h"

@interface IPSConversationMediaCell() 
@property (weak, nonatomic) IBOutlet UIView *cellContentView;
@property (weak, nonatomic) IBOutlet UIImageView *mediaView;
@property (weak,nonatomic) NSData *pdfData;
@property (weak,nonatomic) NSData *imageData;
@end

@implementation IPSConversationMediaCell

+ (void)registerInCollectionView:(UICollectionView *)collectionView {
    [collectionView registerNib:[UINib nibWithNibName:@"IPSConversationMediaCell" bundle:nil] forCellWithReuseIdentifier:@"mediaCell"];
}

+ (instancetype)dequeueCellInCollectionView:(UICollectionView *)collectionView forIndexPath:(NSIndexPath *)indexPath {
    return [collectionView dequeueReusableCellWithReuseIdentifier:@"mediaCell" forIndexPath:indexPath];
}

+ (instancetype)sizingCell {
    return [[UINib nibWithNibName:@"IPSConversationMediaCell" bundle:nil] instantiateWithOwner:nil options:nil].firstObject;
}

- (void)configure:(id<IPSConversationMessageData>)message {
    if(message.messageType==IPSConversationMessageTypePdf){
        self.pdfData = [message mediaContent];
        self.cellContentView.backgroundColor= [UIColor whiteColor];
        self.mediaView.image = [UIImage imageNamed:@"pdf_icon"];
    }else{
        self.imageData = [message mediaContent];
        self.cellContentView.backgroundColor = [UIColor ips_paleGreyColor];
        self.mediaView.image = [message mediaContent];
    }
    UITapGestureRecognizer *tapped = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onImageTapped:)];
    tapped.numberOfTapsRequired = 1;
    [self.mediaView setUserInteractionEnabled:true];
    [self.mediaView addGestureRecognizer:tapped];
}

-(void)onImageTapped :(id)sender
{
    if([self userActionDelegate]){
        if(self.pdfData){
            [[self userActionDelegate] viewPdf:_pdfData];
        }
    }
}

- (BOOL)shadowOutline {
    return YES;
}

@end
