//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAKObject.h"

/**
 The `IPSAKFormInputFieldOptions` class represent an input field option.
 */
@interface IPSAKFormInputFieldOptions : IPSAKObject

/**
 The displayable name.
 */
@property(copy, nonatomic, readonly) NSString *name;
/**
 The value of the submission when selected.
 */
@property(copy, nonatomic, readonly) NSString *value;
/**
 If it should be selected by default.
 */
@property(nonatomic) BOOL selected;
/**
 If it should be hidden by default.
 */
@property(nonatomic, readonly) BOOL hidden;
/**
 If it should be disabled by default.
 */
@property(nonatomic, readonly) BOOL disabled;

@end
