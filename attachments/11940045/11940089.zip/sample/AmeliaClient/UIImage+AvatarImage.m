//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "UIImage+AvatarImage.h"

@implementation UIImage (AvatarImage)

+ (UIImage *)ips_smallAvatarImageForMood:(IPSAKMoodType)mood {
    
    UIImage *avatarImage = [self ips_avatarImageForMood:mood];
    UIImage *innerShadow = [UIImage imageNamed:@"48GraphicsAvatarFoldedInnerShadowCopy"];
    
    UIGraphicsBeginImageContextWithOptions((CGSizeMake(48, 48)), YES, 0);
    [avatarImage drawInRect:CGRectMake(0, 0, 48, 48)];
    [innerShadow drawInRect:CGRectMake(0, 0, 48, 48)];
    UIImage *avatar = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return avatar;
}

+ (UIImage *)ips_avatarImageForMood:(IPSAKMoodType)mood {
    switch (mood) {
        case IPSAKMoodHappy:
            return [UIImage imageNamed:@"64GraphicsAvatarHappy"];
        case IPSAKMoodSad:
            return [UIImage imageNamed:@"64GraphicsAvatarSad"];
        case IPSAKMoodDisgusted:
            return [UIImage imageNamed:@"64GraphicsAvatarDisgusted"];
        case IPSAKMoodContempt:
            return [UIImage imageNamed:@"64GraphicsAvatarContempt"];
        case IPSAKMoodNeutral:
        default:
            return [UIImage imageNamed:@"64GraphicsAvatarNeutral"];
    }
}

@end
