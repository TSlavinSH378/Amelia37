//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IPSAKDomain;

@protocol IPSDomainPickerViewControllerDelegate;

@interface IPSDomainPickerViewController : UIViewController

+ (instancetype)domainPickerViewController;

@property (nonatomic, weak) id<IPSDomainPickerViewControllerDelegate> delegate;

- (void)showDomains:(NSArray<IPSAKDomain *> *)domains;

- (void)reload;

@end

@protocol IPSDomainPickerViewControllerDelegate <NSObject>
- (void)domainPickerViewControllerLogoutButtonTapped:(IPSDomainPickerViewController *)controller;
- (void)domainPickerViewController:(IPSDomainPickerViewController *)controller didSelectDomain:(IPSAKDomain *)domain;
@end
