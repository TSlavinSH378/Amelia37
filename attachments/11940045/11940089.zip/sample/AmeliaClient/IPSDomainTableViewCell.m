//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSDomainTableViewCell.h"
#import "Styling.h"

@implementation IPSDomainTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.cellBackgroundView.backgroundColor = [UIColor ips_azureColor];
    self.cellBackgroundView.layer.cornerRadius = 8;
    self.titleLabel.textColor = [UIColor whiteColor];
}

@end
