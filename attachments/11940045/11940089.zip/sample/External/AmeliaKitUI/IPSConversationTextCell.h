//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationBubbleCell.h"

@interface IPSConversationTextCell : IPSConversationBubbleCell

@end
