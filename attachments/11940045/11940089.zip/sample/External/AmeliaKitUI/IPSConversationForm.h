//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IPSConversationMessageData.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, IPSConversationFormActionStyle) {
    IPSConversationFormActionStyleDefault = 0,
    IPSConversationFormActionStyleCancel,
    IPSConversationFormActionStyleSubmit,
};

@interface IPSConversationFormAction : NSObject

+ (instancetype)actionWithTitle:(nullable NSString *)title content:(nullable id)content style:(IPSConversationFormActionStyle)style handler:(void(^ __nullable)(IPSConversationFormAction *action))handler;

@property (nullable, nonatomic, readonly) NSString *title;
@property (nonatomic, readonly) IPSConversationFormActionStyle style;
@property (nullable, nonatomic, readonly) id content;
@property (weak) UIButton *button;
@property BOOL submit;

- (void)actionTap:(id)sender;

@end

@protocol IPSConversationFormDelegate;

@interface IPSConversationForm : NSObject <IPSConversationMessageData>

- (instancetype)initWithText:(NSString *)text;

@property (weak, nonatomic) id<IPSConversationFormDelegate> delegate;

@property IPSConversationMessageOrigin origin;

@property IPSConversationMessageType messageType;

@property (copy, readonly) NSString *text;

@property (strong, nullable) id content;

@property (strong, nonatomic) NSArray<IPSConversationFormAction *> *actions;

@property BOOL multipleSelection;

- (void)addAction:(IPSConversationFormAction *)action;
- (void)addActionWithTitle:(nullable NSString *)title content:(nullable id)content style:(IPSConversationFormActionStyle)style handler:(void(^ __nullable)(IPSConversationFormAction *action))handler;
@end

@protocol IPSConversationFormDelegate <NSObject>
- (void)conversationFormDidUpdate:(IPSConversationForm *)form action:(IPSConversationFormAction *)action;
@end

NS_ASSUME_NONNULL_END
