//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationTextCell.h"
#import "IPSConversationMessageData.h"
#import "IPSCollectionViewLayoutAttributes.h"
#import "Styling.h"

@interface IPSConversationTextCell ()
@property (weak, nonatomic) IBOutlet UIView *cellContentView;
@property (weak, nonatomic) IBOutlet UILabel *textLabel;
@end

@implementation IPSConversationTextCell

+ (void)registerInCollectionView:(UICollectionView *)collectionView {
    [collectionView registerNib:[UINib nibWithNibName:@"IPSConversationTextCell" bundle:nil] forCellWithReuseIdentifier:@"textCell"];
}

+ (instancetype)dequeueCellInCollectionView:(UICollectionView *)collectionView forIndexPath:(NSIndexPath *)indexPath {
    return [collectionView dequeueReusableCellWithReuseIdentifier:@"textCell" forIndexPath:indexPath];
}

+ (instancetype)sizingCell {
    return [[UINib nibWithNibName:@"IPSConversationTextCell" bundle:nil] instantiateWithOwner:nil options:nil].firstObject;
}

- (CGSize)preferredLayoutSizeFittingSize:(CGSize)size {
    
    CGRect originalFrame = self.frame;
    CGFloat originalPreferredMaxLayoutWidth = self.textLabel.preferredMaxLayoutWidth;
    
    self.textLabel.preferredMaxLayoutWidth = size.width;
    
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
    
    [self setNeedsLayout];
    [self layoutIfNeeded];
    self.textLabel.preferredMaxLayoutWidth = self.textLabel.bounds.size.width;
    
    CGSize computedSize = [self systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
    
    self.frame = originalFrame;
    self.textLabel.preferredMaxLayoutWidth = originalPreferredMaxLayoutWidth;
    
    return computedSize;
}

- (void)configure:(id<IPSConversationMessageData>)message {
    if (message.messageType == IPSConversationMessageTypeInformation) {
        self.textLabel.font = [UIFont systemFontOfSize:13];
        self.cellContentView.backgroundColor = [UIColor whiteColor];
        self.textLabel.textColor = [UIColor ips_coolGreyColor];
    } else {
        self.textLabel.font = [UIFont systemFontOfSize:15];
        if (message.origin == IPSConversationMessageOriginRemote) {
            self.cellContentView.backgroundColor = [UIColor ips_paleGreyColor];
            self.textLabel.textColor = [UIColor blackColor];
        } else {
            self.cellContentView.backgroundColor = [UIColor ips_azureColor];
            self.textLabel.textColor = [UIColor whiteColor];
        }
    }
    
    self.textLabel.text = [message text];
}

@end
