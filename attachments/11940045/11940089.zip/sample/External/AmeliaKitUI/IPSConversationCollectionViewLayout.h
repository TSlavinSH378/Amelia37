//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol IPSConversationMessageData;


@interface IPSConversationCollectionViewLayout : UICollectionViewLayout
@property UIEdgeInsets sectionInset;
@property CGFloat minimumLineSpacing;
@end

@protocol IPSConversationCollectionViewLayoutDelegate <UICollectionViewDelegateFlowLayout>
@optional
- (id<IPSConversationMessageData>)messageForcollectionView:(UICollectionView *)collectionView layout:(IPSConversationCollectionViewLayout *)layout atIndexPath:(NSIndexPath *)indexPath;
@end
