//
//  IPSAKBpnExecutionEvent.h
//  AmeliaKit
//
//  Created by Yulong Yang on 3/8/18.
//  Copyright © 2018 IPsoft. All rights reserved.
//

#import <AmeliaKit/AmeliaKit.h>

typedef NS_ENUM(NSInteger, IPSAKBpnProcessEvent) {
    PROCESS_STARTED_EVENT,
    TASK_STARTED_EVENT,
    TASK_COMPLETION_EVENT,
    PROCESS_SUSPENDED_EVENT,
    PROCESS_RESUMED_EVENT,
    PROCESS_ABORTED_EVENT,
    PROCESS_COMPLETED_EVENT
};
@interface IPSAKBpnExecutionEvent : IPSAKObject
@property (nonatomic,copy,readonly) NSString *eventId;
@property (nonatomic,assign, readonly) IPSAKBpnProcessEvent bpnProcessEvent;
@end
