//
//  IPSAKConfiguration+Security.h
//  AmeliaClient
//
//  Created by Yulong Yang on 3/8/18.
//  Copyright © 2018 IPsoft. All rights reserved.
//

#import <AmeliaKit/AmeliaKit.h>


@interface IPSAKConfiguration (Security)
@property (nonatomic) BOOL allowAllHosts;

@end

