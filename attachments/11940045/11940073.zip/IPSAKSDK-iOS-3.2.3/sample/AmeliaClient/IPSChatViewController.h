//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IPSAKChat;

@protocol IPSChatViewControllerDelegate;

@interface IPSChatViewController : UIViewController

+ (instancetype)chatViewController:(IPSAKChat *)chat;

@property (weak, nonatomic) id<IPSChatViewControllerDelegate> delegate;

@end

@protocol IPSChatViewControllerDelegate <NSObject>
- (void)chatViewControllerDidClose:(IPSChatViewController *)controller;
@end
