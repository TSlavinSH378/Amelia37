//
//  IPSConversationHtmlContentCell.m
//  AmeliaClient
//
//  Created by Yulong Yang on 7/21/17.
//  Copyright © 2017 IPsoft. All rights reserved.
//
//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationHtmlContentCell.h"
#import "IPSConversationMessageData.h"
#import "IPSCollectionViewLayoutAttributes.h"
#import "Styling.h"

@interface IPSConversationHtmlContentCell ()
@property (weak, nonatomic) IBOutlet UITextView *textView;
@end

@implementation IPSConversationHtmlContentCell
+ (void)registerInCollectionView:(UICollectionView *)collectionView {
    [collectionView registerNib:[UINib nibWithNibName:@"IPSConversationHtmlContentCell" bundle:nil] forCellWithReuseIdentifier:@"HtmlContentCell"];
}

+ (instancetype)dequeueCellInCollectionView:(UICollectionView *)collectionView forIndexPath:(NSIndexPath *)indexPath {
    return [collectionView dequeueReusableCellWithReuseIdentifier:@"HtmlContentCell" forIndexPath:indexPath];
}

+ (instancetype)sizingCell {
    IPSConversationHtmlContentCell *cell= [[UINib nibWithNibName:@"IPSConversationHtmlContentCell" bundle:nil] instantiateWithOwner:nil options:nil].firstObject;
    return cell;
}

- (CGSize)preferredLayoutSizeFittingSize:(CGSize)size {
    CGSize preferedSize = [self.textView sizeThatFits:CGSizeMake(size.width, FLT_MAX)];
    return preferedSize;
}

- (void)configure:(id<IPSConversationMessageData>)message {
    
    self.textView.font = [UIFont systemFontOfSize:15];
    if (message.origin == IPSConversationMessageOriginRemote) {
        self.textView.backgroundColor = [UIColor ips_paleGreyColor];
    } else {
        self.textView.backgroundColor = [UIColor ips_azureColor];
    }
    if(message.attributedText){
        self.textView.attributedText = message.attributedText;
    }else{
        self.textView.text = @"";
    }
}
@end

