//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSSettingsViewController.h"
#import "NSUserDefaults+Amelia.h"
#import "Styling.h"

@interface IPSSettingsViewController ()
@property (weak, nonatomic) IBOutlet UISwitch *anonymousLoginSwitch;
@property (weak, nonatomic) IBOutlet UITextField *serverTextField;

@end

@implementation IPSSettingsViewController

+ (instancetype)settingsViewController {
    return [[UIStoryboard storyboardWithName:@"Settings" bundle:nil] instantiateInitialViewController];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"Developer settings";
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(doneTap:)];
    
    UIColor *tintColor = [UIColor ips_azureColor];
    [self.navigationController.navigationBar ips_makeTransparent];
    self.anonymousLoginSwitch.onTintColor = tintColor;
    
    self.anonymousLoginSwitch.on = [NSUserDefaults standardUserDefaults].ips_anonymousAllowed;
    self.serverTextField.text = [NSUserDefaults standardUserDefaults].ips_host;
}

- (void)doneTap:(id)sender {
    [self.serverTextField resignFirstResponder];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)toggleSwitch:(id)sender {
    if (sender == self.anonymousLoginSwitch) {
        [NSUserDefaults standardUserDefaults].ips_anonymousAllowed = self.anonymousLoginSwitch.isOn;
    }
}

- (IBAction)serverFieldUpdated:(id)sender {
    [NSUserDefaults standardUserDefaults].ips_host = self.serverTextField.text;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    cell.tintColor = [UIColor ips_azureColor];
}

@end
