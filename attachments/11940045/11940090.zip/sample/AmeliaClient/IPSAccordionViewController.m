//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAccordionViewController.h"
#import "IPSAccordionHeaderView.h"
#import "IPSAccordionImageCell.h"

@interface IPSAccordionField ()
@property (copy, nonatomic) NSString *text;
@property (copy, nonatomic) NSString *detailText;
@property (strong, nonatomic) UIImage *contentImage;
@end

@implementation IPSAccordionField

- (instancetype)initWithText:(NSString *)text detailText:(NSString *)detailText; {
    self = [super init];
    if (self) {
        _text = text;
        _detailText = detailText;
    }
    return self;
}

- (instancetype)initWithContentImage:(UIImage *)image {
    self = [super init];
    if (self) {
        _contentImage = image;
    }
    return self;
}

@end

@implementation IPSAccordionSection

- (instancetype)init {
    self = [super init];
    if (self) {
        _fields = [NSMutableArray array];
    }
    return self;
}

- (void)addField:(IPSAccordionField *)field {
    [self.fields addObject:field];
}

@end

@interface NSString (Base64Image)
- (UIImage *)ips_base64Image;
@end

@implementation NSString (Base64Image)

- (UIImage *)ips_base64Image {
    NSURL *url = [NSURL URLWithString:self];
    if (url == nil) {
        return nil;
    }
    
    NSData *imageData = [NSData dataWithContentsOfURL:url];
    if (imageData == nil) {
        return nil;
    }
    
    return [UIImage imageWithData:imageData];
}

@end

@interface IPSAccordionViewController ()
@property (strong) NSDictionary *integration;
@property (strong) NSArray<IPSAccordionSection *> *sections;
@end

@implementation IPSAccordionViewController

+ (instancetype)accordionViewControllerWithIntegrationMessage:(NSDictionary *)integration {
    IPSAccordionViewController *controller = [[UIStoryboard storyboardWithName:@"Accordion" bundle:nil] instantiateViewControllerWithIdentifier:@"accordionViewController"];
    controller.integration = integration;
    return controller;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[UINib nibWithNibName:@"IPSAccordionHeaderView" bundle:nil] forHeaderFooterViewReuseIdentifier:@"sectionHeader"];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 44;
    [self buildDataSource];
}

- (void)buildDataSource {
    self.title = self.integration[@"title"];
    
    NSMutableArray *sections = [NSMutableArray array];
    
    for (NSDictionary *child in self.integration[@"children"]) {
        
        IPSAccordionSection *section = [[IPSAccordionSection alloc] init];
        
        {
            section.title = child[@"title"];
            section.actionProcess = child[@"actionProcess"];
        }
        
        {
            NSDictionary *selectionUtteranceMetadata = child[@"selectionUtteranceMetadata"];
            section.staticUtterance = selectionUtteranceMetadata[@"staticUtterance"];
            if (section.staticUtterance == nil) {
                section.staticUtterance = @"None";
            }
        }
        
        NSString *imageBase64 = child[@"imageBase64"];
        if ([imageBase64 isKindOfClass:[NSString class]]) {
            UIImage *image = [imageBase64 ips_base64Image];
            if (image != nil) {
                IPSAccordionField *field = [[IPSAccordionField alloc] initWithContentImage:image];
                [section addField:field];
            }
        }
        
        {
            NSArray *sectionFields = child[@"sectionFields"];
            for (NSDictionary *sectionField in sectionFields) {
                IPSAccordionField *field = [[IPSAccordionField alloc] initWithText:sectionField[@"label"] detailText:sectionField[@"valueForDisplay"]];
                [section addField:field];
            }
        }
        
        [sections addObject:section];
    }
    
    self.sections = sections;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.sections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    IPSAccordionSection *accordionSection = self.sections[section];
    return accordionSection.fields.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    IPSAccordionSection *accordionSection = self.sections[indexPath.section];
    IPSAccordionField *field = accordionSection.fields[indexPath.row];
    
    if (field.contentImage != nil) {
        IPSAccordionImageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"imageCell" forIndexPath:indexPath];
        cell.contentImageView.image = field.contentImage;
        return cell;
    } else {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"sectionFieldCell" forIndexPath:indexPath];
        cell.textLabel.text = field.text;
        cell.detailTextLabel.text = field.detailText;
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 44;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    IPSAccordionHeaderView *headerView = (IPSAccordionHeaderView *)[self.tableView dequeueReusableHeaderFooterViewWithIdentifier:@"sectionHeader"];
    IPSAccordionSection *accordionSection = self.sections[section];
    [headerView configure:accordionSection];
    __weak __typeof__(self) weakSelf = self;
    headerView.onEditTap = ^(IPSAccordionSection *section) {
        NSString *action = section.actionProcess[@"processName"];
        NSDictionary *arguments = section.actionProcess[@"processArgs"];
        [weakSelf.delegate accordionViewController:weakSelf runAction:action arguments:arguments message:section.staticUtterance];
    };
    return headerView;
}



@end
