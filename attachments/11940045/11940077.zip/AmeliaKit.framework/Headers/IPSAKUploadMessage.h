//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class IPSAKMessage;
@class IPSAKSupportedType;
/**
 The `IPSAKUploadMessage` class contains information about what kind of file Amelia expects.
 */
@interface IPSAKUploadMessage : NSObject

/**
 Initializes the object using the given message.
 @param error If an error occurs, this pointer is set to an `NSError` containing information about the error.
 */
- (instancetype _Nullable)initWithMessage:(IPSAKMessage *)message error:(NSError **)error;

/**
 The types of file that should be uploaded.
 */
@property (strong,nonatomic,readonly) NSArray<IPSAKSupportedType *>* supportedTypes;
@property (nonatomic,copy,readonly) NSString *cmObjectType;
@property (nonatomic,assign,readonly) long maxSize;
@property (nonatomic,assign,readonly) BOOL multiple;
@property (nonatomic,assign,readonly) BOOL cancellable;

@end

NS_ASSUME_NONNULL_END
