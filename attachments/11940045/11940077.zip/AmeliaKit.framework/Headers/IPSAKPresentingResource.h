//
//  IPSAKResourceMetaData.h
//  AmeliaKit
//
//  Created by Yulong Yang on 11/28/17.
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IPSAKObject.h"

@interface IPSAKPresentingResource : IPSAKObject

typedef NS_ENUM(NSInteger, IPSAKContentDisplayOption) {
    /**
     * eg.,only downloadable when resource is clicked
     */
    NO_PREVIEW,
    /**
     * Only display a thumbnail of the resource
     */
    INLINE_ONLY,
    /**
     * popup a new window to display a resource when resource is loaded,
     * in the mean time, display a thumbnail of the reosurce,
     * and when clicked, pop up a new window to display the resource
     */
    POPUP_AND_INLINE,
    /**
     * display a thumbnail of the reosurce,
     * and when clicked, pop up a new window to display the resource
     */
    INLINE_AND_POPUP,
    /**
     * only popping up a new window to show the resource
     */
    POPUP_ONLY,
};
/**
 * Object identifier in the CMS.
 */
@property (copy,nonatomic,readonly) NSString *objectId;
/**
 * Name of the bucket the file lives.
 */
@property (copy,nonatomic,readonly) NSString *bucketName;
/**
 * Filename.
 */
@property (copy,nonatomic,readonly) NSString *fileName;
/**
 * Human readable Label.
 */
@property (copy,nonatomic,readonly) NSString *label;
/**
 * Description, optional, (alt text).
 */
@property (copy,nonatomic,readonly) NSString *resourceDescription;
/**
 * the file is downloadable by user
 */
@property (assign,nonatomic,readonly) BOOL download;
/**
 * indication of whether file details should display along with the file or not
 */
@property (assign,nonatomic,readonly) BOOL displayResourceDetails;
/**
 * style of displaying the file
 */
@property (nonatomic, readonly) IPSAKContentDisplayOption displayOption;
/**
 *    The size of the file in bytes. e.g. 10020.
 */
@property (copy,nonatomic, readonly) NSString* byteCount;

/**
 * The size of the file in human readable format. e.g. 100.2 kB.
 */
@property (copy,nonatomic, readonly) NSString *fileSize;


@end
