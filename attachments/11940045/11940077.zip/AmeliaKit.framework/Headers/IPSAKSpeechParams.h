//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 The `IPSAKSpeechParams` class controls the initial state whether the SDK should
 speak the messages Amelia sends.
 */
@interface IPSAKSpeechParams : NSObject
/**
 Whether speech is enabled at all.
 */
@property(nonatomic) BOOL enabled;
/**
 Whether the SDK should start muted or not.
 */
@property(nonatomic) BOOL muted;
@end
