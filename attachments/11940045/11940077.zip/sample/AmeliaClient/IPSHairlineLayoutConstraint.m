//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSHairlineLayoutConstraint.h"

@implementation IPSHairlineLayoutConstraint

- (void)awakeFromNib {
    [super awakeFromNib];
    self.constant = self.constant / [UIScreen mainScreen].scale;
}

@end
