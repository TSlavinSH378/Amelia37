//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSDomainForm.h"

@implementation IPSDomainForm

- (IPSConversationMessageOrigin)origin {
    return IPSConversationMessageOriginRemote;
}

- (IPSConversationMessageType)messageType {
    return IPSConversationMessageTypeCustom;
}

- (NSInteger)actionCount {
    return 1;
}

- (id)mediaContent {
    return nil;
}

@end
