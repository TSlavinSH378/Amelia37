//
//  IPSConversationHtmlContentCell.h
//  AmeliaClient
//
//  Created by Yulong Yang on 7/21/17.
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationBubbleCell.h"

@interface IPSConversationHtmlContentCell : IPSConversationBubbleCell

@end
