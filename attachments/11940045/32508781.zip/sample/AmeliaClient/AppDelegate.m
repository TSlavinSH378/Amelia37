//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "AppDelegate.h"
#import "Styling.h"
#import "NSUserDefaults+Amelia.h"

#define LOG_TO_FILE 0
#define CUSTOM_URL_SCHEME @"ameliaclientappv3"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [UINavigationBar appearance].tintColor = [UIColor ips_azureColor];
    
#if LOG_TO_FILE
    NSArray *allPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [allPaths objectAtIndex:0];
    NSDate *date = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    formatter.dateFormat = @"yyMMdd_HHmmss";
    NSString *filename = [NSString stringWithFormat:@"nslog_%@.txt",  [formatter stringFromDate:date]];
    NSString *pathForLog = [documentsDirectory stringByAppendingPathComponent:filename];
    freopen([pathForLog cStringUsingEncoding:NSASCIIStringEncoding],"a+",stderr);
#endif
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (BOOL)application:(UIApplication *)application openURL:(nonnull NSURL *)url options:(nonnull NSDictionary<UIApplicationOpenURLOptionsKey,id> *) options{
    NSString* urlString = [url absoluteString];
      NSString* schemeWithLogin = [NSString stringWithFormat:@"%@://login",CUSTOM_URL_SCHEME];
      
      if([urlString rangeOfString:schemeWithLogin].location != NSNotFound ){
          NSArray * array = [urlString componentsSeparatedByString:@"session="];
          if([array count] == 2){
              NSDictionary * sessionDict = [[NSDictionary alloc]initWithObjectsAndKeys: [array objectAtIndex:1], @"session", nil];
              [[NSNotificationCenter defaultCenter] postNotificationName:@"SSOSignedIn"
                                                                  object:sessionDict];
          }else{
              NSLog(@"NO session info in the redirect URL %@", urlString);
          }
      }
    return YES;
}

@end
