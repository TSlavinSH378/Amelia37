//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSIntegrationView.h"

@interface IPSIntegrationView ()
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) NSDictionary *integration;
@end

@implementation IPSIntegrationView

- (void)configure:(NSDictionary *)integration {
    self.titleLabel.text = [NSString stringWithFormat:@"Tap to view %@", integration[@"title"]];
    self.integration = integration;
}

- (IBAction)integrationTap:(id)sender {
    [self.delegate integrationViewTap:self];
}

@end
