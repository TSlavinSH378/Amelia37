//
//  IPSAKConversation.h
//  AmeliaKit
//
//  Created by Yulong Yang on 6/11/19.
//  Copyright © 2019 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IPSAKMessage.h"
@class IPSAKUploadMessage;
@class IPSAKDownloadMessage;
@protocol IPSAKChatConversationDelegate;
/**
 Conversation object that contains information regarding a conversation.
 Messages in the conversation can be received by conforming to the protocol 'IPSAKChatConversationDelegate'
 */
@interface IPSAKConversation : NSObject
/**
 Conversation ID
 */
@property (readonly,strong,nonatomic) NSString * conversationId;
/**
 Conversation's session ID (not Amelia session)
 */
@property (readonly,strong,nonatomic) NSString * sessionId;
/**
 Conversation's subscribe Id
 */
@property (readonly,strong,nonatomic) NSString * subscribeId;
/**
 Conversation's receipt Id
 */
@property (readonly,strong,nonatomic) NSString * receiptId;
/**
 Number of successful connections(including reconnections) that have established for the conversation.
 */
@property (readonly,nonatomic) int successfulConnectionCount;
/**
 Whether input is enabled for the conversation
 */
@property (readonly,nonatomic) BOOL inputEnabled;
/**
 Whether input is secured for the conversation at this moment.
 */
@property (readonly,nonatomic) BOOL inputSecured;
/**
 Whether conversation is muted or not
 @note speechParams are sdk level voice control. This is conversation level.
 */
@property (readonly,nonatomic) BOOL muted;
/**
 Whether this is a conversation picked up by joining a conversation as an agent
 */
@property (readonly,nonatomic) BOOL isAgentConversation;
/**
 Whether this is a pre-existing conversation (ex, created by joining to a previous conversation that's still open)
 */
@property (readonly,nonatomic) BOOL existingConversation;
/**
 Current Amelia's mood
 */
@property (readonly,nonatomic) IPSAKMoodType currentMood;
/**
 The other end of the conversation. Usually this is Amelia. Though it could also be a human agent.
 */
@property (readonly,nonatomic, copy) NSString *conversationPartnerName;
/**
 The minimum time (in milliseconds) between messages before the user is considered idle. Default: 300000 (5 minutes)
 */
@property (readonly,nonatomic) NSInteger minIdleTime;

/**
 Adds a variable time component (in milliseconds) to the min idle time. Default: 600000 (10 minutes)
 */
@property (readonly,nonatomic) NSInteger varIdleTime;
/**
 Arrival time of the last message of type:
 IPSAKMessageTypeOutboundEcho
 IPSAKMessageTypeOutboundText
 IPSAKMessageTypeOutboundIntegration
 IPSAKMessageTypeOutboundPresentMessage
 IPSAKMessageTypeOutboundFormInputMessage
 */
@property (readonly,nonatomic, strong) NSDate *timeOfLastMessage;
/**
 The object that acts as the chat delegate of the conversation.
 */
@property (weak,nonatomic) id<IPSAKChatConversationDelegate> delegate;
/**
 mute the current conversation
 */
-(void)mute;
/**
 unmute the current conversation
 */
-(void)unmute;
@end
/**
  Set ChatConversationDelegate in IPSAKConversation to listen for messages coming in
 */
@protocol IPSAKChatConversationDelegate<NSObject>
@optional
/**
 Tells the delegate that a message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that an echo message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveEchoMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that a final text message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveFinalTextMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that Amelia is ready to take user input.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveAmeliaReadyMessage: (IPSAKMessage *)message;
/**
 Tells the delegate that a escalation started message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveEscalationStartedMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that an ack request message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveAckRequestMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that a session closed message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveSessionClosedMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that a conversation closed message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveConversationClosedMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that an integration message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveIntegrationMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that a form input message has been received
 */
-(void)conversation:(IPSAKConversation*)conversation didReceiveFormInputMessage:(IPSAKMessage *)message;
/**
 tells the delegate that a bpn execution event message has been receivede
 */
-(void)conversation:(IPSAKConversation*)conversation didReceiveBpnExecutionEventMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that an agent session changed message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveAgentSessionChangedMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that a final replay message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveReplayFinishedMessage:(IPSAKMessage *)message;
/**
 Tells the delegate that a download message has been received from Amelia.
 */
- (void)conversation:(IPSAKConversation*)conversation didReceiveDownloadMessage:(IPSAKDownloadMessage *)message;
/**
 Tells the delegate that an upload is requested.
 */
- (void)conversation:(IPSAKConversation*)conversation uploadRequested:(IPSAKUploadMessage *)uploadRequest;
/**
 Tells the delegate that an upload has successfully completed.
 */
- (void)conversationFileUploadSuccess:(IPSAKConversation*)conversation;
/**
 Tells the delegate that an upload failed.
 */
- (void)conversation:(IPSAKConversation*)conversation uploadFailWithError:(NSError *)error;
/**
 Tells the delegate whether Amelia is ready to receive input or not.
 */
- (void)conversation:(IPSAKConversation*)conversation inputEnabled:(BOOL)enabled;
/**
 Tells the delegate whether user's input should be secured.
 */
- (void)conversation:(IPSAKConversation*)conversation inputSecured:(BOOL)enabled;

/**
 Tells the delegate that input is currently blocked.
 */
- (void)conversationInputBlocked:(IPSAKConversation*)conversation;

/**
 Tells the delegate the SDK will start speaking.
 */
- (void)conversationWillStartSpeaking:(IPSAKConversation*)conversation;
/**
 Tells the delegate the SDK has stopped speaking.
 */
- (void)conversationDidStopSpeaking:(IPSAKConversation*)conversation;
/**
 Tells the delegate that Amelia's mood has changed.
 */
- (void)conversation:(IPSAKConversation*)conversation moodChangeFrom:(IPSAKMoodType)fromMood to:(IPSAKMoodType)toMood;
/**
 Tells the delegate that the chat session has ended when the server initiated the ending.
 */
- (void)conversationDidEnd:(IPSAKConversation*)conversation;
/**
 Tells the delegate that then conversation is disconnected unexpectedly.
 */
- (void)conversationDidDisconnect:(IPSAKConversation*)conversation;
/**
 Tells the delegate that the conversation is reconnected after a previous disconnect.
 */
- (void)conversationDidReconnect:(IPSAKConversation*)conversation;
/**
 Tells the delegate that an error occurred while chatting.
 */
- (void)conversation:(IPSAKConversation*)conversation error:(NSError *)error;
@end
