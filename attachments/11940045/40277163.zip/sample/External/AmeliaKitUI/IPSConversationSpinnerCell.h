//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationBubbleCell.h"

@interface IPSConversationSpinnerCell : IPSConversationBubbleCell

@end
