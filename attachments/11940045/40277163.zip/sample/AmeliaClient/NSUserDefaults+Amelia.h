//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 Posted when a setting is changed that requires creating a new `ISPAKChat` instance.
 */
extern NSNotificationName const IPSChatSettingsUpdateNotification;

@interface NSUserDefaults (Amelia)
- (void)postChatSettingsUpdateNotification;
@property (nonatomic, copy, setter=ips_setHost:) NSString *ips_host;
@property (nonatomic, setter=ips_setAnonymousAllowed:) BOOL ips_anonymousAllowed;
@property (nonatomic, setter=ips_setAutoConnect:) BOOL ips_autoConnect;
@property (nonatomic, setter=ips_setAutoDomain:) BOOL ips_autoDomain;
@property (nonatomic, copy, setter=ips_setUserName:) NSString *ips_username;
@property (nonatomic, copy, setter=ips_setPassword:) NSString *ips_password;

@end
