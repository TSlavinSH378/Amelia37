//
//  IPSAKEscalationRequest.h
//  AmeliaKit
//
//  Created by Yulong Yang on 12/18/18.
//  Copyright © 2018 IPsoft. All rights reserved.
//

#import "IPSAKEscalationAlert.h"
/**
 Escalation types
 */
typedef NS_ENUM(NSInteger, IPSAKEscalationType) {
    IPSAKEscalationTypeNormal,
    IPSAKEscalationTypeAssigned,
};
/**
 A request containing the details about the escalation
 */
@interface IPSAKEscalationRequest : IPSAKEscalationAlert
@property (nonatomic,strong) NSString* escalationId;
@property (nonatomic,strong) NSString* agentId;//agent's user ID
@property (nonatomic,strong) NSString* agentName;
@property (nonatomic,strong) NSString* conversationId;
@property (nonatomic,strong) NSString* domainName;
@property (nonatomic,strong) NSString* domainCode;
@property (nonatomic) IPSAKEscalationType escalationType;
@property (nonatomic) int escalationTimeout;
@property (nonatomic,strong) NSString* endUserName;
@property (nonatomic,strong) NSDictionary *escalationAttributes;
@end

