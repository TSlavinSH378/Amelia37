//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IPSAKDownloadMessage.h"
#import "IPSAKMessage.h"
#import "IPSAKConversation.h"
#import "IPSAKTrafficMonitor.h"

NS_ASSUME_NONNULL_BEGIN

@class IPSAKAuthSystem;
@class IPSAKConfiguration;
@class IPSAKDomain;
@class IPSAKFormInputData;
@class IPSAKLoginOptions;
@class IPSAKUploadMessage;
@class IPSAKUser;
@class IPSAKAppConfig;
@class IPSAKEscalationRequest;
@class IPSAKEscalationAlert;
@class IPSAKJoinConversationRequest;
@class IPSAKConversationInfo;
@protocol IPSAKChatSessionDelegate;
@protocol IPSAKEscalationDelegate;

/**
 Constants indicating the type of reconnect option.
 */
typedef NS_ENUM(NSInteger, IPSAKReconnectOption) {
    /// There is still a valid session, reconnect is possible.
    IPSAKReconnectOptionCanReconnect,
    /// The session is not valid, reconnect is not possible.
    IPSAKReconnectOptionInvalidSession,
    /// Could not determine if it is possible to reconnect or not.
    IPSAKReconnectOptionUnknown
};

/**
The version of the Amelia protocol this version of the SDK supports. 
 */
extern NSString *const IPS_AMELIA_PROTOCOL_VERSION;

/**
 Sdk main entry point.
 */
@interface IPSAKChat : NSObject

/**
 Creates a chat with the specified configuration.
 
 @param configuration A configuration object that specifies certain behaviors, such as if anonymous login is allowed and how to select which domain to join. The configuration also contains the URL for the Amelia instance.
 
 @return An `IPSAKChat` instance.
 */
+ (instancetype)chatWithConfiguration:(IPSAKConfiguration *)configuration;

/// The object that acts as the session delegate of the chat.
@property (nonatomic, weak) id<IPSAKChatSessionDelegate> sessionDelegate;

/// The object that acts as the escalation delegate of the Amelia chat.
@property (nonatomic, weak) id<IPSAKEscalationDelegate> escalationDelegate;

/// The list of available domains
@property (nullable, nonatomic, strong, readonly) NSArray<IPSAKDomain *> *domains;

/// The current selected domain.
@property (nullable, strong, nonatomic, readonly) IPSAKDomain *domain;

/// The currently logged on user.
@property (nullable, nonatomic, strong, readonly) IPSAKUser *user;


/**
 Whether the SDK should try to reconnect to a conversation when the conversation is unexpectedly disconnected.
 
 @note The current implementation just tries to reconnect every 2 seconds. Should be changed to use the reachability API.
 */
@property (nonatomic) BOOL autoReconnect;

#pragma mark - Session
/**
 initialize sdk so that an appConfig will be returned, which contains server info such as timeouts, anonymous user information, etc..
 */
-(void)initialize;
/**
 Start an anonymous conversation
 If anonymous conversation is not allowed, it'll trigger loginRequiredWithAuthSystems:
 Initiate the process of starting a new conversation. Starting a conversation is a multistep process that requires several
 network requests and the implementer of the `sessionDelegate` may need to respond to events to complete the process.
 */
- (void)startNewConversation;
/**
 Start an anonymous conversation
 If anonymous conversation is not allowed, it'll trigger loginRequiredWithAuthSystems:
 start new conversation with initialAttribute pairs and intialBpnVariable pairs. Either of the them can be nil.
 */
-(void)startNewConversationWithInitialAttributes:(nullable NSDictionary *)initialAttributes andInitialBpnVariables:(nullable NSDictionary*) initialBpnVariables;

/**
 start a new covnersaton using existing session.
 Must be in a valid session.
 @param conversation the conversation to reset
 */
-(void)resetConversation:(IPSAKConversation*)conversation;
/**
 start a new conversation with a different domain
 from current selected domain.Default domain will
 be selected if domain is nil.
 @param conversation the conversation to reset
 @param domain the domain to select once conversation is reset
 */
-(void)resetConversation:(IPSAKConversation*)conversation withDomain:(IPSAKDomain*)domain;


/**
 Cancel an ongoing process of establishing a session.
 
 @note Have no effect if a conversation is started.
 */
- (void)cancel;

/**
 Continue the current start conversation process, starting from the current state.
 
 @note It is possible to call `retry` after receiving any type of error, but other than some type of network errors probaly needs to solved in another way.
 */
- (void)retry;

/**
 Step up from an anonymous login to an authenticated login.
 */
- (void)stepUp;

/**
 Performs a login using the provided login options. Normally called in response to a `chat:loginRequiredWithAuthSystems:`.
 
 @param options The options to use when logging in.
 */
- (void)login:(IPSAKLoginOptions *)options;

/**
 Selects which domain to use when starting a new conversation. Normally called in response to a `chat:domainSelectionRequired:`.
 pass in null domain to select default user domain
 */
- (void)selectDomain:(IPSAKDomain *)domain;
/**
 Logs out current logged in user.
 */
- (void)logout;

/**
 Checks if the session can be reconnected (session is still alive)
 
 @param completionHandler a callback that returns whether the current session can be reconnect or is an invalid session.
 @param sendSessionError The option to suppress any session error during the reconenct.
 */
- (void)reconnectSession:(void(^)(IPSAKReconnectOption option))completionHandler andReportSessionError:(BOOL) sendSessionError;

/**
 Ends the current conversation.
 */
- (void)endConversation:(IPSAKConversation*) conversation;
/**
 Accept the escalation request sent by Amelia.
 */
-(void)acceptEscalationRequest:(IPSAKEscalationRequest*)escalationRequest;
/**
 Reject the escalation request sent by Amelia.
 */
-(void)rejectEscalationRequest:(IPSAKEscalationRequest*)escalationRequest;
/**
 Accept request to join conversation.
 */
-(void)acceptConversationJoinRequest:(IPSAKJoinConversationRequest*)conversationJoinRequest;
/**
 Join an existing conversation with conversation info
 This is in response to chat:onOpenConversationsLoaded:. The open conversations can be joined and replayed with this method.
 After successful call, conversationStart: will call back with the new conversation started
 */
-(void)joinConversation:(IPSAKConversationInfo*)conversationInfo;
#pragma mark - Chat

/**
 Ask Amelia a question.
 @param question the message to send.
 @param conversation the conversation to ask the question in
 */
- (void)ask:(NSString *)question inConversation:(nonnull IPSAKConversation *)conversation;

/**
 Alias for `ask:`.
 @param statement the message to send.
 @param conversation the conversation to say the statement to
 */
- (void)say:(NSString *)statement inConversation:(nonnull IPSAKConversation *)conversation;

/**
 Send to Amelia custom conversation attributes during the chat
 Conversation must be started before the attributes to be sent.
 @param attributes key/value map
 @param conversation the conversation to send the attributes to
 */

-(void)sendCustomConversationAttributes:(NSDictionary*)attributes inConversation:(nonnull IPSAKConversation *)conversation;
/**
 Submit a form to Amelia.
 
 @note This method should be uses to respond to a message that includes `formInputData`
 
 @param form The form included in the message.
 @param message The text to speak in the submission
 @param conversation The conversation to submit the form to
 */
- (void)submitForm:(IPSAKFormInputData *)form message:(NSString *_Nullable)message inConversation:(nonnull IPSAKConversation *)conversation;

/**
 Run the named BPN process on Amelia.
 
 @param processName The name of the BPN process to run.
 @param processArgs The arguments to pass to the process.
 @param message A custom message to send.
 @param conversation the conversation to run the bpn in
 */
- (void)runAction:(NSString *)processName arguments:(NSDictionary *)processArgs message:(NSString *)message inConversation:(nonnull IPSAKConversation *)conversation;
/**
 cancel file upload, for example, when client sides does not support upload of certain file types
 @param conversation the conversaton to upload file to
 */
- (void)cancelFileUploadInConversation:(nonnull IPSAKConversation*)conversation;
/**
 Uploads the provided data to Amelia using `uploadFileData:filename:mimetype:` where mimetype is determined from the the passed in data.
 @param data file data
 @param filename name of the file
 @param conversation the conversation to upload file to
 */
- (void)uploadFileData:(NSData *)data filename:(NSString *)filename inConversation:(nonnull IPSAKConversation*)conversation;

/**
 Uploads the provided data to Amelia.
 
 @note The result of the upload is reported on the `conversationDelegate` using `chatUploadSuccess:` or `chat:uploadFailWithError:`.
 @param data The data to upload.
 @param filename The name of the file.
 @param mimetype The mimetype of the data.
 @param conversation the conversation to send the file to
 */
- (void)uploadFileData:(NSData *)data
              filename:(NSString *)filename
              mimetype:(NSString *)mimetype inConversation:(IPSAKConversation*)conversation;

/**
 Tells the SDK to stop playing the audio and forget all the audios which haven't been played. Set isSpeaking to No.
 */
- (void)stopPlayAudio;

#pragma mark - Debug

/**
 A debug delegate that, if set, will be called with raw requests and responses sent to and recevied from the Amelia 
 instance.
 */
@property (nonatomic, weak) id<IPSAKTrafficMonitor> trafficMonitor;

@end

/**
 The `IPSAKChatSessionDelegate` protocol defines the optional methods you implement to make an `IPSAKChat` instance
 functional. Which methods to implement depends on the functionality of your application, but at a minimum the delegate
 should respond to `chatConversationStart:` and present a chat UI.
 */
@protocol IPSAKChatSessionDelegate<NSObject>

@optional

#pragma mark - Anonymous login
/**
 called back at the time time of intializing IPSAKChat oboject,
 contains server information including whether anonymous user is allowed and anonymous domains if any
 */
-(void)chatInitialized:(IPSAKChat*)chat withAppConfig:(IPSAKAppConfig *)appConfig;
/**
 Tells the delegate that an anonymous user has been created.
 */
- (void)chatSessionStart:(IPSAKChat *)chat;
/**
 Tells the delegate that a session could not be established, the anonymous login failed.
 */
- (void)chat:(IPSAKChat *)chat sessionFailWithError:(NSError *)error;

#pragma mark - Login

/**
 Tells the delegate that a login is required. To continue the connection process `login:` should be called.
 */
- (void)chat:(IPSAKChat *)chat loginRequiredWithAuthSystems:(NSArray<IPSAKAuthSystem *> *)authSystems;
/**
 Tells the delegate that a login succeeded.
 */
- (void)chatLoginSuccess:(IPSAKChat *)chat;
/**
 Tells the delegate that the session is now logged out.
 */
- (void)chatLogout:(IPSAKChat *)chat;
/**
 Tells the delegate the login failed.
 */
- (void)chat:(IPSAKChat *)chat loginFailWithError:(NSError *)error;

#pragma mark -

/**
 Tells the delegate that an anonymous login has completed successfully.
 */
- (void)chat:(IPSAKChat *)chat didInitUser:(IPSAKUser *)user;

#pragma mark - Domain

/**
 Tells the delegate that a domain must be selected. Call `selectDomain:` to continue the process.
 */
- (void)chat:(IPSAKChat *)chat domainSelectionRequired:(NSArray<IPSAKDomain *> *)domains;
/**
Tells the delegate that the language for the conversation has changed.
*/
- (void)chat:(IPSAKChat *)chat languageChangeFrom:(NSString *)prevLanguageCode to:(NSString *)languageCode;
/**
 Tells the delegate that fethcing the list of domains failed.
 */
- (void)chat:(IPSAKChat *)chat domainFailWithError:(NSError *)error;

#pragma mark - Conversation

/**
 Tells the delegate the a conversation has been started. Events regarding the chat are received on the `IPSAKChatConversationDelegate`
 in IPSAKConversation.h
 */
- (void)chat:(IPSAKChat *)chat conversationStart:(IPSAKConversation*)conversation;
/**
 Tells the delegate that a conversation failed to start.
 */
- (void)chat:(IPSAKChat *)chat conversationFailWithError:(NSError *)error;
/**
 A list of previously open conversations of the user will be returns if there are any.
 They will need to be joined later to be started,  with 'joinConversation:'
 */
- (void)chat:(IPSAKChat *)chat onOpenConversationsLoaded:(NSArray<IPSAKConversationInfo*>*) conversationInfoList;

@end
/**
 This delegates returns escalation events. Only users that have the necessary permissions can receive escalation | join requests
 */
@protocol IPSAKEscalationDelegate<NSObject>
/**
 Received Amelia escalation request
 */
-(void)didReceiveEscalationRequestFromAmelia:(IPSAKEscalationRequest*)escalationRequest;
/**
 Received escalation alert from Amelia to update availability
 */
-(void)didReceiveEscalationAlertFromAmelia:(IPSAKEscalationAlert*)escalationAlert;
/**
 Received request from a user/Amelia to join conversation
 */
-(void)didReceiveConversationJoinRequest:(IPSAKJoinConversationRequest*)conversationJoinRequest;
@end
/**
 The `IPSAKChatConversationDelegate` protocol defines the optional methods you implement to make an `IPSAKChat` instance functional regarding the chat functionality.
 */


NS_ASSUME_NONNULL_END
