//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationForm.h"

@class IPSAKFormInputData;

@interface IPSConversationForm (IPSAKFormInputData)

+ (instancetype)conversationFormWithFormInputData:(IPSAKFormInputData *)formInputData;

@end
