//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSTrafficMonitor.h"

@interface IPSTrafficMonitor ()
@property NSInteger counter;
@property (nonatomic, strong) NSURL *saveURL;
@end

@implementation IPSTrafficMonitor

- (void)startSession {
    self.saveURL = nil;
    self.counter = 0;
    
    NSFileManager *fm = [NSFileManager defaultManager];
    NSURL *documentsDirectory = [fm URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].firstObject;
    if (documentsDirectory == nil) {
        return;
    }
    
    NSDate *date = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    formatter.dateFormat = @"yyMMdd_HHmmss";
    NSString *directoryName = [NSString stringWithFormat:@"Session_%@",  [formatter stringFromDate:date]];
    
    NSURL *saveURL = [documentsDirectory URLByAppendingPathComponent:directoryName];
    NSError *createError = nil;
    if (![fm createDirectoryAtURL:saveURL withIntermediateDirectories:YES attributes:nil error:&createError]) {
        return;
    }
    
    self.saveURL = saveURL;
    NSLog(@"Traffic saved to %@", self.saveURL);
}

- (void)endSession {
    
}

- (void)sentRequest:(NSURLRequest *)request {
    if (self.saveURL == nil) {
        return;
    }
    
    NSString *filename = [self fileNameForRequest:request];
    NSDictionary *headers = request.allHTTPHeaderFields;
    if (headers.count > 0) {
        NSMutableString *headerText = [[NSMutableString alloc] init];
        [headers enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *value, BOOL *stop) {
            [headerText appendFormat:@"%@=%@\n", key, value];
        }];
        
        NSURL *headerSaveURL = [self.saveURL URLByAppendingPathComponent:[NSString stringWithFormat:@"%@_request_headers.txt", filename]];
        NSError *writeError = nil;
        if (![headerText writeToURL:headerSaveURL atomically:NO encoding:NSUTF8StringEncoding error:&writeError]) {
            NSLog(@"Error writing headers to %@", headerSaveURL);
        }
    }
    
    if (request.HTTPBody != nil) {
        NSURL *bodyURL = nil;
        if ([NSJSONSerialization JSONObjectWithData:request.HTTPBody options:kNilOptions error:nil]) {
            bodyURL = [self.saveURL URLByAppendingPathComponent:[NSString stringWithFormat:@"%@_request_body.json", filename]];
        } else {
            bodyURL = [self.saveURL URLByAppendingPathComponent:[NSString stringWithFormat:@"%@_request_body.txt", filename]];
        }
        [request.HTTPBody writeToURL:bodyURL atomically:NO];
    }
}

- (void)receivedResponse:(NSURLResponse *)response withRequest:(NSURLRequest *)request data:(NSData *)data error:(NSError *)error {
    if (self.saveURL == nil) {
        return;
    }
    
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
    NSString *filename = [self fileNameForRequest:request];
    
    NSDictionary *headers = httpResponse.allHeaderFields;
    if (headers.count > 0) {
        NSMutableString *headerText = [[NSMutableString alloc] init];
        [headers enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *value, BOOL *stop) {
            [headerText appendFormat:@"%@=%@\n", key, value];
        }];
        
        NSURL *headerSaveURL = [self.saveURL URLByAppendingPathComponent:[NSString stringWithFormat:@"%@_response_headers.txt", filename]];
        NSError *writeError = nil;
        if (![headerText writeToURL:headerSaveURL atomically:NO encoding:NSUTF8StringEncoding error:&writeError]) {
            NSLog(@"Error writing headers to %@", headerSaveURL);
        }
    }
    
    if (data!= nil) {
        NSURL *bodyURL = nil;
        if ([NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil]) {
            bodyURL = [self.saveURL URLByAppendingPathComponent:[NSString stringWithFormat:@"%@_response_body.json", filename]];
        } else {
            bodyURL = [self.saveURL URLByAppendingPathComponent:[NSString stringWithFormat:@"%@_response_body.txt", filename]];
        }
        [data writeToURL:bodyURL atomically:NO];
    }
}

- (void)sentFrame:(IPSStompFrame *)frame {
    self.counter += 1;
    NSString *filename = [NSString stringWithFormat:@"%ld_STOMP_%@_send.txt", (long)self.counter, frame.command];
    NSURL *frameURL = [self.saveURL URLByAppendingPathComponent:filename];
    [[frame toString] writeToURL:frameURL atomically:NO encoding:NSUTF8StringEncoding error:nil];
}

- (void)receivedFrame:(IPSStompFrame *)frame error:(NSError *)error {
    self.counter += 1;
    NSString *filename = [NSString stringWithFormat:@"%ld_STOMP_%@_receive.txt", (long)self.counter, frame.command];
    NSURL *frameURL = [self.saveURL URLByAppendingPathComponent:filename];
    [[frame toString] writeToURL:frameURL atomically:NO encoding:NSUTF8StringEncoding error:nil];
}


- (NSString *)fileNameForRequest:(NSURLRequest *)request {
    self.counter += 1;
    NSURLComponents *urlComponents = [NSURLComponents componentsWithURL:request.URL resolvingAgainstBaseURL:NO];
    NSString *filename = [urlComponents.path stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    return [NSString stringWithFormat:@"%ld%@", (long)self.counter, filename];
}

@end
