//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSStartViewController.h"
#import "Styling.h"

@interface IPSStartViewController ()
@property (weak, nonatomic) IBOutlet UIView *startTalkingButtonContainer;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;

@property (weak, nonatomic) IBOutlet UIButton *startTalkingButton;
@property (weak, nonatomic) IBOutlet UIView *loginContainer;

@end

@implementation IPSStartViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self styleStartTalinkgButton];
}

- (IBAction)startTalkingTap:(id)sender {
    [self.delegate startViewControllerStartButtonTapped:self];
}

-(void)viewDidAppear:(BOOL)animated{
    self.startTalkingButton.enabled = true;
    
}


#pragma mark - Start Talking Button

- (void)styleStartTalinkgButton {
    UIBezierPath *buttonMaskPath = [self buttonMaskPath: self.startTalkingButton];
    
    self.startTalkingButton.backgroundColor = [UIColor ips_azureColor];
    self.startTalkingButton.titleLabel.font = [UIFont ips_primaryActionButtonFont];
    
    CALayer *buttonLayer = self.startTalkingButton.layer;
    CAShapeLayer *maskLayer = [CAShapeLayer new];
    maskLayer.frame = self.startTalkingButton.bounds;
    maskLayer.path = buttonMaskPath.CGPath;
    buttonLayer.mask = maskLayer;
    
    self.startTalkingButtonContainer.backgroundColor = [UIColor clearColor];
    
    CALayer *containerLayer = self.startTalkingButtonContainer.layer;
    containerLayer.shadowPath = buttonMaskPath.CGPath;
    containerLayer.shadowColor = [UIColor ips_azure20Color].CGColor;
    containerLayer.shadowOffset = CGSizeMake(0, 4);
    containerLayer.shadowOpacity = 1;
    
}


- (UIBezierPath *)buttonMaskPath : (UIButton *) button {
    CGFloat width = CGRectGetWidth(button.frame);
    CGFloat height = CGRectGetHeight(button.frame);
    CGFloat cornerRadius = 22;
    CGFloat smallCornerRadius = 22;
    
    
    UIBezierPath *buttonMask = [UIBezierPath bezierPath];
    // Start just to the left of the small corner in the bottom right.
    [buttonMask moveToPoint:CGPointMake(width - smallCornerRadius, height)];
    // Move left and add the corner in the bottom left.
    [buttonMask addLineToPoint:CGPointMake(cornerRadius, height)];
    [buttonMask addArcWithCenter:CGPointMake(cornerRadius, height - cornerRadius) radius:cornerRadius startAngle:M_PI_2 endAngle:M_PI clockwise:YES];
    // Move up and add the corner in the top left
    [buttonMask addLineToPoint:CGPointMake(0, cornerRadius)];
    [buttonMask addArcWithCenter:CGPointMake(cornerRadius, cornerRadius) radius:cornerRadius startAngle:M_PI endAngle:3 * M_PI_2 clockwise:YES];
    // Move right and the the corner in the top right.
    [buttonMask addLineToPoint:CGPointMake(width - cornerRadius, 0)];
    [buttonMask addArcWithCenter:CGPointMake(width - cornerRadius, cornerRadius) radius:cornerRadius startAngle:3 * M_PI_2 endAngle:0 clockwise:YES];
    // Move down and the small corner in the bottom right.
    [buttonMask addLineToPoint:CGPointMake(width, height - smallCornerRadius)];
    [buttonMask addArcWithCenter:CGPointMake(width - smallCornerRadius, height - smallCornerRadius) radius:smallCornerRadius startAngle:0 endAngle:M_PI_2 clockwise:YES];
    
    [buttonMask closePath];
    
    return buttonMask;
}


@end
