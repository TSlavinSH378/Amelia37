//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSChatInputToolbar.h"
#import "IPSSendButton.h"
#import "Styling.h"

@interface IPSChatInputToolbar () <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIView *topSepartorView;
@property (weak, nonatomic) IBOutlet UIView *textFieldBackground;
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet IPSSendButton *sendButton;
@end

@implementation IPSChatInputToolbar

- (void)awakeFromNib {
    [super awakeFromNib];
    self.topSepartorView.backgroundColor = [UIColor ips_darkGrey6Color];
    self.textFieldBackground.backgroundColor = [UIColor ips_lightGreyColor];
    self.textFieldBackground.layer.cornerRadius = 16;
    self.textField.backgroundColor = [UIColor ips_lightGreyColor];
    self.sendButton.enabled = NO;
    self.sendButton.inputEnabled = YES;
}

- (void)setInputEnabled:(BOOL)inputEnabled {
    self.sendButton.inputEnabled = inputEnabled;
}

- (void)clearText {
    self.textField.text = @"";
    self.sendButton.enabled = NO;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *newInput = [textField.text stringByReplacingCharactersInRange:range withString:string];
    self.sendButton.enabled = newInput.length > 0;
    return YES;
}

- (IBAction)longPressButtonTap:(id)sender {
    if ([self.delegate respondsToSelector:@selector(chatInputToolBarDidLongPress:)]) {
        [self.delegate chatInputToolBarDidLongPress:self];
    }
}

- (IBAction)sendButtonTap:(id)sender {
    [self.delegate chatInputToolBar:self sendText:self.textField.text];
}
@end
