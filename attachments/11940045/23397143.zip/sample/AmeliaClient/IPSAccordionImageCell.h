//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IPSAccordionImageCell : UITableViewCell
@property (weak, nonatomic, readonly) UIImageView *contentImageView;
@end
