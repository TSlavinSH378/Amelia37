//
//  IPSAKEscalationAlert.h
//  AmeliaKit
//
//  Created by Yulong Yang on 12/18/18.
//  Copyright © 2018 IPsoft. All rights reserved.
//

#import "IPSAKObject.h"
#import "IPSAKMessage.h"
/**
 User status. Only when user is in READY state,
 the user is able to receive escalation request or conversation join request.
 */
typedef NS_ENUM(NSInteger, IPSAKAvailabilityType) {
    AWAY,
    READY,
    BUSY,
    OFFLINE,
};
/**
 Simple alert show to the agent, unlike  IPSAKEscalationRequest it does not expect any action.
 */
@interface IPSAKEscalationAlert : IPSAKObject
@property (nonatomic) IPSAKMessageType messageType;
@property (nonatomic,strong) NSString* escalationRequestId;
@property (nonatomic,strong) NSString* details;
@property (nonatomic) int effectiveTimeout;
@property (nonatomic) BOOL updateAvailability;
@property (nonatomic) IPSAKAvailabilityType availability;
@property (nonatomic) BOOL webApiNotificationEnabled;
@end

