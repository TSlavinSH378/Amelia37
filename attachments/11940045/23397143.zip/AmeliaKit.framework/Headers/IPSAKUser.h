//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAKObject.h"

/**
 The `IPSAKUser` class represents a user.

 @note This encapsulates the response from `httpSession/whomai`.
 */
@interface IPSAKUser : IPSAKObject
/**
 user ID
 **/
@property(nonatomic,copy,readonly) NSString *userId;
/**
 The email.
 */
@property(nonatomic, copy, readonly) NSString *email;
/**
 The name of the user.
 */
@property(nonatomic, copy, readonly) NSString *name;
/**
 Whether this is an anonymous user or not.
 */
@property(nonatomic, readonly) BOOL anonymous;
/**
 Whether this is an agent or not
 */
@property(nonatomic, readonly) BOOL agent;
/**
 The list of available domains for this user, as parsed from
 `httpSession/whomai` response.
 */
@property(nonatomic, strong, readonly) NSArray *domains;
/**
 Default domain
 */
@property(nonatomic, strong,readonly) NSString *defaultConversationDomainId;
@end
