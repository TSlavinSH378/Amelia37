//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@class IPSStompFrame;

/**
 The optional `IPSAKTrafficMonitor` defines methods that can be used to monitor and store the network
 data sent by `IPSHTTPClient` and `IPSStompClient`.
 */
@protocol IPSAKTrafficMonitor<NSObject>

/**
 Tells the traffic monitor to start a new monitor session
 */
- (void)startSession;

/**
 Tells the traffic monitor to end a new session
 */
- (void)endSession;

/**
 Tells the traffic monitor the provided request was sent.
 */
- (void)sentRequest:(NSURLRequest *)request;

/**
 Tells the traffic monitor that the provided response was received.
 */
- (void)receivedResponse:(NSURLResponse *)response
             withRequest:(NSURLRequest *)request
                    data:(NSData *)data
                   error:(NSError *)error;

/**
 Tells the traffic monitor that the provided frame was sent.
 */
- (void)sentFrame:(IPSStompFrame *)frame;

/**
 Tells the traffic monitor the provided frame was received.
 */
- (void)receivedFrame:(IPSStompFrame *)frame error:(NSError *)error;

@end
