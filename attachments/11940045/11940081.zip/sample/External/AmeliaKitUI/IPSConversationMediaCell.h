//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationBubbleCell.h"
@protocol IPSConversationUserActionDelegate;

@interface IPSConversationMediaCell : IPSConversationBubbleCell
@property (nonatomic,weak) id<IPSConversationUserActionDelegate> userActionDelegate;
@end
