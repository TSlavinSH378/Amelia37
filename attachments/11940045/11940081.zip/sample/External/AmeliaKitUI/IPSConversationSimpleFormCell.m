//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationSimpleFormCell.h"
#import "IPSCollectionViewLayoutAttributes.h"
#import "IPSConversationForm.h"
#import "Styling.h"

@interface IPSConversationSimpleFormCell ()

@property (weak, nonatomic) IBOutlet UILabel *textLabel;
@property (weak, nonatomic) IBOutlet UIStackView *buttonContainer;
@property (strong) NSMutableArray<IPSConversationFormAction *> *actions;
@end

@implementation IPSConversationSimpleFormCell

+ (void)registerInCollectionView:(UICollectionView *)collectionView {
    [collectionView registerNib:[UINib nibWithNibName:@"IPSConversationSimpleFormCell" bundle:nil] forCellWithReuseIdentifier:@"simpleFormCell"];
}

+ (instancetype)dequeueCellInCollectionView:(UICollectionView *)collectionView forIndexPath:(NSIndexPath *)indexPath {
    return [collectionView dequeueReusableCellWithReuseIdentifier:@"simpleFormCell" forIndexPath:indexPath];
}

+ (instancetype)sizingCell {
    return [[UINib nibWithNibName:@"IPSConversationSimpleFormCell" bundle:nil] instantiateWithOwner:nil options:nil].firstObject;
}


- (CGSize)preferredLayoutSizeFittingSize:(CGSize)size {
    
    CGRect originalFrame = self.frame;
    CGFloat originalPreferredMaxLayoutWidth = self.textLabel.preferredMaxLayoutWidth;
    
    self.textLabel.preferredMaxLayoutWidth = size.width;
    
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
    
    [self setNeedsLayout];
    [self layoutIfNeeded];
    self.textLabel.preferredMaxLayoutWidth = self.textLabel.bounds.size.width;
    
    CGSize computedSize = [self systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
    computedSize.width = size.width;
    
    self.frame = originalFrame;
    self.textLabel.preferredMaxLayoutWidth = originalPreferredMaxLayoutWidth;
    
    return computedSize;
}

- (void)configure:(IPSConversationForm *)message {
    self.textLabel.text = message.text;
    
    NSArray *buttons = self.buttonContainer.arrangedSubviews;
    [buttons enumerateObjectsUsingBlock:^(UIView *button, NSUInteger idx, BOOL * _Nonnull stop) {
        [self.buttonContainer removeArrangedSubview:button];
        [button removeFromSuperview];
    }];
    
    for (IPSConversationFormAction *action in message.actions) {
        [self addAction:action];
    }
}

- (void)addAction:(IPSConversationFormAction *)action {
    if (self.actions == nil) {
        self.actions = [NSMutableArray array];
    }
    
    [self.actions addObject:action];
    
    UIButton *actionButton = [[UIButton alloc] init];
    
    [actionButton setTitle:action.title forState:UIControlStateNormal];
    
    switch (action.style) {
        case IPSConversationFormActionStyleDefault:
            [actionButton setTitleColor:[UIColor ips_azureColor] forState:UIControlStateNormal];
            actionButton.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
            break;
        case IPSConversationFormActionStyleCancel:
            [actionButton setTitleColor:[UIColor ips_coolGreyColor] forState:UIControlStateNormal];
            actionButton.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
            break;
        case IPSConversationFormActionStyleSubmit:
            [actionButton setTitleColor:[UIColor ips_azureColor] forState:UIControlStateNormal];
            actionButton.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightBold];
            break;
    }
    
    [actionButton setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
    
    [actionButton addTarget:action action:@selector(actionTap:) forControlEvents:UIControlEventTouchUpInside];
    [self.buttonContainer addArrangedSubview:actionButton];
    [actionButton.heightAnchor constraintGreaterThanOrEqualToConstant:48].active = YES;
    
    action.button = actionButton;
}

- (BOOL)shadowOutline {
    return YES;
}

@end
