//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@class IPSAKChat;
@class IPSAKDomain;
@class IPSAKUser;


@protocol IPSSessionViewControllerDelegate;

@interface IPSSessionViewController : UIViewController

+ (instancetype)sessionViewController;

@property (weak, nonatomic) id<IPSSessionViewControllerDelegate> delegate;
@property (strong, nonatomic) IPSAKUser *user;

- (void)sessionFailWithError:(NSError *)error;
- (void)domainSelectionRequired:(NSArray<IPSAKDomain *> *)domains;
- (void)domainFailWithError:(NSError *)error;
- (void)conversationStartWithChat:(IPSAKChat *)chat;
- (void)conversationFailWithError:(NSError *)error;

@end

@protocol IPSSessionViewControllerDelegate <NSObject>
- (void)sessionViewController:(IPSSessionViewController *)controller didSelectDomain:(IPSAKDomain *)domain;
- (void)sessionViewControllerDidTapLogoutButton:(IPSSessionViewController *)controller;
- (void)sessionViewControllerDidTapStepUpButton:(IPSSessionViewController *)controller;
@end
