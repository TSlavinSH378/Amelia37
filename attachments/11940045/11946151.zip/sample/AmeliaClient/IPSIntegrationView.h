//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol IPSIntegrationViewDelegate;


@interface IPSIntegrationView : UIVisualEffectView

@property (weak, nonatomic) id<IPSIntegrationViewDelegate> delegate;
@property (strong, nonatomic, readonly) NSDictionary *integration;

- (void)configure:(NSDictionary *)integration;

@end

@protocol IPSIntegrationViewDelegate <NSObject>
- (void)integrationViewTap:(IPSIntegrationView *)integrationView;
@end
