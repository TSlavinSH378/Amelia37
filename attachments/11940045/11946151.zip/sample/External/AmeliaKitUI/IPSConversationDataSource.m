//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationDataSource.h"
#import "IPSConversationMessageData.h"
#import "IPSConversationMessage.h"

@interface IPSConversationDataSource()
@property (strong) NSMutableArray *sections;
@property NSInteger messageCount;
@property (strong) NSObject *suppressLock;
@property BOOL suppressUpdates;
@end

@implementation IPSConversationDataSource

- (instancetype)init {
    self = [super init];
    if (self) {
        _sections = [NSMutableArray array];
        _suppressLock = [[NSObject alloc] init];
    }
    return self;
}

- (void)suppressUpdates:(void(^)(IPSConversationDataSource *dataSource))block {
    @synchronized (self.suppressLock) {
        self.suppressUpdates = YES;
        block(self);
        self.suppressUpdates = NO;
    }
}

- (void)addMessage:(id<IPSConversationMessageData>)message {
    self.messageCount += 1;
    
    NSIndexSet *insertedSections;
    NSIndexPath *deletedIndexPath;
    
    NSMutableArray *messages = self.sections.lastObject;
    if (messages == nil) {
        messages = [NSMutableArray array];
        [self.sections addObject:messages];
        insertedSections = [NSIndexSet indexSetWithIndex:0];
    }
    
    id<IPSConversationMessageData> lastMessage = messages.lastObject;
    if ((lastMessage && message.origin != lastMessage.origin)) {
        messages = [NSMutableArray array];
        [self.sections addObject:messages];
        insertedSections = [NSIndexSet indexSetWithIndex:self.sections.count - 1];
    }
    
    BOOL didReplace = NO;
    if (message.messageType == IPSConversationMessageTypeInformation) {
        if (messages.lastObject != nil && [messages.lastObject messageType] == IPSConversationMessageTypeSpinner) {
            deletedIndexPath = [NSIndexPath indexPathForItem:messages.count - 1 inSection:self.sections.count - 1];
            [messages removeLastObject];
        }
        
        messages = [NSMutableArray array];
        [self.sections addObject:messages];
        insertedSections = [NSIndexSet indexSetWithIndex:self.sections.count - 1];
        [messages addObject:message];
    } else {
        if (messages.lastObject != nil && [messages.lastObject messageType] == IPSConversationMessageTypeSpinner) {
            didReplace = YES;
            [messages replaceObjectAtIndex:messages.count-1 withObject:message];
        } else {
            [messages addObject:message];
        }
    }
    
    if (!self.suppressUpdates) {
        if (deletedIndexPath != nil) {
            [self.delegate conversationDataSource:self didDeleteItemsAtIndexPath:@[deletedIndexPath]];
        }
        if (insertedSections != nil) {
            [self.delegate conversationDataSource:self didInsertSections:insertedSections];
        } else {
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:messages.count - 1 inSection:self.sections.count - 1];
            if (didReplace) {
                [self.delegate conversationDataSource:self didReloadItemsAtIndexPath:@[indexPath]];
            } else {
                [self.delegate conversationDataSource:self didInsertItemsAtIndexPath:@[indexPath]];
            }
        }
    }
}

- (void)addSpinner {
    IPSConversationMessage *spinner = [[IPSConversationMessage alloc] init];
    spinner.messageType = IPSConversationMessageTypeSpinner;
    spinner.origin = IPSConversationMessageOriginRemote;
    [self addMessage:spinner];
}

- (void)removeSpinner {
    id<IPSConversationMessageData> lastMessage = [self lastMessage];
    if (lastMessage.messageType == IPSConversationMessageTypeSpinner) {
        [self removeMessage:lastMessage];
    }
}

- (void)removeAllMessages {
    [self.sections removeAllObjects];
    if (!self.suppressUpdates) {
        [self.delegate conversationDataSourceDidReload:self];
    }
}

- (void)removeMessage:(id<IPSConversationMessageData>)message {
    NSIndexPath *deleteIndexPath = [self indexPathForMessage:message];
    if (deleteIndexPath == nil) {
        return;
    }
    
    NSMutableArray *messages = self.sections[deleteIndexPath.section];
    [messages removeObjectAtIndex:deleteIndexPath.item];
    
    NSIndexSet *deletedSections;
    if (messages.count == 0) {
        deletedSections = [NSIndexSet indexSetWithIndex:deleteIndexPath.section];
        [self.sections removeObjectAtIndex:deleteIndexPath.section];
    }
    
    if (!self.suppressUpdates) {
        if (deletedSections != nil) {
            [self.delegate conversationDataSource:self didDeleteSections:deletedSections];
        } else {
            [self.delegate conversationDataSource:self didDeleteItemsAtIndexPath:@[deleteIndexPath]];
        }
    }
}

- (NSIndexPath *)indexPathForMessage:(id<IPSConversationMessageData>)message {
    for (int section = 0; section < self.sections.count; ++section) {
        NSArray *messages = self.sections[section];
        for (int item = 0; item < messages.count; ++item) {
            if (message == messages[item]) {
                return [NSIndexPath indexPathForItem:item inSection:section];
            }
        }
    }
    return nil;
}

- (NSInteger)numberOfSections {
    return self.sections.count;
}

- (NSInteger)numberOfItemsInSection:(NSInteger)section {
    NSArray *messages = self.sections[section];
    return messages.count;
}

- (id<IPSConversationMessageData>)messageAtIndexPath:(NSIndexPath *)indexPath {
    NSArray *messages = self.sections[indexPath.section];
    return messages[indexPath.item];
}

- (id<IPSConversationMessageData>)lastMessage {
    NSArray *messages = self.sections.lastObject;
    return messages.lastObject;
}

@end
