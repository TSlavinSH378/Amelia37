//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IPSConversationMessageData.h"

typedef NS_ENUM(NSInteger, IPSRowType) {
    IPSRowTypeSingle,
    IPSRowTypeTop,
    IPSRowTypeMiddle,
    IPSRowTypeBottom,
};

@interface IPSCollectionViewLayoutAttributes : UICollectionViewLayoutAttributes

@property IPSConversationMessageOrigin origin;
@property IPSRowType rowType;
/// The maximum width a single bubble is allowed to be.
@property CGFloat maxBubbleWidth;
@end
