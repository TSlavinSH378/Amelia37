//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IPSConversationMessageData.h"

@interface IPSDomainForm : NSObject <IPSConversationMessageData>
@property (nonatomic, copy) NSString *text;
@property (strong) id content;
@end
