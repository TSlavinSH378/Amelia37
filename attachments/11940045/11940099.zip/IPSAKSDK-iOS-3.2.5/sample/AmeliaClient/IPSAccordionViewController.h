//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IPSAccordionField : NSObject

- (instancetype)initWithText:(NSString *)text detailText:(NSString *)detailText;

- (instancetype)initWithContentImage:(UIImage *)image;

@property (copy, nonatomic, readonly) NSString *text;
@property (copy, nonatomic, readonly) NSString *detailText;
@property (strong, nonatomic, readonly) UIImage *contentImage;
@end

@interface IPSAccordionSection : NSObject

@property (copy, nonatomic) NSString *title;
@property (copy, nonatomic) NSDictionary *actionProcess;
@property (copy, nonatomic) NSString *staticUtterance;

@property (strong, nonatomic) NSMutableArray<IPSAccordionField *> *fields;

- (void)addField:(IPSAccordionField *)field;
@end


@protocol IPSAccordionViewControllerDelegate;

@interface IPSAccordionViewController : UITableViewController

+ (instancetype)accordionViewControllerWithIntegrationMessage:(NSDictionary *)integration;

@property (weak, nonatomic) id<IPSAccordionViewControllerDelegate> delegate;

@end

@protocol IPSAccordionViewControllerDelegate <NSObject>
- (void)accordionViewController:(IPSAccordionViewController *)controller runAction:(NSString *)action arguments:(NSDictionary *)arguments message:(NSString *)message;
@end
