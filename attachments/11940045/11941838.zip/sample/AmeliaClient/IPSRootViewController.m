//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSRootViewController.h"
#import "IPSLoginViewController.h"
#import "IPSSessionViewController.h"
#import "IPSSettingsViewController.h"
#import "IPSStartViewController.h"
#import "IPSTrafficMonitor.h"
#import "NSUserDefaults+Amelia.h"
#import "Styling.h"
#import "IPSAKConfiguration+Security.h"
#import <AmeliaKit/AmeliaKit.h>


typedef NS_ENUM(NSInteger, IPSRootState) {
    IPSRootStateStart,
    IPSRootStateAnonymous,
    IPSRootStateLoginRequired,
    IPSRootStateSession
};

@interface IPSRootViewController () <IPSLoginViewControllerDelegate,
                                     IPSStartViewControllerDelegate,
                                     IPSSessionViewControllerDelegate,
                                     IPSAKChatSessionDelegate>
@property (nonatomic, strong) IPSStartViewController *startViewController;
@property (nonatomic, strong) IPSLoginViewController *loginViewController;
@property (nonatomic, strong) IPSSessionViewController *sessionViewController;
@property (nonatomic, strong) IPSAKConfiguration *configuration;
@property (nonatomic, strong) IPSAKChat *chat;
@property (nonatomic,strong) IPSAKLoginOptions *loginOptions;
@property IPSRootState rootState;
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (nonatomic, strong) IPSTrafficMonitor *trafficMonitor;
@property (assign,nonatomic) BOOL chatInitialized;
@end

@implementation IPSRootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"88GraphicsTempAmeliaLogo"]];
    [self.navigationController.navigationBar ips_makeTransparent];
    
    [[NSNotificationCenter defaultCenter] addObserverForName:IPSChatSettingsUpdateNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
            self.chat.conversationDelegate = nil;
            self.chat.sessionDelegate = nil;
            self.chat = nil;
    }];

    NSLog(@"sdk version %@, %@", IPSAK_VERSION_STRING, IPSAK_TARGET_PLATFORM_VERSION);
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self updateContentView];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"iconSettings"] style:UIBarButtonItemStyleDone target:self action:@selector(settingsTap:)];
}

- (void)updateContentView {
    [self.chat initialize];
}

- (void)startViewControllerLoginButtonTapped:(IPSStartViewController *)controller{
    [self showLoginScreen:NO];
}

- (IBAction)settingsTap:(id)sender {
    IPSSettingsViewController *settingsViewController = [IPSSettingsViewController settingsViewController];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:settingsViewController];
    [self presentViewController:navigationController animated:YES completion:nil];
}

- (void)startViewControllerStartButtonTapped:(IPSStartViewController *)controller {
    [self.chat startNewConversation];
}

- (void)loginViewController:(IPSLoginViewController *)controller loginWithUsername:(NSString *)username password:(NSString *)password {
    _loginOptions = [[IPSAKLoginOptions alloc] initWithUsername:username password:password];
    [self.chat login:[[IPSAKLoginOptions alloc] initWithUsername:username password:password]];
}

#pragma mark - <IPSSessionViewControllerDelegate>

- (void)sessionViewController:(IPSSessionViewController *)controller didSelectDomain:(IPSAKDomain *)domain {
    [self.chat selectDomain:domain];
}

- (void)sessionViewControllerDidTapLogoutButton:(IPSSessionViewController *)controller {
    [self.chat logout];
    self.navigationItem.leftBarButtonItem = nil;
    [self dismissViewControllerAnimated:YES completion:^{
        self.sessionViewController = nil;
    }];
}


- (void)backToMain: (IPSLoginViewController *) controller{
    [self.loginViewController willMoveToParentViewController:nil];
    [self.loginViewController.view removeFromSuperview];
    [self.loginViewController removeFromParentViewController];
    
    self.navigationItem.rightBarButtonItem = nil;
    self.navigationItem.leftBarButtonItem = nil;
    
    [self showStartScreen];
}

- (void)sessionViewControllerDidTapStepUpButton:(IPSSessionViewController *)controller {
    [NSUserDefaults standardUserDefaults].ips_anonymousAllowed = NO;
    [self.chat stepUp];
}

#pragma mark -

- (IPSAKChat *)chat {
    if (_chat == nil) {
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSURL *serverURL = [NSURL URLWithString:userDefaults.ips_host];
        IPSAKConfiguration *configuration = [IPSAKConfiguration configurationWithURL:serverURL];
        configuration.domainSelectionMode = IPSAKDomainSelectionModeAutomatic;
        configuration.speechParams.enabled = YES;
        configuration.allowAllHosts = YES;

        _chat = [IPSAKChat chatWithConfiguration:configuration];
        _chat.sessionDelegate = self;
        _chat.trafficMonitor = self.trafficMonitor = [[IPSTrafficMonitor alloc] init];
    }
    return _chat;
}

# pragma mark - <IPSAKChatSessionDelegate>
-(void)chatInitialized:(IPSAKChat*)chat withAppConfig:(IPSAKAppConfig *)appConfig{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    userDefaults.ips_anonymousAllowed = appConfig.allowAnonymous;
    _chatInitialized = true;
    if(appConfig.allowAnonymous){
        [self showStartScreen];
    }else{
        [self showLoginScreen:NO];
    }
}

- (void)chatSessionStart:(IPSAKChat *)chat {
    NSAssert(self.rootState == IPSRootStateAnonymous, @"`sessionStart` can only be recevied when logging in anonymously.");
    [self showSessionScreen];
}

- (void)chat:(IPSAKChat *)chat sessionFailWithError:(NSError *)error {
    NSLog(@"%s: %@", __PRETTY_FUNCTION__, error);
    if (self.rootState == IPSRootStateAnonymous) {
       [self presentError:error];
    } else {
        if(!_chatInitialized){
            [self showLoginScreen:NO];
        }
        [self.sessionViewController sessionFailWithError:error];
    }
}

- (void)chat:(IPSAKChat *)chat loginRequiredWithAuthSystems:(NSArray<IPSAKAuthSystem *> *)authSystems {
//    NSAssert(self.rootState == IPSRootStateSession, @"We should only ever receive `loginRequired` when trying to login anonymously but the server doesn't allow it.");
    [self showLoginScreen:YES];
    [self dismissViewControllerAnimated:YES completion:^{
        self.sessionViewController = nil;
    }];

}

- (void)presentError:(NSError *)error {
    NSString *message = [NSString stringWithFormat:@"%@", error.localizedDescription];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Error" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)chatLoginSuccess:(IPSAKChat *)chat {
    NSAssert(self.rootState == IPSRootStateLoginRequired, @"Should only receive `loginSuccess` when in state loginRequired.");
    [self showSessionScreen];
}

- (void)chat:(IPSAKChat *)chat loginFailWithError:(NSError *)error {
    NSLog(@"%s: %@", __PRETTY_FUNCTION__, error);
    NSAssert(self.rootState == IPSRootStateLoginRequired, @"Should only receive `loginFail` when in state loginRequired.");
    [self.loginViewController loginFailWithError:error];
}

- (void)chat:(IPSAKChat *)chat didInitUser:(nonnull IPSAKUser *)user {
    NSAssert(self.rootState == IPSRootStateSession, @"Should only receive `didInitUser` when in state session.");
    self.sessionViewController.user = user;
}

- (void)chat:(IPSAKChat *)chat domainSelectionRequired:(NSArray<IPSAKDomain *> *)domains {
    NSAssert(self.rootState == IPSRootStateSession, @"Should only receive `domainSelectionRequired` when in state session.");
    [self.sessionViewController domainSelectionRequired:domains];
}

- (void)chat:(IPSAKChat *)chat domainFailWithError:(NSError *)error {
    NSLog(@"%s: %@", __PRETTY_FUNCTION__, error);
    NSAssert(self.rootState == IPSRootStateSession, @"Should only receive `domainFailWithError` when in state session.");
    [self.sessionViewController domainFailWithError:error];
}

- (void)chat:(IPSAKChat *)chat languageChangeFrom:(NSString *)prevLanguageCode to:(NSString *)languageCode {
    NSLog(@"Language is now %@", languageCode);
}
- (void)chatConversationStart:(IPSAKChat *)chat {
    NSAssert(self.rootState == IPSRootStateSession, @"Should only receive `conversationStart` when in state session.");
    [self.sessionViewController conversationStartWithChat:chat];
}

- (void)chat:(IPSAKChat *)chat conversationFailWithError:(NSError *)error {
    NSLog(@"%s: %@", __PRETTY_FUNCTION__, error);
    NSAssert(self.rootState == IPSRootStateSession, @"Should only receive `conversationStart` when in state session.");
    [self.sessionViewController conversationFailWithError:error];
}

#pragma mark -

- (void)showStartScreen {
    self.rootState = IPSRootStateAnonymous;
    UIViewController *childViewController = self.childViewControllers.firstObject;
    if (childViewController != self.startViewController) {
        [self addViewController:self.startViewController];
        self.navigationItem.rightBarButtonItem = nil;
    }
}

- (void)showLoginScreen:(BOOL)animate {
    self.rootState = IPSRootStateLoginRequired;
    UIViewController *childViewController = self.childViewControllers.firstObject;
    if (childViewController != self.loginViewController) {
        [self addViewController:self.loginViewController];
        self.navigationItem.rightBarButtonItem = self.loginViewController.loginButton;
        //self.navigationItem.leftBarButtonItem = self.loginViewController.backButton;
        [self.contentView addSubview: [self.loginViewController view]];
        [self.loginViewController didMoveToParentViewController:self];
    }
}

- (void)showSessionScreen {
    self.rootState = IPSRootStateSession;
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:self.sessionViewController];
    [self presentViewController:navigationController animated:YES completion:nil];
}

#pragma mark -

- (void)addViewController:(UIViewController *)viewController {
    UIViewController *currentViewController = self.childViewControllers.firstObject;
    [currentViewController willMoveToParentViewController:nil];
    [self addChildViewController:viewController];
    [currentViewController.view removeFromSuperview];
    [self.view addSubview:viewController.view];
    [viewController didMoveToParentViewController:self];
    [currentViewController removeFromParentViewController];
}

- (IPSStartViewController *)startViewController {
    if (_startViewController == nil) {
        _startViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"startViewController"];
        _startViewController.delegate = self;
    }
    return _startViewController;
}

- (IPSLoginViewController *)loginViewController {
    if (_loginViewController == nil) {
        _loginViewController = [IPSLoginViewController loginViewController];
        _loginViewController.delegate = self;
    }
    return _loginViewController;
}

- (IPSSessionViewController *)sessionViewController {
    if (_sessionViewController == nil) {
        _sessionViewController = [IPSSessionViewController sessionViewController];
        _sessionViewController.delegate = self;
    }
    return _sessionViewController;
}

@end
