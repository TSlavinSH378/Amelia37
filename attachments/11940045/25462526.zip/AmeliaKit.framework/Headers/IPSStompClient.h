//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IPSAKTrafficMonitor.h"

#define SRWebSocket IPS_SRWebSocket

@class SRWebSocket;
@class IPSOfflineSession;

extern NSString *const IPSStompErrorDomain;
extern NSString *const IPSStompCommandConnect;
extern NSString *const IPSStompCommandConnected;
extern NSString *const IPSStompCommandDisconnect;
extern NSString *const IPSStompCommandSubscribe;
extern NSString *const IPSStompCommandUnsubscribe;
extern NSString *const IPStompCommandSend;

typedef NS_ENUM(NSInteger, IPSStompErrorCode) {
    IPSStompErrorInvalidFrame,
    IPSStompErrorNoConnection,
};
/**
 Stomp frame message format exchanged in the stompclient
 */
@interface IPSStompFrame : NSObject<NSCopying>

+ (instancetype)stompFrameFromString:(NSString *)string;

- (instancetype)initWithCommand:(NSString *)command headers:(NSDictionary *)headers body:(NSString *)body;

- (NSString *)toString;

@property (nonatomic, copy, readonly) NSString *command;
@property (nonatomic, copy, readonly) NSDictionary<NSString *, NSString *> *headers;
@property (nonatomic, copy, readonly) NSString *body;

@end

@protocol IPSStompClientDelegate;
/**
 Stompclient used for receiving the websocket messages
 */
@interface IPSStompClient : NSObject

- (instancetype)initWithURL:(NSURL *)URL andRequestTimeout:(double)seconds;

@property (weak) id<IPSStompClientDelegate> delegate;

@property (copy) NSArray<NSHTTPCookie *> *httpCookies;
@property (copy) NSDictionary *httpHeaders;
@property (nonatomic) BOOL ignoreCertificateErrors;
/**
 Whether to send the STOMP frame as data. If `NO` STOMP frames are sent as text.
 Defaults to `NO`.
 */
@property BOOL sendAsData;

- (void)connect;

- (void)disconnect;

- (void)subscribeTo:(NSString *)destination headers:(NSDictionary *)headers;

- (void)unsubscribeWithHeaders:(NSDictionary *)headers;

- (void)sendTo:(NSString *)destination headers:(NSDictionary *)headers jsonBody:(id)jsonBody;

#pragma mark - Debug

@property (nonatomic, weak) id<IPSAKTrafficMonitor> trafficMonitor;
@property (nonatomic, copy) SRWebSocket * (^createWebSocket)(NSURL *);

@end

@protocol IPSStompClientDelegate<NSObject>
@optional
- (void)stompClientDidConnect:(IPSStompClient *)client;
- (void)stompClient:(IPSStompClient *)client didReceiveFrame:(IPSStompFrame *)frame;
-(void)stompClient:(IPSStompClient *)client didGetReceipt:(NSString*)receiptId;
- (void)stompClient:(IPSStompClient *)client didFailWithError:(NSError *)error;
- (void)stompClient:(IPSStompClient *)client stompFrameError:(NSError *)error;
- (void)stompClient:(IPSStompClient *)client didCloseWithError:(NSError *)error;
@end
