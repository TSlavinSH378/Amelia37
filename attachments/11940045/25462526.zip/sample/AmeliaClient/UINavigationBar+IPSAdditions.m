//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "UINavigationBar+IPSAdditions.h"

@implementation UINavigationBar (IPSAdditions)

- (void)ips_makeTransparent {
    [self setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [self setShadowImage:[UIImage new]];
}

@end
