//
//  IPSAKAppConfig.h
//  AmeliaKit
//
//  Created by Yulong Yang on 1/29/18.
//  Copyright © 2018 IPsoft. All rights reserved.
//

#import <AmeliaKit/AmeliaKit.h>
/**
   This is configuration returned after the sdk is successfully intialized
 */
@interface IPSAKAppConfig : IPSAKObject
/**
 Indicating if user is currently logged in or not
 */
@property (nonatomic, readonly) BOOL loggedIn;
/**
 Whether anonymous user is allowed on this server
 */
@property (nonatomic,readonly) BOOL allowAnonymous;
/**
 Csrf session token
 */
@property (copy, nonatomic,readonly) NSString *csrfToken;
/**
 The current logged in user / anonymous user.
 */
@property (copy, nonatomic,readonly) IPSAKUser *user;
/**
 All domains, indcluding ones that are not accessible by the user.
 */
@property (copy,nonatomic,readonly) NSArray<IPSAKDomain*>* allDomains;
@end
