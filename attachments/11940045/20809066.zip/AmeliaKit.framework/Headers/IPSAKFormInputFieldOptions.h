//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSAKObject.h"

/**
 The `IPSAKFormInputFieldOptions` class represent an input field option.
 */
@interface IPSAKFormInputFieldOptions : IPSAKObject

/**
 The displayable name.
 */
@property(copy, nonatomic, readonly) NSString *name;
/**
 The value of the submission when selected.
 */
@property(copy, nonatomic, readonly) NSString *value;
/**
 If the option contains an image
 */
@property(copy,nonatomic, readonly) NSString* imageBase64;
/**
 If the option is of Large Size and has a description
 */
@property(copy,nonatomic, readonly) NSString* imageAlternativeText;
/**
 If the option is of X Large Size and has a CTA button
 */
@property(copy,nonatomic,readonly) NSString* valueForDisplay;
/**
 name for display in suggested response
 */
@property (copy, nonatomic,readonly) NSString *nameForDisplay;

/**
 If it should be selected by default.
 */
@property(nonatomic) BOOL selected;
/**
 If it should be hidden by default.
 */
@property(nonatomic, readonly) BOOL hidden;
/**
 If it should be disabled by default.
 */
@property(nonatomic, readonly) BOOL disabled;

@end
