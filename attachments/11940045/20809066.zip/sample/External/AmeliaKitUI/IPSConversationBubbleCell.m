//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationBubbleCell.h"
#import "IPSConversationMessageData.h"
#import "IPSCollectionViewLayoutAttributes.h"

@interface IPSConversationBubbleCell ()
@property IPSConversationMessageOrigin origin;
@property IPSRowType rowType;
@end

@implementation IPSConversationBubbleCell

+ (void)registerInCollectionView:(UICollectionView *)collectionView {
    
}

+ (instancetype)dequeueCellInCollectionView:(UICollectionView *)collectionView forIndexPath:(NSIndexPath *)indexPath {
    return nil;
}

+ (instancetype)sizingCell {
    return nil;
}


- (CGSize)preferredLayoutSizeFittingSize:(CGSize)size {
    return size;
}

- (void)applyLayoutAttributes:(IPSCollectionViewLayoutAttributes *)layoutAttributes {
    [super applyLayoutAttributes:layoutAttributes];
    self.rowType = layoutAttributes.rowType;
    self.origin = layoutAttributes.origin;
    [self setNeedsLayout];
}

- (UICollectionViewLayoutAttributes *)preferredLayoutAttributesFittingAttributes:(IPSCollectionViewLayoutAttributes *)layoutAttributes {
    self.rowType = layoutAttributes.rowType;
    self.origin = layoutAttributes.origin;
    [self setNeedsLayout];
    return [super preferredLayoutAttributesFittingAttributes:layoutAttributes];
}

- (void)configure:(id<IPSConversationMessageData>)message {
}

- (void)layoutSubviews {
    [super layoutSubviews];

    BOOL isLeft = self.origin == IPSConversationMessageOriginRemote;
    UIRectCorner rectCorner;
    switch (self.rowType) {
        case IPSRowTypeSingle:
            rectCorner = 0;
            break;
        case IPSRowTypeTop:
            rectCorner = isLeft ? UIRectCornerBottomLeft : UIRectCornerBottomRight;
            break;
        case IPSRowTypeBottom:
            rectCorner = isLeft ? UIRectCornerTopLeft : UIRectCornerTopRight;
            break;
        case IPSRowTypeMiddle:
            rectCorner = isLeft ? UIRectCornerTopLeft | UIRectCornerBottomLeft : UIRectCornerTopRight | UIRectCornerBottomRight;
    }
    [self applyMaskWithSmallCorner:rectCorner];
}


- (void)applyMaskWithSmallCorner:(UIRectCorner)smallCorner {
    self.contentView.layer.actions = @{@"contents": [NSNull null] };
    UIBezierPath *buttonMaskPath = [self buttonMaskPath:smallCorner];
    CAShapeLayer *maskLayer = [CAShapeLayer new];
    maskLayer.frame = self.bounds;
    maskLayer.path = buttonMaskPath.CGPath;
    self.contentView.layer.mask = maskLayer;
    
    if (self.shadowOutline) {
        self.layer.shadowPath = buttonMaskPath.CGPath;
        self.layer.shadowOpacity = 1;
        self.layer.shadowColor = [UIColor colorWithRed:24.0f / 255.0f green:25.0f / 255.0f blue:26.0f / 255.0f alpha:0.06f].CGColor;
        self.layer.shadowRadius = 3;
        self.layer.shadowOffset = CGSizeMake(0, 1.5);
        
        self.clipsToBounds = NO;
    }
}

- (UIBezierPath *)buttonMaskPath:(UIRectCorner)smallCorner {
    
    CGFloat width = CGRectGetWidth(self.frame);
    CGFloat height = CGRectGetHeight(self.frame);
    CGFloat cornerRadius = MIN(16, CGRectGetHeight(self.frame)/2);
    CGFloat smallCornerRadius = 5;
    CGFloat bottomRightCornerRadius = (smallCorner & UIRectCornerBottomRight) == UIRectCornerBottomRight ? smallCornerRadius : cornerRadius;
    CGFloat bottomLeftCornerRadius = (smallCorner & UIRectCornerBottomLeft) == UIRectCornerBottomLeft ? smallCornerRadius : cornerRadius;
    CGFloat topLeftCornerRadius = (smallCorner & UIRectCornerTopLeft) == UIRectCornerTopLeft ? smallCornerRadius : cornerRadius;
    CGFloat topRightCornerRadius = (smallCorner & UIRectCornerTopRight) == UIRectCornerTopRight ? smallCornerRadius : cornerRadius;
    
    UIBezierPath *buttonMask = [UIBezierPath bezierPath];
    // Start just to the left of the corner in the bottom right.
    [buttonMask moveToPoint:CGPointMake(width - bottomRightCornerRadius, height)];
    // Move left and add the corner in the bottom left.
    [buttonMask addLineToPoint:CGPointMake(bottomLeftCornerRadius, height)];
    [buttonMask addArcWithCenter:CGPointMake(bottomLeftCornerRadius, height - bottomLeftCornerRadius) radius:bottomLeftCornerRadius startAngle:M_PI_2 endAngle:M_PI clockwise:YES];
    // Move up and add the corner in the top left
    [buttonMask addLineToPoint:CGPointMake(0, topLeftCornerRadius)];
    [buttonMask addArcWithCenter:CGPointMake(topLeftCornerRadius, topLeftCornerRadius) radius:topLeftCornerRadius startAngle:M_PI endAngle:3 * M_PI_2 clockwise:YES];
    // Move right and the the corner in the top right.
    [buttonMask addLineToPoint:CGPointMake(width - topRightCornerRadius, 0)];
    [buttonMask addArcWithCenter:CGPointMake(width - topRightCornerRadius, topRightCornerRadius) radius:topRightCornerRadius startAngle:3 * M_PI_2 endAngle:0 clockwise:YES];
    // Move down and the corner in the bottom right.
    [buttonMask addLineToPoint:CGPointMake(width, height - bottomRightCornerRadius)];
    [buttonMask addArcWithCenter:CGPointMake(width - bottomRightCornerRadius, height - bottomRightCornerRadius) radius:bottomRightCornerRadius startAngle:0 endAngle:M_PI_2 clockwise:YES];
    
    [buttonMask closePath];
    
    return buttonMask;
}


@end
