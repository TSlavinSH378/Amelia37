//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IPSConversationViewController.h"

@class IPSAKDomain;

@protocol IPSDomainListViewContollerDelegate;

@interface IPSDomainListViewController : IPSConversationViewController

+ (instancetype)domainListViewController;

@property (nonatomic, weak) id<IPSDomainListViewContollerDelegate> delegate;

- (void)showDomains:(NSArray<IPSAKDomain *> *)domains;

- (void)clearDomains;

- (void)reload;

@end

@protocol IPSDomainListViewContollerDelegate <NSObject>
- (void)domainListViewController:(IPSDomainListViewController *)controller didSelectDomain:(IPSAKDomain *)domain;
@end
