//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Where the message originated. Local messages are shown on the right side, and remote messages are shown on the left.
 */
typedef NS_ENUM(NSInteger, IPSConversationMessageOrigin) {
    IPSConversationMessageOriginRemote,
    IPSConversationMessageOriginLocal,
};

/**
 The message type controls the type of cell.
 */
typedef NS_ENUM(NSInteger, IPSConversationMessageType) {
    IPSConversationMessageTypeText,
    IPSConversationMessageTypeImage,
    IPSConversationMessageTypePdf,
    IPSConversationMessageTypeLink,
    IPSConversationMessageTypeHtmlContent,
    IPSConversationMessageTypeForm,
    IPSConversationMessageTypeSpinner,
    IPSConversationMessageTypeInformation,
    IPSConversationMessageTypeCustom,
};

@protocol IPSConversationMessageData <NSObject>

@property (readonly) IPSConversationMessageOrigin origin;

@property (readonly) IPSConversationMessageType messageType;

@property (copy, readonly, nullable) NSString *text;

@property (copy, readonly,nullable) NSAttributedString *attributedText;

@property (strong, readonly, nullable) id mediaContent;

@property (strong, readonly) id content;

@property (nonatomic, readonly) NSInteger actionCount;

@end

NS_ASSUME_NONNULL_END
