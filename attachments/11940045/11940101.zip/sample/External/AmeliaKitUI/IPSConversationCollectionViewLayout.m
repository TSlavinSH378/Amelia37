//
//  Copyright © 2017 IPsoft. All rights reserved.
//

#import "IPSConversationCollectionViewLayout.h"
#import "IPSConversationMessageData.h"
#import "IPSCollectionViewLayoutAttributes.h"

@interface IPSConversationCollectionViewLayout ()
@property (readonly) id<IPSConversationCollectionViewLayoutDelegate> collectionViewDelegate;
@property (strong, nonatomic) NSMutableArray<IPSCollectionViewLayoutAttributes *> *attributes;
@property (strong, nonatomic) NSMutableDictionary<NSIndexPath *, IPSCollectionViewLayoutAttributes *> *indexPathToItemAttributes;
@property CGSize contentSize;
@end

@implementation IPSConversationCollectionViewLayout

+ (Class)layoutAttributesClass {
    return [IPSCollectionViewLayoutAttributes class];
}

- (CGSize)collectionViewContentSize {
    return self.contentSize;
}

- (void)prepareLayout {
    [self buildLayout];
    [super prepareLayout];
}

- (void)buildLayout {
    if (_attributes == nil) {
        _attributes = [NSMutableArray array];
    }
    if (_indexPathToItemAttributes == nil) {
        _indexPathToItemAttributes = [NSMutableDictionary dictionary];
    }
    
    [self.attributes removeAllObjects];
    [self.indexPathToItemAttributes removeAllObjects];
    
    id<IPSConversationCollectionViewLayoutDelegate> delegate = self.collectionViewDelegate;
    UICollectionView *collectionView = self.collectionView;
    
    CGFloat top = self.sectionInset.top;
    
    NSInteger sectionCount = [collectionView numberOfSections];
    for (int section = 0; section < sectionCount; ++section) {
        NSInteger itemCount = [collectionView numberOfItemsInSection:section];
        for (int item = 0; item < itemCount; ++item) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:item inSection:section];
            IPSCollectionViewLayoutAttributes *attributes = [IPSCollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
            
            // rowTypeForIndexPath:withItemCount:
            if (itemCount == 1) {
                attributes.rowType = IPSRowTypeSingle;
            } else if (indexPath.item == 0) {
                attributes.rowType = IPSRowTypeTop;
            } else if (indexPath.item == itemCount - 1) {
                attributes.rowType = IPSRowTypeBottom;
            } else {
                attributes.rowType = IPSRowTypeMiddle;
            }
            
            id<IPSConversationMessageData> message = [delegate messageForcollectionView:self.collectionView layout:self atIndexPath:indexPath];
            attributes.origin = [message origin];
            
            CGSize cellSize = [delegate collectionView:collectionView layout:self sizeForItemAtIndexPath:indexPath];
            CGFloat x = attributes.origin == IPSConversationMessageOriginRemote ? self.sectionInset.left : CGRectGetWidth(collectionView.bounds) - self.sectionInset.right - cellSize.width;
            attributes.frame = (CGRect) { .origin = CGPointMake(x, top), .size = cellSize };
            top = CGRectGetMaxY(attributes.frame) + self.minimumLineSpacing;
            
            self.indexPathToItemAttributes[indexPath] = attributes;
            [self.attributes addObject:attributes];
        }
        top += 10;
    }
    
    self.contentSize = CGSizeMake(CGRectGetWidth(collectionView.frame), top);
}

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect {
    NSMutableArray *attributes = [NSMutableArray array];
    
    for (UICollectionViewLayoutAttributes *attr in self.attributes) {
        if (CGRectIntersectsRect(rect, attr.frame)) {
            [attributes addObject:attr];
        }
    }
    
    return attributes;
}

- (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath {
    return self.indexPathToItemAttributes[indexPath];
}

- (id<IPSConversationCollectionViewLayoutDelegate>)collectionViewDelegate {
    return (id<IPSConversationCollectionViewLayoutDelegate>)self.collectionView.delegate;
}

@end
